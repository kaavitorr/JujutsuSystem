import BaseSettingsConfig from "./base-settings.mjs";

/**
 * An application for configuring variant rules settings.
 */
export default class VariantRulesSettingsConfig extends BaseSettingsConfig {
  /** @override */
  static DEFAULT_OPTIONS = {
    window: {
      title: "SETTINGS.DND5E.VARIANT.Label"
    }
  };

  /* -------------------------------------------- */

  /** @override */
  static PARTS = {
    general: {
      template: "systems/jujutsu-system/templates/settings/base-config.hbs"
    },
    encumbrance: {
      template: "systems/jujutsu-system/templates/settings/base-config.hbs"
    },
    abilities: {
      template: "systems/jujutsu-system/templates/settings/base-config.hbs"
    },
    scores: {
      template: "systems/jujutsu-system/templates/settings/base-config.hbs"
    },
    footer: {
      template: "templates/generic/form-footer.hbs"
    }
  };

  /* -------------------------------------------- */
  /*  Rendering                                   */
  /* -------------------------------------------- */

  /** @inheritDoc */
  async _preparePartContext(partId, context, options) {
    context = await super._preparePartContext(partId, context, options);
    switch ( partId ) {
      case "general":
        context.fields = [
          dnd5e.settings.rulesVersion === "legacy" ? this.createSettingField("allowFeats") : null,
          this.createSettingField("restVariant"),
          this.createSettingField("proficiencyModifier"),
          this.createSettingField("levelingMode")
        ].filter(_ => _);
        context.legend = _loc("SETTINGS.DND5E.General");
        break;
      case "encumbrance":
        context.fields = [
          this.createSettingField("encumbrance"),
          this.createSettingField("currencyWeight")
        ];
        context.legend = _loc("DND5E.Encumbrance");
        break;
      case "abilities":
        context.fields = [
          this.createSettingField("honorScore"),
          this.createSettingField("sanityScore")
        ];
        context.legend = _loc("DND5E.Abilities");
        break;
      case "scores":
        context.fields = [
          this.createSettingField("loyaltyScore"),
          this.createSettingField("pietyScore")
        ];
        context.legend = _loc("DND5E.AttributeScores");
        break;
    }
    return context;
  }
}

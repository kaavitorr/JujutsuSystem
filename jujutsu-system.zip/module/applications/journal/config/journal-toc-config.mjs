import DocumentSheet5e from "../../api/document-sheet.mjs";
import { createCheckboxInput } from "../../fields.mjs";

const { BooleanField, NumberField, SetField, StringField } = foundry.data.fields;

/**
 * Application for configuring a journal entry's listing in Table of Contents and its pages.
 */
export default class JournalTOCConfig extends DocumentSheet5e {
  /** @override */
  static DEFAULT_OPTIONS = {
    form: {
      submitOnChange: true
    },
    id: "journal-toc-config-{id}",
    position: {
      width: 400
    },
    window: {
      title: "DND5E.TABLEOFCONTENTS.Title"
    }
  };

  /* -------------------------------------------- */

  /** @override */
  static PARTS = {
    form: {
      template: "systems/jujutsu-system/templates/journal/config/journal-toc-config.hbs"
    }
  };

  /* --------------------------------------------- */
  /*  Properties                                   */
  /* --------------------------------------------- */

  /**
   * The compendium being configured.
   * @type {CompendiumCollection}
   */
  get compendium() {
    return this.document.collection;
  }

  /* --------------------------------------------- */

  /** @override */
  get title() {
    return _loc(this.options.window.title);
  }

  /* --------------------------------------------- */

  /** @override */
  get subtitle() {
    return this.document.name;
  }

  /* --------------------------------------------- */
  /*  Rendering                                    */
  /* --------------------------------------------- */

  /** @inheritDoc */
  async _prepareContext(options) {
    const context = await super._prepareContext(options);
    const { TableOfContentsCompendium } = dnd5e.applications.journal;
    const { chapterOptions } = await TableOfContentsCompendium._getEntryBreakdown(this.compendium);

    const data = this.document.flags["jujutsu-system"] ?? {};
    const appendedSpecial = (data.type === "special") && Number.isNumeric(data.append);
    context.fields = [
      {
        field: new StringField(),
        label: "DND5E.TABLEOFCONTENTS.FIELDS.type.label",
        localize: true,
        name: "type",
        options: TableOfContentsCompendium.TYPE_OPTIONS,
        value: data.type,
        visible: true
      },
      {
        field: new NumberField({ integer: true }),
        label: _loc("DND5E.TABLEOFCONTENTS.FIELDS.position.label"),
        name: "position",
        value: data.position,
        visible: (data.type === "appendix") || (data.type === "chapter")
      },
      {
        field: new NumberField(),
        label: _loc("DND5E.TABLEOFCONTENTS.FIELDS.position.label"),
        name: "append",
        options: chapterOptions,
        value: data.append,
        visible: data.type === "special"
      },
      {
        field: new NumberField({ integer: true }),
        label: _loc("DND5E.TABLEOFCONTENTS.FIELDS.order.label"),
        name: "order",
        value: data.order,
        visible: data.type === "special"
      },
      {
        field: new StringField(),
        label: _loc("DND5E.TABLEOFCONTENTS.FIELDS.title.label"),
        name: "title",
        placeholder: this.document.name,
        value: data.title,
        visible: !!data.type
      },
      {
        field: new BooleanField(),
        input: createCheckboxInput,
        label: _loc("DND5E.TABLEOFCONTENTS.HideAllPages"),
        name: "hidePages",
        value: data.showPages === false,
        visible: (data.type !== "header") && !appendedSpecial
      },
      {
        field: new BooleanField(),
        input: createCheckboxInput,
        label: _loc("DND5E.TABLEOFCONTENTS.FIELDS.showPages.label"),
        name: "showPages",
        value: data.showPages === true,
        visible: appendedSpecial
      },
      {
        field: new SetField(new StringField()),
        label: _loc("DND5E.TABLEOFCONTENTS.HiddenPages"),
        name: "hiddenPages",
        options: this.document.pages
          .map(page => {
            const option = { value: page.id, label: page.name, sort: page.sort };
            if ( this.document.categories.size ) {
              const category = this.document.categories.get(page.category);
              option.groupSort = category?.sort ?? -Infinity;
              option.group = category?.name ?? _loc("JOURNAL.Uncategorized");
            }
            return option;
          })
          .sort((lhs, rhs) => (lhs.groupSort - rhs.groupSort) || (lhs.sort - rhs.sort)),
        value: this.#getHiddenPages(),
        visible: (data.showPages !== false) && (
          ((data.type === "chapter") || (data.type === "appendix") || ((data.type === "special") && !appendedSpecial))
          || (appendedSpecial && (data.showPages === true))
        )
      }
    ];

    return context;
  }

  /* -------------------------------------------- */
  /*  Form Handling                               */
  /* -------------------------------------------- */

  /** @inheritDoc */
  _processFormData(event, form, formData) {
    const submitData = super._processFormData(event, form, formData);
    const update = {};

    const flagKeys = ["type", "position", "append", "order", "title"];
    if ( "hidePages" in submitData ) {
      if ( submitData.hidePages ) update.showPages = false;
      else update.showPages = _del;
    } else {
      flagKeys.push("showPages");
    }
    for ( const key of flagKeys ) {
      if ( submitData[key] || (submitData[key] === 0) ) update[key] = submitData[key];
      else update[key] = _del;
    }

    if ( submitData.hiddenPages ) {
      const currentlyHidden = this.#getHiddenPages();
      const formHidden = new Set(submitData.hiddenPages);
      const pageUpdates = [
        ...formHidden.difference(currentlyHidden).map(_id => ({ _id, "flags.jujutsu-system.tocHidden": true })),
        ...currentlyHidden.difference(formHidden).map(_id => ({ _id, "flags.jujutsu-system.tocHidden": _del }))
      ];
      if ( pageUpdates.length ) update._pageUpdates = pageUpdates;
    }

    return { flags: { dnd5e: update } };
  }

  /* -------------------------------------------- */

  /** @inheritDoc */
  async _processSubmitData(event, form, submitData, options={}) {
    if ( "_pageUpdates" in (submitData.flags?.["jujutsu-system"] ?? {}) ) {
      await this.document.updateEmbeddedDocuments("JournalEntryPage", submitData.flags["jujutsu-system"]._pageUpdates);
      delete submitData.flags["jujutsu-system"]._pageUpdates;
    }
    await super._processSubmitData(event, form, submitData, options);
    this.compendium.render();
  }

  /* -------------------------------------------- */
  /*  Helpers                                     */
  /* -------------------------------------------- */

  /**
   * Return the IDs of all pages in this journal entry that are hidden in the table of contents.
   * @returns {Set<string>}
   */
  #getHiddenPages() {
    return this.document.pages.reduce((hidden, page) => {
      if ( page.flags["jujutsu-system"]?.tocHidden ) hidden.add(page.id);
      return hidden;
    }, new Set());
  }
}

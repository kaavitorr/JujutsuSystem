import CompendiumTOCConfig from "./config/compendium-toc-config.mjs";

/**
 * Compendium that renders pages as a table of contents.
 */
export default class TableOfContentsCompendium extends foundry.applications.sidebar.apps.Compendium {
  /** @override */
  static DEFAULT_OPTIONS = {
    actions: {
      activateEntry: this.prototype._onClickLink,
      configureTableOfContents: TableOfContentsCompendium.#onConfigureTableOfContents
    },
    classes: ["table-of-contents"],
    position: {
      width: 800,
      height: 950
    },
    window: {
      contentTag: "article",
      controls: [
        {
          action: "configureTableOfContents",
          icon: "fa-solid fa-bars-staggered",
          label: "DND5E.TABLEOFCONTENTS.Action.Configure",
          visible: TableOfContentsCompendium.#canConfigureTableOfContents
        }
      ],
      resizable: true
    }
  };

  /* -------------------------------------------- */

  /** @override */
  static PARTS = {
    article: {
      root: true,
      template: "systems/jujutsu-system/templates/journal/table-of-contents.hbs"
    }
  };

  /* -------------------------------------------- */

  /**
   * Position of pages based on type.
   * @enum {number}
   */
  static TYPES = {
    chapter: 0,
    appendix: 100
  };

  /* -------------------------------------------- */

  /**
   * Options allowed for entry types.
   * @type {FormSelectOption[]}
   */
  static TYPE_OPTIONS = [
    { value: "chapter", label: "DND5E.TABLEOFCONTENTS.Type.Chapter" },
    { value: "appendix", label: "DND5E.TABLEOFCONTENTS.Type.Appendix" },
    { value: "header", label: "DND5E.TABLEOFCONTENTS.Type.Header" },
    { value: "special", label: "DND5E.TABLEOFCONTENTS.Type.Special" }
  ];

  /* -------------------------------------------- */
  /*  Rendering                                   */
  /* -------------------------------------------- */

  /** @override */
  _configureRenderParts(options) {
    // Skip normal compendium render parts logic.
    return foundry.utils.deepClone(this.constructor.PARTS);
  }

  /* -------------------------------------------- */

  /** @override */
  _createContextMenus() {
    this._createContextMenu(this._getEntryContextOptions, "[data-entry-id]", { fixed: true });
  }

  /* -------------------------------------------- */

  /** @inheritDoc */
  async _onRender(context, options) {
    await super._onRender(context, options);
    new CONFIG.ux.DragDrop({
      dragSelector: "[data-document-id]",
      dropSelector: "article",
      permissions: {
        dragstart: this._canDragStart.bind(this),
        drop: this._canDragDrop.bind(this)
      },
      callbacks: {
        dragstart: this._onDragStart.bind(this),
        drop: this._onDrop.bind(this)
      }
    }).bind(this.element);
  }

  /* -------------------------------------------- */

  /** @inheritDoc */
  async _prepareContext(options) {
    const context = await super._prepareContext(options);
    const documents = await this.collection.getDocuments();

    context.chapters = [];
    const specialEntries = [];
    for ( const entry of documents ) {
      const flags = entry.flags?.["jujutsu-system"];
      if ( !flags ) continue;
      const keys = Object.keys(flags);
      if ( flags.tocHidden || !keys.length || ((keys.length === 1) && (keys[0] === "navigation")) ) continue;
      const type = flags.type ?? "chapter";

      if ( type === "header" ) {
        const page = entry.pages.contents[0];
        context.header = {
          title: flags.title ?? page?.name,
          content: page?.text.content
        };
        continue;
      }

      const data = {
        type, flags,
        id: entry.id,
        name: flags.title ?? entry.name,
        pages: Array.from(entry.pages).map(({ flags, id, name, sort }) => ({
          id, sort, flags,
          name: flags.JujutsuLegacy?.title ?? name,
          entryId: entry.id
        }))
      };

      if ( type === "special" ) {
        data.showPages = flags.showPages ?? !flags.append;
        specialEntries.push(data);
      } else {
        data.order = (this.constructor.TYPES[type] ?? 200) + (flags.position ?? 0);
        data.showPages = (flags.showPages !== false) && ((flags.showPages === true) || (type === "chapter"));
        context.chapters.push(data);
      }
    }

    context.chapters.sort((lhs, rhs) => lhs.order - rhs.order);
    for ( const entry of specialEntries ) {
      const append = entry.flags.append;
      const order = entry.flags.order;
      if ( append && (append <= context.chapters.length) ) {
        context.chapters[append - 1].pages.push({ ...entry, sort: order, entry: true });
      } else {
        context.chapters.push(entry);
      }
    }

    for ( const chapter of context.chapters ) {
      chapter.pages = chapter.pages
        .filter(p => !p.flags.tocHidden && (chapter.showPages || p.entry))
        .sort((lhs, rhs) => lhs.sort - rhs.sort);
      for ( const page of chapter.pages ) {
        if ( page.pages ) page.pages.sort((lhs, rhs) => lhs.sort - rhs.sort);
      }
    }

    return context;
  }

  /* -------------------------------------------- */

  /** @inheritDoc */
  async _renderFrame(options) {
    const frame = await super._renderFrame(options);
    frame.dataset.compendiumId = this.collection.metadata.id;
    return frame;
  }

  /* -------------------------------------------- */
  /*  Event Handlers                              */
  /* -------------------------------------------- */

  /**
   * Whether it's possible to configure the table of contents.
   * @this {TableOfContentsCompendium}
   * @returns {boolean}
   */
  static #canConfigureTableOfContents() {
    return !this.collection.locked && this.collection.testUserPermission(game.user, "OWNER");
  }

  /* -------------------------------------------- */

  /**
   * Handle opening the configuration application.
   * @this {TableOfContentsCompendium}
   * @param {Event} event         Triggering click event.
   * @param {HTMLElement} target  Button that was clicked.
   */
  static async #onConfigureTableOfContents(event, target) {
    new CompendiumTOCConfig({ compendium: this.collection }).render({ force: true });
  }

  /* -------------------------------------------- */

  /**
   * Handle clicking a link to a journal entry or page.
   * @param {PointerEvent} event  The triggering click event.
   * @param {HTMLElement} target  The action target.
   * @protected
   */
  async _onClickLink(event, target) {
    const entryId = target.closest("[data-entry-id]")?.dataset.entryId;
    if ( !entryId ) return;
    const entry = await this.collection.getDocument(entryId);
    entry?.sheet.render(true, {
      pageId: target.closest("[data-page-id]")?.dataset.pageId
    });
  }

  /* -------------------------------------------- */

  /** @inheritDoc */
  _onDragStart(event) {
    let dragData;
    if ( ui.context ) ui.context.close({animate: false});
    dragData = this._getEntryDragData(event.target.dataset.documentId);
    if ( !dragData ) return;
    event.dataTransfer.setData("text/plain", JSON.stringify(dragData));
  }

  /* -------------------------------------------- */
  /*  Helpers                                     */
  /* -------------------------------------------- */

  /**
   * Prepare information on all entries in the provided compendium for configuring table of contents.
   * @param {CompendiumCollection} compendium
   * @returns { chapterOptions: FormSelectOption[], counts: Record<string, number> }
   */
  static async _getEntryBreakdown(compendium) {
    const docs = await compendium.getIndex({
      fields: ["flags.jujutsu-system.type", "flags.jujutsu-system.append", "flags.jujutsu-system.position"]
    });

    const counts = {};
    const chapterOptions = docs
      .reduce((arr, doc) => {
        const flags = doc.flags["jujutsu-system"] ?? {};
        if ( flags.type ) {
          counts[`${flags.type}-${flags.position ?? 0}`] ??= 0;
          counts[`${flags.type}-${flags.position ?? 0}`] += 1;
        }
        if ( (flags.type === "appendix") || (flags.type === "chapter") ) {
          const sort = TableOfContentsCompendium.TYPES[flags.type] + (flags.position ?? 0);
          arr.push({ label: _loc("DND5E.TABLEOFCONTENTS.Special.After", { chapter: doc.name }), sort });
        }
        return arr;
      }, [{ value: null, label: _loc("DND5E.TABLEOFCONTENTS.Special.End"), rule: true }])
      .sort((lhs, rhs) => lhs.sort - rhs.sort)
      .map((option, value) => ({ ...option, value: option.value === null ? null : value }));

    return { chapterOptions, counts };
  }
}

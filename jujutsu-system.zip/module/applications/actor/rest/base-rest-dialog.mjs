import { convertTime, filteredKeys } from "../../../utils.mjs";
import Dialog5e from "../../api/dialog.mjs";

const { BooleanField, NumberField, StringField } = foundry.data.fields;

/**
 * @import { RestConfiguration } from "../../../documents/_types.mjs";
 */

/**
 * Dialog with shared resting functionality.
 */
export default class BaseRestDialog extends Dialog5e {
  constructor(options={}) {
    super(options);
    this.actor = options.document;
    this.#config = options.config;
    this.options.window.title = CONFIG.DND5E.restTypes[options.config.type]?.label;
  }

  /* -------------------------------------------- */

  /** @override */
  static DEFAULT_OPTIONS = {
    actions: {
      setDurationSunrise: BaseRestDialog.#onSetDurationSunrise
    },
    classes: ["rest"],
    config: null,
    document: null,
    form: {
      handler: BaseRestDialog.#handleFormSubmission
    },
    position: {
      width: 380
    },
    templates: [
      "systems/jujutsu-system/templates/actors/rest/parts/duration.hbs",
      "systems/jujutsu-system/templates/actors/rest/parts/hit-dice.hbs",
      "systems/jujutsu-system/templates/actors/rest/parts/rest-request.hbs"
    ]
  };

  /* -------------------------------------------- */

  /** @inheritDoc */
  static PARTS = {
    ...super.PARTS,
    content: {
      template: "systems/jujutsu-system/templates/actors/rest/base-rest.hbs"
    }
  };

  /* -------------------------------------------- */
  /*  Properties                                  */
  /* -------------------------------------------- */

  /**
   * The actor being rested.
   * @type {Actor5e}
   */
  actor;

  /* -------------------------------------------- */

  /**
   * The rest configuration.
   * @type {RestConfiguration}
   */
  #config;

  get config() {
    return this.#config;
  }

  /* -------------------------------------------- */

  /**
   * Duration of the rest in minutes.
   * @type {number}
   */
  get duration() {
    return this.config.duration ?? CONFIG.DND5E.restTypes[this.config.type]
      ?.duration?.[dnd5e.settings.restVariant] ?? 0;
  }

  /* -------------------------------------------- */

  /**
   * Is the resting actor a party?
   * @type {boolean}
   */
  get isPartyGroup() {
    return this.actor.type === "group";
  }

  /* -------------------------------------------- */

  /**
   * Should the user be prompted as to whether a new day has occurred?
   * @type {boolean}
   */
  get promptNewDay() {
    // Only prompt if rest is longer than 10 minutes and less than 24 hours
    return dnd5e.settings.calendarConfig.manualRecovery && (this.duration > 10) && (this.duration < 1440);
  }

  /* -------------------------------------------- */

  /**
   * Was the rest button pressed?
   * @type {boolean}
   */
  #rested = false;

  get rested() {
    return this.#rested;
  }

  /* -------------------------------------------- */
  /*  Rendering                                   */
  /* -------------------------------------------- */

  /** @inheritDoc */
  async _prepareContext(options) {
    const context = {
      ...await super._prepareContext(options),
      actor: this.actor,
      config: this.config,
      fields: [],
      hitPoints: [],
      formSections: [],
      result: this.result,
      hd: this.actor.system.attributes?.hd,
      hp: this.actor.system.attributes?.hp,
      isGroup: this.isPartyGroup,
      variant: game.settings.get("jujutsu-system", "restVariant")
    };

    await this._prepareFields(context, options);

    if ( context.fields.length ) {
      context.formSections.push({ legend: "DND5E.REST.Configuration", fields: context.fields });
    }
    if ( context.hitPoints.length ) {
      context.formSections.push({ legend: "DND5E.HitPoints", fields: context.hitPoints });
    }

    if ( this.isPartyGroup ) {
      const restSettings = this.actor.getFlag("jujutsu-system", "restSettings") ?? {};
      const { autoRest=restSettings.autoRest, targets } = this.#config;
      context.request = [
        {
          field: new BooleanField({
            label: _loc("DND5E.REST.Request.AutoRest.Label"),
            hint: _loc("DND5E.REST.Request.AutoRest.Hint")
          }),
          name: "autoRest",
          input: context.inputs.createCheckboxInput,
          value: autoRest
        },
        ...this.actor.system.members
          .filter(m => m.actor?.system.isCreature)
          .map(m => ({
            field: new BooleanField({
              label: m.actor.name
            }),
            name: `targets.${m.actor.id}`,
            input: context.inputs.createCheckboxInput,
            value: targets?.[m.actor.id] ?? (restSettings.targets ? restSettings.targets.has(m.actor.id) : true)
          }))
      ];
    }

    return context;
  }

  /* -------------------------------------------- */

  /**
   * Handle preparing the main list of fields for the dialog.
   * @param {ApplicationRenderContext} context  Context being prepared.
   * @param {HandlebarsRenderOptions} options   Options which configure application rendering behavior.
   */
  async _prepareFields(context, options) {
    if ( this.promptNewDay ) context.fields.push({
      disabled: !!this.config.request,
      field: new BooleanField({
        label: _loc("DND5E.REST.NewDay.Label"),
        hint: _loc("DND5E.REST.NewDay.Hint")
      }),
      input: context.inputs.createCheckboxInput,
      name: "newDay",
      value: context.config.newDay
    });

    if ( context.isGroup && dnd5e.settings.calendarConfig.enabled ) {
      const duration = convertTime(this.duration, "minute", { strict: false });
      context.duration = {
        fields: [
          {
            field: new NumberField({ min: 0 }),
            name: "duration.value",
            value: duration.value
          },
          {
            field: new StringField({ required: true, blank: false }),
            name: "duration.unit",
            options: Object.entries(CONFIG.DND5E.timeUnits)
              .filter(([, c]) => !c.combat)
              .map(([value, { label }]) => ({ value, label })),
            value: duration.unit
          }
        ],
        showSunriseButton: "sunrise" in game.time.calendar
      };
      context.fields.push({ template: "systems/jujutsu-system/templates/actors/rest/parts/duration.hbs" });
    }

    const rest = CONFIG.DND5E.restTypes[this.config.type];
    if ( "recoverTemp" in rest ) context.hitPoints.push({
      disabled: !!this.config.request,
      field: new BooleanField({
        label: _loc("DND5E.REST.RecoverTempHP.Label")
      }),
      input: context.inputs.createCheckboxInput,
      name: "recoverTemp",
      value: context.config.recoverTemp
    });
    if ( "recoverTempMax" in rest ) context.hitPoints.push({
      disabled: !!this.config.request,
      field: new BooleanField({
        label: _loc("DND5E.REST.RecoverTempMaxHP.Label"),
        hint: _loc("DND5E.REST.RecoverTempMaxHP.Hint")
      }),
      input: context.inputs.createCheckboxInput,
      name: "recoverTempMax",
      value: context.config.recoverTempMax
    });
  }

  /* -------------------------------------------- */
  /*  Event Listeners and Handlers                */
  /* -------------------------------------------- */

  /**
   * Customize how form data is extracted into an expanded object.
   * @param {SubmitEvent|null} event     The originating form submission event.
   * @param {HTMLFormElement} form       The form element that was submitted.
   * @param {FormDataExtended} formData  Processed data for the submitted form.
   * @returns {object}                   An expanded object of processed form data.
   * @protected
   */
  _processFormData(event, form, formData) {
    const data = foundry.utils.expandObject(formData.object);
    if ( foundry.utils.isPlainObject(data.duration) ) {
      data.duration = convertTime(data.duration.value, data.duration.unit, { strict: false, to: "minute" }).value;
    }
    return data;
  }

  /* -------------------------------------------- */

  /**
   * Handle submission of the dialog using the form buttons.
   * @this {BaseRestDialog}
   * @param {Event|SubmitEvent} event    The form submission event.
   * @param {HTMLFormElement} form       The submitted form.
   * @param {FormDataExtended} formData  Data from the dialog.
   */
  static async #handleFormSubmission(event, form, formData) {
    const data = this._processFormData(event, form, formData);
    if ( this.isPartyGroup ) {
      data.targets = filteredKeys(data.targets ?? {});
      this.actor.setFlag("jujutsu-system", "restSettings", data);
    }
    foundry.utils.mergeObject(this.config, data);
    this.#rested = true;
    await this.close();
  }

  /* -------------------------------------------- */

  /**
   * Handle setting the rest duration to end at the next sunrise.
   * @this {BaseRestDialog}
   * @param {Event} event         Triggering click event.
   * @param {HTMLElement} target  Button that was clicked.
   */
  static #onSetDurationSunrise(event, target) {
    const sunrise = Math.round(game.time.calendar.sunrise());
    const now = game.time.components.hour;
    const hoursUntilSunrise = sunrise - now + (now > sunrise ? game.time.calendar.days.hoursPerDay : 0);
    this.form.elements["duration.value"].value = hoursUntilSunrise;
    this.form.elements["duration.unit"].value = "hour";
  }

  /* -------------------------------------------- */
  /*  Factory Methods                             */
  /* -------------------------------------------- */

  /**
   * A helper to handle displaying and responding to the dialog.
   * @param {Actor5e} actor              The actor that is resting.
   * @param {RestConfiguration}  config  Configuration information for the rest.
   * @returns {Promise<RestConfiguration>}
   */
  static async configure(actor, config) {
    return new Promise((resolve, reject) => {
      const app = new this({
        config,
        buttons: [
          {
            default: true,
            icon: "fa-solid fa-bed",
            label: _loc("DND5E.REST.Label"),
            name: "rest",
            type: "submit"
          }
        ],
        document: actor
      });
      app.addEventListener("close", () => app.rested ? resolve(app.config) : reject(), { once: true });
      app.render({ force: true });
    });
  }
}

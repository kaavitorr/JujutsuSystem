import { convertTime, formatTime, loadingTooltip } from "../../utils.mjs";
import ChatTrayElement from "./chat-tray-element.mjs";

/**
 * @import { RecordedTargetEntryCallback, TargetPillMenuEntryCallback } from "./_types.mjs";
 * @import RecordedTargetsElement from "./recorded-targets.mjs";
 */

/**
 * Application to handle applying active effects from a chat card.
 */
export default class EffectApplicationElement extends ChatTrayElement {

  /* -------------------------------------------- */
  /*  Properties                                  */
  /* -------------------------------------------- */

  /**
   * The HTML tag named used by this element.
   * @type {string}
   */
  static tagName = "effect-application";

  /* -------------------------------------------- */

  /**
   * The chat message with which this application is associated.
   * @type {ChatMessage5e}
   */
  chatMessage;

  /* -------------------------------------------- */

  /**
   * Active effects that will be applied by this application.
   * @type {ActiveEffect5e[]}
   */
  effects = [];

  /* -------------------------------------------- */

  /**
   * The list of active effects.
   * @type {HTMLUListElement}
   */
  effectsList;

  /* -------------------------------------------- */

  /**
   * Whether the tray itself manages its target selector.
   * @type {boolean}
   */
  get managesTargets() {
    return this.chatMessage?.getAssociatedActivity()?.metadata.targetPhase === "post";
  }

  /* -------------------------------------------- */

  /**
   * The container for the targets.
   * @type {RecordedTargetsElement}
   */
  targetList;

  /* -------------------------------------------- */

  /**
   * Checked status for effects.
   * @type {Map<string, boolean>}
   */
  #effectOptions = new Map();

  /* -------------------------------------------- */

  /**
   * Checked status for the given effect.
   * @param {string} uuid  UUID of the effect.
   * @returns {boolean}
   */
  effectChecked(uuid) {
    return this.#effectOptions.get(uuid) ?? false;
  }

  /* -------------------------------------------- */
  /*  Rendering                                   */
  /* -------------------------------------------- */

  /** @override */
  connectedCallback() {
    // Fetch the associated chat message
    const messageId = this.closest("[data-message-id]")?.dataset.messageId;
    this.chatMessage = game.messages.get(messageId);
    if ( !this.chatMessage ) return;

    // Build the frame HTML only once
    if ( !this.effectsList ) {
      let effectPromise;
      if ( !this.effects.length ) effectPromise = (this.chatMessage.system.getEffects?.() ?? Promise.all(
        Array.from(this.querySelectorAll("option")).map(o => fromUuid(o.value))
      )).then(p => this.effects = p.filter(_ => _));
      const div = document.createElement("div");
      div.classList.add("card-tray", "effects-tray", "collapsible");
      if ( !this.open ) div.classList.add("collapsed");
      div.innerHTML = `
        <label class="roboto-upper">
          <i class="fa-solid fa-bolt"></i>
          <span>${_loc("DND5E.EFFECT.Application.Header")}</span>
          <i class="fa-solid fa-caret-down"></i>
        </label>
        <div class="collapsible-content">
          <div class="wrapper">
            <menu class="effects unlist"></menu>
            <template></template>
            <button type="button" class="apply-button" data-action="apply">
              <i class="fa-light fa-reply-all fa-flip-horizontal" inert></i>
              <span>${_loc("DND5E.EFFECT.Action.Apply")}</span>
            </button>
          </div>
        </div>
      `;
      this.replaceChildren(div);
      this.effectsList = div.querySelector(".effects");
      const slot = div.querySelector("template");
      if ( this.managesTargets ) slot.replaceWith(this.buildTargetContainer());
      else slot.remove();
      if ( effectPromise ) effectPromise.then(() => this.buildEffectsList());
      else this.buildEffectsList();
      this.effectsList.addEventListener("click", this._onCheckEffect.bind(this));
      div.addEventListener("click", this._handleClickHeader.bind(this));
      div.querySelector(".apply-button").addEventListener("click", this._onApplyEffects.bind(this));
    }
  }

  /* -------------------------------------------- */

  /**
   * Build a list of active effects.
   */
  buildEffectsList() {
    if ( this.effects.length && foundry.utils.isEmpty(this.#effectOptions) ) {
      this.#effectOptions.set(this.effects[0].uuid, true);
    }
    for ( const effect of this.effects ) {
      effect.updateDuration();
      const { icon, label } = this.#formatDuration(effect);
      const li = document.createElement("li");
      li.classList.add("effect");
      Object.assign(li.dataset, {
        id: effect.id,
        tooltipHtml: loadingTooltip({ uuid: effect.uuid }),
        tooltipClass: "dnd5e2 dnd5e-tooltip effect-tooltip document-tooltip",
        tooltipDirection: "LEFT",
        uuid: effect.uuid
      });
      li.innerHTML = `
        <button type="button" class="unbutton" aria-pressed="${this.effectChecked(effect.uuid)}">
          <img class="gold-icon">
          <span class="title"></span>
          <span class="duration pill transparent">
            <i class="fa-solid ${icon}" inert></i>
            <span>${label}</span>
          </span>
          <span class="pip" inert></span>
        </button>
      `;
      Object.assign(li.querySelector(".gold-icon"), { alt: effect.name, src: effect.img });
      li.querySelector(".title").append(effect.name);
      this.effectsList.append(li);
    }
  }

  /* -------------------------------------------- */

  /**
   * Build a managed target selector.
   * @returns {RecordedTargetsElement}
   */
  buildTargetContainer() {
    this.targetList = document.createElement("recorded-targets");
    this.targetList.suspended = !this.open;
    return this.targetList;
  }

  /* -------------------------------------------- */

  /**
   * Abbreviate an effect's duration, using the most significant unit that can represent it.
   * @param {ActiveEffect5e} effect              The effect being displayed.
   * @returns {{ icon: string, label: string }}  Icon and label to display.
   */
  #formatDuration(effect) {
    const special = effect.getSpecialDurationParts();
    if ( special ) return special;
    const { label, units, value } = effect.duration;
    if ( !Number.isFinite(value) || !units ) return { icon: "fa-clock", label };
    const from = units.replace(/s$/, "");
    const { unit, value: converted } = CONFIG.DND5E.timeUnits[from]?.combat
      ? { value, unit: from }
      : convertTime(value, from, { truncate: true });
    return { icon: "fa-clock", label: formatTime(converted, unit, { unitDisplay: "narrow" }) };
  }

  /* -------------------------------------------- */
  /*  Methods                                     */
  /* -------------------------------------------- */

  /**
   * Handle applying an Active Effect to a Token.
   * @param {ActiveEffect5e} effect      The effect to apply.
   * @param {Actor5e} actor              The actor to which the effect should be applied.
   * @returns {Promise<ActiveEffect5e>}  The created effect.
   * @throws {Error}                     If the effect could not be applied.
   * @protected
   */
  async _applyEffectToActor(effect, actor) {
    const { action, data } = await this._prepareEffectData(effect, actor);
    if ( action === "update" ) return actor.effects.get(data._id).update(data);
    return ActiveEffect.implementation.create(data, { parent: actor });
  }

  /* -------------------------------------------- */

  /**
   * Prepare the data for applying an Active Effect to an Actor.
   * @param {ActiveEffect5e} effect  The effect to apply.
   * @param {Actor5e} actor          The actor.
   * @returns {Promise<{ action: "create"|"update", data: object }>}
   * @throws {Error}
   * @protected
   */
  async _prepareEffectData(effect, actor) {
    const originActor = this.chatMessage.getAssociatedActor();
    const concentration = originActor?.effects.get(this.chatMessage.system.concentration);
    const item = this.chatMessage.getAssociatedItem({ scaled: true });
    const activity = this.chatMessage.getAssociatedActivity({ scaled: true });
    const sourceKey = effect.inCompendium ? "compendiumSource" : "duplicateSource";
    if ( !game.user.isGM && !actor.isOwner ) {
      throw new Error(_loc("DND5E.EFFECT.Application.Warning.Ownership"));
    }

    // Get any effect changes provided by the activity & add flags
    const changes = activity?.getAppliedEffectChanges(effect, { chatMessage: this.chatMessage, target: actor }) ?? {};
    foundry.utils.mergeObject(changes, {
      flags: {
        dnd5e: {
          dependentOn: concentration?.uuid,
          scaling: this.chatMessage.system.scaling,
          spellLevel: this.chatMessage.system.level
        }
      },
      system: {
        origin: {
          [activity ? "activity" : "item"]: activity ? activity.uuid : item?.uuid,
          effect: concentration?.uuid,
          message: this.chatMessage.uuid,
          profile: activity
            ? activity.effects?.find(e => (e.uuid === effect.uuid) || (e._id === effect.id))?._id : undefined
        }
      }
    });

    // Enable an existing effect on the target if it originated from this effect
    const existingEffect = actor.effects.find(e => e._stats[sourceKey] === effect.uuid);
    if ( existingEffect ) {
      return { action: "update", data: foundry.utils.mergeObject({
        _id: existingEffect.id,
        disabled: false,
        duration: {
          expired: false
        },
        start: effect.constructor.getEffectStart()
      }, changes) };
    }

    // Otherwise, create a new effect on the target
    const effectData = foundry.utils.mergeObject({
      ...effect.toObject(),
      disabled: false,
      transfer: false,
      _stats: {
        [sourceKey]: effect.uuid,
        [effect.inCompendium ? "duplicateSource" : "compendiumSource"]: null
      }
    }, changes);

    effectData.system.changes = await ActiveEffect.implementation.forApplication(
      effectData.system.changes,
      activity ?? item ?? originActor,
      actor
    );

    return { action: "create", data: effectData };
  }

  /* -------------------------------------------- */

  /**
   * Get the UUIDs of targets to apply selected effects to.
   * @returns {string[]}
   */
  #getTargets() {
    const recordedTargets = this.targetList ?? this.closest("[data-message-id]").querySelector("recorded-targets");
    if ( recordedTargets ) return recordedTargets.targets;
    return canvas.tokens?.controlled?.map(t => t.actor ? t.document.uuid : null).filter(_ => _) ?? [];
  }

  /* -------------------------------------------- */
  /*  Event Handlers                              */
  /* -------------------------------------------- */

  /** @inheritDoc */
  _handleToggleOpen(open) {
    super._handleToggleOpen(open);
    if ( this.targetList ) this.targetList.suspended = !open;
  }

  /* -------------------------------------------- */

  /**
   * Handle applying selected effects to the appropriate targets.
   * @protected
   */
  async _onApplyEffects() {
    const effects = this.effects.filter(e => this.effectChecked(e.uuid));
    const operations = [];
    for ( const uuid of this.#getTargets() ) {
      const doc = await fromUuid(uuid);
      const actor = doc?.actor ?? doc;
      if ( !actor?.isOwner ) continue;
      const data = [];
      const updates = [];
      for ( const effect of effects ) {
        try {
          const operation = await this._prepareEffectData(effect, actor);
          (operation.action === "create" ? data : updates).push(operation.data);
        } catch (err) {
          Hooks.onError("EffectApplicationElement._prepareEffectData", err, { notify: "warn", log: "warn" });
        }
      }
      if ( data.length ) operations.push({ data, action: "create", documentName: "ActiveEffect", parent: actor });
      if ( updates.length ) {
        operations.push({ updates, action: "update", documentName: "ActiveEffect", parent: actor });
      }
    }
    if ( operations.length ) await foundry.documents.modifyBatch(operations);
    if ( game.settings.get("jujutsu-system", "autoCollapseChatTrays") !== "manual" ) {
      this.querySelector(".collapsible").dispatchEvent(new PointerEvent("click", { bubbles: true, cancelable: true }));
    }
  }

  /* -------------------------------------------- */

  /**
   * Handle checking or unchecking an effect.
   * @param {PointerEvent} event  The triggering event.
   * @protected
   */
  _onCheckEffect(event) {
    const effect = event.target.closest(".effect[data-uuid]");
    if ( !effect ) return;
    event.stopPropagation();
    const { uuid } = effect.dataset;
    const checked = this.#effectOptions.get(uuid);
    if ( !event.shiftKey ) this.#effectOptions.clear();
    this.#effectOptions.set(uuid, event.shiftKey ? !checked : true);
    this.querySelectorAll(".effect[data-uuid]").forEach(el => {
      el.querySelector("button").ariaPressed = `${this.#effectOptions.get(el.dataset.uuid) ?? false}`;
    });
  }
}

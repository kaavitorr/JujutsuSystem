import { COMPARISON_FUNCTIONS, OPERATOR_FUNCTIONS } from "../../filter.mjs";
import { getHumanReadableAttributeLabel } from "../../utils.mjs";
import FiltersEditor from "../filters-editor.mjs";

/**
 * Element for displaying and editing filters.
 * @extends {AbstractFormInputElement}
 */
export default class FiltersInputElement extends foundry.applications.elements.AbstractFormInputElement {

  /** @override */
  static tagName = "filters-input";

  /* -------------------------------------------- */
  /*  Properties                                  */
  /* -------------------------------------------- */

  /**
   * Element containing the filters breakdown.
   * @type {HTMLElement}
   */
  #breakdown;

  /* -------------------------------------------- */

  /**
   * Element for opening the editor.
   * @type {HTMLButtonElement}
   */
  #button;

  /* -------------------------------------------- */

  /**
   * Editor instance opened by this input.
   * @type {FiltersEditor}
   */
  #editor;

  /* -------------------------------------------- */

  /** @override */
  _toggleDisabled(disabled) {
    this.#button.disabled = disabled;
  }

  /* -------------------------------------------- */
  /*  Rendering                                   */
  /* -------------------------------------------- */

  /** @override */
  _buildElements() {
    this._value ??= this.getAttribute("value") || this.innerText || "{}";

    // Create filter breakdown
    this.#breakdown = document.createElement("filters-breakdown");
    this.#refreshBreakdown();

    // Create button for opening editor
    const b = this.#button = document.createElement("button");
    Object.assign(b, { ariaLabel: _loc("DND5E.FILTER.Action.Edit"), type: "button" });
    b.classList.add("icon", "fa-solid", "fa-filter");
    b.dataset.tooltip = "";

    return [this.#breakdown, this.#button];
  }

  /* -------------------------------------------- */

  /** @override */
  _refresh() {
    this.#refreshBreakdown();
  }

  /* -------------------------------------------- */

  /**
   * Render the filters breakdown.
   */
  #refreshBreakdown() {
    let filters;
    try {
      filters = JSON.parse(this.value);
    } catch {
      this.#breakdown.innerText = _loc("DND5E.FILTER.Invalid");
      return;
    }

    const isEmpty = foundry.utils.isEmpty(filters);
    this.#breakdown.classList.toggle("empty", isEmpty);
    if ( isEmpty ) {
      this.#breakdown.innerText = _loc("DND5E.FILTER.Empty");
      return;
    }

    let breakdown;
    try {
      breakdown = this.#renderBreakdownNode(Array.isArray(filters) ? { o: "AND", v: filters } : filters);
    } catch {}
    if ( breakdown ) this.#breakdown.replaceChildren(breakdown);
    else this.#breakdown.innerText = _loc("DND5E.FILTER.Invalid");
  }

  /* -------------------------------------------- */

  /**
   * Turn a single filter node into an breakdown element.
   * @param {FilterDescription} filter
   * @returns {HTMLElement|void}
   */
  #renderBreakdownNode(filter) {
    if ( !foundry.utils.isPlainObject(filter) ) throw new Error("Invalid breakdown");
    let { k: key, o: operator="exact", v: value } = filter;

    // If in OPERATOR_FUNCTIONS, create group and recurse
    if ( operator in OPERATOR_FUNCTIONS ) {
      const node = document.createElement("filter-operator");
      node.setAttribute("operator", operator);
      if ( !foundry.utils.isEmpty(value) ) {
        if ( !Array.isArray(value) ) value = [value];
        node.replaceChildren(...value.map(v => this.#renderBreakdownNode(v)).filter(_ => _));
      }
      return node;
    }

    // If in COMPARISON_FUNCTIONS, create entry
    if ( operator in COMPARISON_FUNCTIONS ) {
      const node = document.createElement("filter-comparison");
      node.setAttribute("operator", operator);
      const keyElement = document.createElement("filter-key");
      keyElement.innerText = getHumanReadableAttributeLabel(key) ?? key;
      if ( foundry.utils.isEmpty(value) ) {
        node.replaceChildren(keyElement);
      } else {
        const valueElement = document.createElement("filter-value");
        if ( foundry.utils.isPlainObject(value) ) {
          const innerNode = this.#renderBreakdownNode(value);
          if ( innerNode ) valueElement.replaceChildren(innerNode);
        } else {
          valueElement.innerText = Array.isArray(value) ? value.join(", ") : value;
        }
        node.replaceChildren(keyElement, valueElement);
      }
      return node;
    }
  }

  /* -------------------------------------------- */
  /*  Event Listeners and Handlers                */
  /* -------------------------------------------- */

  /** @override */
  _activateListeners() {
    this.#button.addEventListener("click", this.#onOpenEditor.bind(this), { signal: this.abortSignal });
  }

  /* -------------------------------------------- */

  /**
   * Handle opening the filters config application for this input.
   * @param {PointerEvent} event  Triggering click event.
   */
  #onOpenEditor(event) {
    event.preventDefault();
    const edit = new Event("edit", { bubbles: true, cancelable: true });
    this.dispatchEvent(edit);
    if ( edit.defaultPrevented ) return;

    this.#editor?.close();
    this.#editor = new FiltersEditor({ value: this.value });
    this.#editor.addEventListener("close", () => {
      this.value = this.#editor.value;
      this.#editor = undefined;
    }, { once: true });
    this.#editor.render({ force: true, window: { windowId: this.ownerDocument.defaultView.id } });
  }

  /* -------------------------------------------- */
  /*  Factory Methods                             */
  /* -------------------------------------------- */

  /**
   * Create a `<filters-input>` element for a FiltersField.
   * @param {FormInputConfig<string>} config
   * @returns {FiltersInputElement}
   */
  static create(config) {
    const input = new this();
    if ( config.value ) input.setAttribute("value", config.value);
    foundry.applications.fields.setInputAttributes(input, config);
    return input;
  }
}

/* -------------------------------------------- */

/**
 * Small custom element to insert separators between elements in the comparison.
 */
export class FilterOperatorElement extends HTMLElement {

  static {
    window.customElements.define("filter-operator", FilterOperatorElement);
  }

  /* -------------------------------------------- */

  /** @override */
  connectedCallback() {
    const operator = this.getAttribute("operator");
    const symbol = operator?.endsWith("AND") ? _loc("DND5E.FILTER.Operator.And")
      : operator?.endsWith("OR") ? _loc("DND5E.FILTER.Operator.Or") : null;
    if ( symbol ) this.querySelectorAll(":is(filter-comparison, filter-operator):not(:last-child)").forEach(e =>
      e.insertAdjacentHTML("afterend", `<span class="separator">${symbol}</span>`)
    );
    if ( operator?.startsWith("N") ) this.insertAdjacentHTML(
      "afterbegin", `<span class="separator">${_loc("DND5E.FILTER.Operator.Not")}</span>`
    );
  }

  /* -------------------------------------------- */

  /** @override */
  disconnectedCallback() {
    this.querySelectorAll(".separator").forEach(e => e.remove());
  }
}

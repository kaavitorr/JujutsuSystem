import RollConfigurationDialog from "../applications/dice/roll-configuration-dialog.mjs";
import BasicDie from "./basic-die.mjs";

const { DiceTerm, NumericTerm, PoolTerm, RollTerm } = foundry.dice.terms;

/**
 * @import {
 *   BasicRollConfiguration, BasicRollDialogConfiguration, BasicRollMessageConfiguration,
 *   BasicRollOptions, BasicRollProcessConfiguration
 * } from "./_types.mjs";
 */

/**
 * Custom base roll type with methods for building rolls, presenting prompts, and creating messages.
 */
export default class BasicRoll extends Roll {

  /**
   * Default application used for the roll configuration prompt.
   * @type {typeof RollConfigurationDialog}
   */
  static DefaultConfigurationDialog = RollConfigurationDialog;

  /* -------------------------------------------- */
  /*  Static Construction                         */
  /* -------------------------------------------- */

  /**
   * Create a roll instance from a roll config.
   * @param {BasicRollConfiguration} config          Configuration info for the roll.
   * @param {BasicRollProcessConfiguration} process  Configuration info for the whole rolling process.
   * @returns {BasicRoll}
   */
  static fromConfig(config, process) {
    const formula = (config.parts ?? []).join(" + ");
    config.options ??= {};
    config.options.target ??= process.target;
    return new this(formula, config.data, config.options);
  }

  /* -------------------------------------------- */

  /**
   * Construct roll parts and populate its data object.
   * @param {object} parts   Information on the parts to be constructed.
   * @param {object} [data]  Roll data to use and populate while constructing the parts.
   * @returns {{ parts: string[], data: object }}
   */
  static constructParts(parts, data={}) {
    const finalParts = [];
    for ( const [key, value] of Object.entries(parts) ) {
      if ( !value && (value !== 0) ) continue;
      finalParts.push(`@${key}`);
      foundry.utils.setProperty(data, key, value);
    }
    return { parts: finalParts, data };
  }

  /* -------------------------------------------- */

  /**
   * Construct and perform a roll through the standard workflow.
   * @param {BasicRollProcessConfiguration} [config={}]   Configuration for the rolls.
   * @param {BasicRollDialogConfiguration} [dialog={}]    Configuration for roll prompt.
   * @param {BasicRollMessageConfiguration} [message={}]  Configuration for message creation.
   * @returns {BasicRoll[]}
   */
  static async build(config={}, dialog={}, message={}) {
    const rolls = await this.buildConfigure(config, dialog, message);
    await this.buildEvaluate(rolls, config, message);
    await this.buildPost(rolls, config, message);
    return rolls;
  }

  /* -------------------------------------------- */

  /**
   * Stage one of the standard rolling workflow, configuring the roll.
   * @param {BasicRollProcessConfiguration} [config={}]   Configuration for the rolls.
   * @param {BasicRollDialogConfiguration} [dialog={}]    Configuration for roll prompt.
   * @param {BasicRollMessageConfiguration} [message={}]  Configuration for message creation.
   * @returns {Promise<BasicRoll[]>}
   */
  static async buildConfigure(config={}, dialog={}, message={}) {
    config.hookNames = [...(config.hookNames ?? []), ""];

    /**
     * A hook event that fires before a roll is performed. Multiple hooks may be called depending on the rolling
     * method (e.g. `dnd5e.preRollSkill`, `dnd5e.preRollAbilityCheck`, `dnd5e.preRoll`). Exact contents of the
     * configuration object will also change based on the roll type, but the same objects will always be present.
     * @function dnd5e.preRoll
     * @memberof hookEvents
     * @param {BasicRollProcessConfiguration} config   Configuration data for the pending roll.
     * @param {BasicRollDialogConfiguration} dialog    Presentation data for the roll configuration dialog.
     * @param {BasicRollMessageConfiguration} message  Configuration data for the roll's message.
     * @returns {boolean}                              Explicitly return `false` to prevent the roll.
     */
    for ( const hookName of config.hookNames ) {
      if ( Hooks.call(`dnd5e.preRoll${hookName.capitalize()}`, config, dialog, message) === false ) return [];
      if ( Hooks.call(`dnd5e.preRoll${hookName.capitalize()}V2`, config, dialog, message) === false ) return [];
    }

    this.applyKeybindings(config, dialog, message);
    dialog.sheet ??= foundry.applications.instances.get(config.event?.target?.closest(".application")?.id);

    let rolls;
    if ( dialog.configure === false ) {
      rolls = config.rolls?.map((r, index) => {
        dialog.options?.buildConfig?.(config, r, null, index);
        for ( const hookName of config.hookNames ) {
          Hooks.callAll(`dnd5e.postBuild${hookName.capitalize()}RollConfig`, config, r, index);
        }
        return this.fromConfig(r, config);
      }) ?? [];
    } else {
      const DialogClass = dialog.applicationClass ?? this.DefaultConfigurationDialog;
      rolls = await DialogClass.configure(config, dialog, message);
    }

    // Store the roll type in roll.options so it can be accessed from only the roll
    const rollType = foundry.utils.getProperty(message, "data.type");
    if ( rollType && (rollType !== "base") ) rolls.forEach(roll => roll.options.rollType ??= rollType);

    /**
     * A hook event that fires after roll configuration is complete, but before the roll is evaluated.
     * Multiple hooks may be called depending on the rolling method (e.g. `dnd5e.postSkillCheckRollConfiguration`,
     * `dnd5e.postAbilityTestRollConfiguration`, and `dnd5e.postRollConfiguration` for skill checks). Exact contents of
     * the configuration object will also change based on the roll type, but the same objects will always be present.
     * @function dnd5e.postRollConfiguration
     * @memberof hookEvents
     * @param {BasicRoll[]} rolls                      Rolls that have been constructed but not evaluated.
     * @param {BasicRollProcessConfiguration} config   Configuration information for the roll.
     * @param {BasicRollDialogConfiguration} dialog    Configuration for the roll dialog.
     * @param {BasicRollMessageConfiguration} message  Configuration for the roll message.
     * @returns {boolean}                              Explicitly return `false` to prevent rolls.
     */
    for ( const hookName of config.hookNames ) {
      const name = `dnd5e.post${hookName.capitalize()}RollConfiguration`;
      if ( Hooks.call(name, rolls, config, dialog, message) === false ) return [];
    }

    return rolls;
  }

  /* -------------------------------------------- */

  /**
   * Stage two of the standard rolling workflow, evaluating the rolls.
   * @param {BasicRoll[]} rolls                           Rolls to evaluate.
   * @param {BasicRollProcessConfiguration} [config={}]   Configuration for the rolls.
   * @param {BasicRollMessageConfiguration} [message={}]  Configuration for message creation.
   */
  static async buildEvaluate(rolls, config={}, message={}) {
    if ( config.evaluate !== false ) {
      for ( const roll of rolls ) await roll.evaluate();
    }
  }

  /* -------------------------------------------- */

  /**
   * Stage three of the standard rolling workflow, posting a message to chat.
   * @param {BasicRoll[]} rolls                      Rolls to evaluate.
   * @param {BasicRollProcessConfiguration} config   Configuration for the rolls.
   * @param {BasicRollMessageConfiguration} message  Configuration for message creation.
   * @returns {ChatMessage5e|void}
   */
  static async buildPost(rolls, config, message) {
    message.data = foundry.utils.expandObject(message.data ?? {});
    const messageId = config.event?.target?.closest("[data-message-id]")?.dataset.messageId;
    if ( messageId ) foundry.utils.setProperty(message.data, "system.origin", messageId);

    // Attack & Damage store their origin directly on message.data and do not have a config.event. We retrieve
    // those here.
    const origin = foundry.utils.getProperty(message.data, "system.origin");
    // Store in roll options so that it can be serialized.
    if ( origin ) rolls?.forEach(r => r.options.originatingMessage ??= origin);

    if ( rolls?.length && (config.evaluate !== false) ) {
      message[message.create !== false ? "document" : "data"] = await this.toMessage(
        rolls, message.data, { create: message.create, rollMode: message.rollMode }
      );
      if ( message.document ) rolls.forEach(r => r.parent = message.document);
    }

    return message.document;
  }

  /* -------------------------------------------- */

  /**
   * Determines whether the roll process should be fast forwarded.
   * @param {BasicRollProcessConfiguration} config   Roll configuration data.
   * @param {BasicRollDialogConfiguration} dialog    Data for the roll configuration dialog.
   * @param {BasicRollMessageConfiguration} message  Message configuration data.
   */
  static applyKeybindings(config, dialog, message) {
    dialog.configure ??= true;
  }

  /* -------------------------------------------- */
  /*  Properties                                  */
  /* -------------------------------------------- */

  /**
   * Get the chat message that originated this roll (e.g. the item card that triggered it), if any.
   * @returns {ChatMessage5e|null}
   */
  getOriginatingMessage() {
    return game.messages.get(this.options.originatingMessage) ?? null;
  }

  /* -------------------------------------------- */

  /**
   * Is the result of this roll a failure? Returns `undefined` if roll isn't evaluated.
   * @type {boolean|void}
   */
  get isFailure() {
    if ( !this._evaluated ) return;
    if ( !Number.isNumeric(this.options.target) ) return false;
    return this.total < this.options.target;
  }

  /* -------------------------------------------- */

  /**
   * Is the result of this roll a success? Returns `undefined` if roll isn't evaluated.
   * @type {boolean|void}
   */
  get isSuccess() {
    if ( !this._evaluated ) return;
    if ( !Number.isNumeric(this.options.target) ) return false;
    return this.total >= this.options.target;
  }

  /* -------------------------------------------- */
  /*  Chat Messages                               */
  /* -------------------------------------------- */

  /**
   * Transform a Roll instance into a ChatMessage, displaying the roll result.
   * This function can either create the ChatMessage directly, or return the data object that will be used to create it.
   *
   * @param {BasicRoll[]} rolls              Rolls to add to the message.
   * @param {object} messageData             The data object to use when creating the message.
   * @param {options} [options]              Additional options which modify the created message.
   * @param {string} [options.rollMode]      The roll mode to use for the message from `CONFIG.ChatMessage.modes`.
   * @param {boolean} [options.create=true]  Whether to automatically create the chat message, or only return the
   *                                         prepared chatData object.
   * @returns {Promise<ChatMessage|object>}  A promise which resolves to the created ChatMessage document if create is
   *                                         true, or the Object of prepared chatData otherwise.
   */
  static async toMessage(rolls, messageData={}, { rollMode, create=true }={}) {
    for ( const roll of rolls ) {
      if ( !roll._evaluated ) await roll.evaluate({ allowInteractive: rollMode !== CONST.DICE_ROLL_MODES.BLIND });
      rollMode ??= roll.options.rollMode;
    }
    rollMode ??= BasicRoll.getMessageMode();

    // Prepare chat data
    messageData = foundry.utils.mergeObject({ sound: CONFIG.sounds.dice }, messageData);
    this._prepareMessageData(rolls, messageData);
    messageData.rolls = rolls.map(r => this.fromData(r.toJSON()));

    // Process the chat data
    const cls = getDocumentClass("ChatMessage");
    const msg = new cls(messageData);

    // Either create or return the data
    if ( create ) return cls.create(msg.toObject(), { messageMode: rollMode });
    else {
      if ( rollMode ) msg.applyMode(rollMode);
      return msg.toObject();
    }
  }

  /* -------------------------------------------- */

  /**
   * Perform specific changes to message data before creating message.
   * @param {BasicRoll[]} rolls   Rolls to add to the message.
   * @param {object} messageData  The data object to use when creating the message.
   * @protected
   */
  static _prepareMessageData(rolls, messageData) {}

  /* -------------------------------------------- */

  /** @inheritDoc */
  async getTooltip() {
    const ast = CONFIG.Dice.parser.toAST(this.clone().terms);
    const constants = this.constructor.collectConstants?.(ast).filter(({ flavor, total }) => flavor || total);
    return foundry.applications.handlebars.renderTemplate(this.constructor.TOOLTIP_TEMPLATE, {
      constants,
      parts: this.dice.map(d => d.getTooltipData())
    });
  }

  /* -------------------------------------------- */

  async _prepareChatRenderContext(options) {
    const context = await super._prepareChatRenderContext(options);
    context.classes = "";
    context.icons = [];
    context.isPrivate = options.isPrivate;
    if ( options.isPrivate || !this._evaluated || !Number.isFinite(this.options.target) ) return context;
    const success = this.isSuccess || options.forceSuccess;
    context.classes = success ? "success" : "failure";
    context.icons.push(success ? "fa-check" : "fa-xmark");
    return context;
  }

  /* -------------------------------------------- */
  /*  Evaluate Methods                            */
  /* -------------------------------------------- */

  /** @inheritDoc */
  async evaluate(options={}) {
    this.preCalculateDiceTerms(options);
    for ( const term of this.terms ) {
      if ( term instanceof BasicDie ) term.expandAdvantage();
    }
    return super.evaluate(options);
  }

  /* -------------------------------------------- */

  /** @inheritDoc */
  evaluateSync(options={}) {
    this.preCalculateDiceTerms(options);
    for ( const term of this.terms ) {
      if ( term instanceof BasicDie ) term.expandAdvantage();
    }
    return super.evaluateSync(options);
  }

  /* -------------------------------------------- */
  /*  Roll Formula Parsing                        */
  /* -------------------------------------------- */

  /**
   * Collect constant terms from an AST node.
   * @param {RollParseNode} node     The node.
   * @param {number} [multiplier=1]  The outer multiplier, if any.
   * @returns {{ flavor: string, total: number }[]}
   */
  static collectConstants(node, multiplier=1) {
    if ( (node.class === "Node") && ((node.operator === "+") || (node.operator === "-")) ) {
      const [left, right] = node.operands;
      return [
        ...this.collectConstants(left, multiplier),
        ...this.collectConstants(right, node.operator === "-" ? -multiplier : multiplier)
      ];
    }
    const terms = CONFIG.Dice.parser.flattenTree(node).map(term => {
      return term instanceof RollTerm ? term : RollTerm.fromData(term);
    });
    const roll = Roll.fromTerms(terms);
    if ( !roll.isDeterministic ) return [];
    const flavor = terms.map(term => term.flavor).filterJoin(", ");
    const total = roll.evaluateSync().total * multiplier;
    return [{ flavor, total }];
  }

  /* -------------------------------------------- */

  /** @inheritDoc */
  static replaceFormulaData(formula, data, options={}, _r=0) {
    options.recursive ??= true;
    return super.replaceFormulaData(formula, data, options, _r);
  }

  /* -------------------------------------------- */
  /*  Inversion Methods                           */
  /* -------------------------------------------- */

  /**
   * Invert the roll's formula, resulting in a formula whose total, if multiplied by -1, will be the same as
   * the evaluated total of the original formula.
   * @returns {BasicRoll}
   */
  invert() {
    // Add "0 +" to the start of formulas that don't begin with a numeric term
    if ( !(this.terms[0] instanceof foundry.dice.terms.NumericTerm) ) this.terms.unshift(
      new foundry.dice.terms.NumericTerm({ number: 0 }),
      new foundry.dice.terms.OperatorTerm({ operator: "+" })
    );

    // Otherwise remove "0 -" from formulas that start with that
    else if ( (this.terms[0]?.number === 0) && (this.terms[1]?.operator === "-") ) this.terms.splice(0, 2);

    // Starting numeric terms should be directly inverted
    if ( this.terms[0] instanceof foundry.dice.terms.NumericTerm ) this.terms[0].number *= -1;

    // Invert all addition & subtraction operators
    this.terms = this.terms.map((term, index) => {
      if ( term instanceof foundry.dice.terms.OperatorTerm ) {
        if ( term.operator === "+" ) term.operator = "-";
        else if ( term.operator === "-" ) term.operator = "+";
      }
      return term;
    });

    if ( this._evaluated ) this._total *= -1;
    this.resetFormula();
    return this;
  }

  /* -------------------------------------------- */
  /*  Maximize/Minimize Methods                   */
  /* -------------------------------------------- */

  /**
   * Replaces all dice or pool terms that have modifiers with their maximum/minimum value.
   * @param {object} [options={}]            Extra optional arguments which describe or modify the BasicRoll.
   */
  preCalculateDiceTerms(options={}) {
    if ( this._evaluated || (!options.maximize && !options.minimize) ) return;
    this.terms = this.terms.map(term => {
      if ( (term instanceof DiceTerm || term instanceof PoolTerm) && term.modifiers.length ) {
        const minimize = !options.maximize;
        const fn = term instanceof DiceTerm ? "preCalculateTerm" : "preCalculatePoolTerm";
        const number = this.constructor[fn](term, { minimize });
        if ( Number.isFinite(number) ) return new NumericTerm({ number, options: term.options });
      }
      return term;
    });
  }

  /* -------------------------------------------- */

  /**
   * Synchronously apply a term's result-selection modifiers to its already-populated results by dispatching to the
   * term's own modifier handlers. Asynchronous handlers are skipped, as they cannot be awaited on this synchronous
   * path. Reroll and advantage/disadvantage could not change a forced extreme in any case, but explosion could (its
   * maximum is unbounded).
   * @param {DiceTerm|PoolTerm} term  Term whose results have been populated with their maximum or minimum faces.
   * @internal
   */
  static _applyMaxMinModifiers(term) {
    const cls = term.constructor;
    const union = Object.keys(cls.MODIFIERS).sort((a, b) => b.length - a.length).join("|");
    const pattern = new RegExp(`(${union})[^A-z\\s()+\\-*/]*`, "gi");
    for ( const sequence of term.modifiers.map(m => m.toLowerCase()) ) {
      for ( const [matched, command] of sequence.matchAll(pattern) ) {
        let fn = cls.MODIFIERS[command];
        if ( typeof fn === "string" ) fn = term[fn];
        if ( (typeof fn === "function") && !(fn instanceof foundry.utils.AsyncFunction) ) fn.call(term, matched);
      }
    }
  }

  /* -------------------------------------------- */

  /**
   * Calculate the maximum or minimum value that could be rolled by a dice term, honoring all of its modifiers by
   * populating its results with the extreme face value and then delegating to the term's real modifier handlers.
   * @param {DiceTerm} die                                  DiceTerm to get the maximum/minimum value.
   * @param {object} [preCalculateOptions={}]               Additional options to modify preCalculate functionality.
   * @param {boolean} [preCalculateOptions.minimize=false]  Calculate the minimum value instead of the maximum.
   * @returns {number|null}                                 Maximum/Minimum value that could be rolled as an integer, or
   *                                                        null if the term could not be precalculated.
   */
  static preCalculateTerm(die, { minimize=false }={}) {
    if ( !die.modifiers.length || !Number.isFinite(die.number) || !Number.isFinite(die.faces) ) return null;
    for ( let n = die.results.length; n < Math.abs(die.number); n++ ) {
      die.results.push({ active: true, result: minimize ? Math.min(1, die.faces) : die.faces });
    }
    die._evaluated = true;
    this._applyMaxMinModifiers(die);
    return die.total;
  }

  /* -------------------------------------------- */

  /**
   * Calculate the maximum or minimum value that could be rolled by a pool term, honoring all of its modifiers by
   * evaluating the pool at its extreme and then delegating to the term's real modifier handlers.
   * @param {PoolTerm} pool                                 PoolTerm to get the maximum/minimum value.
   * @param {object} [preCalculateOptions={}]               Additional options to modify preCalculate functionality.
   * @param {boolean} [preCalculateOptions.minimize=false]  Calculate the minimum value instead of the maximum.
   * @returns {number|null}                                 Maximum/Minimum value that could be rolled as an integer, or
   *                                                        null if the term could not be precalculated.
   */
  static preCalculatePoolTerm(pool, { minimize=false }={}) {
    pool.evaluate({ maximize: !minimize, minimize });
    this._applyMaxMinModifiers(pool);
    return pool.total;
  }

  /* -------------------------------------------- */
  /*  Simplification Methods                      */
  /* -------------------------------------------- */

  /**
   * Replace number and faces of dice terms with numeric values where possible.
   * @returns {this}
   */
  simplify() {
    for ( const die of this.dice ) {
      const n = die._number;
      if ( (n instanceof BasicRoll) && n.isDeterministic ) die._number = n.evaluateSync().total;
      const f = die._faces;
      if ( (f instanceof BasicRoll) && f.isDeterministic ) die._faces = f.evaluateSync().total;

      // Preserve flavor.
      if ( f.terms?.[0]?.flavor ) die.options.flavor = f.terms[0].flavor;
    }

    this.resetFormula();
    return this;
  }

  /* -------------------------------------------- */
  /*  Helpers                                     */
  /* -------------------------------------------- */

  /**
   * Retrieve the message mode to use, treating in-character as public by default.
   * @param {boolean} [ignoreIC=true]  Ignore in-character message mode.
   * @returns {string}}
   */
  static getMessageMode(ignoreIC=true) {
    const mode = game.settings.get("core", "messageMode");
    return ignoreIC && (mode === "ic") ? "public" : mode;
  }

  /* -------------------------------------------- */

  /**
   * Merge two roll configurations in place.
   * @param {Partial<BasicRollConfiguration>} original  The initial configuration that will be merged into.
   * @param {Partial<BasicRollConfiguration>} other     The configuration to merge.
   * @returns {Partial<BasicRollConfiguration>}         The original instance.
   */
  static mergeConfigs(original, other={}) {
    if ( other.data ) {
      original.data ??= {};
      Object.assign(original.data, other.data);
    }

    if ( other.parts?.length ) {
      original.parts ??= [];
      original.parts.unshift(...other.parts);
    }

    if ( other.options ) {
      original.options = this.mergeOptions(original.options, other.options);
    }

    return original;
  }

  /* -------------------------------------------- */

  /**
   * Merge two roll options objects.
   * @param {Partial<BasicRollOptions>} [original]  The initial options that will be merged into.
   * @param {Partial<BasicRollOptions>} [other]     The options to merge.
   * @returns {Partial<BasicRollOptions>}           The merged version.
   */
  static mergeOptions(original={}, other={}) {
    return foundry.utils.mergeObject(original, other, { inplace: false });
  }
}

import { defaultUnits, formatLength, splitSemicolons } from "../../../utils.mjs";
import FormulaField from "../../fields/formula-field.mjs";
import MappingField from "../../fields/mapping-field.mjs";
import ActorSizeField from "../fields/actor-size-field.mjs";
import DamageTraitField from "../fields/damage-trait-field.mjs";
import SimpleTraitField from "../fields/simple-trait-field.mjs";

const { NumberField, SchemaField, SetField, StringField } = foundry.data.fields;

/**
 * @import { TraitsCommonData, TraitsCreatureData } from "./_types.mjs";
 */

/**
 * Shared contents of the traits schema between various actor types.
 */
export default class TraitsField {
  /**
   * Fields shared between characters, NPCs, and vehicles.
   * @type {TraitsCommonData}
   */
  static get common() {
    return {
      size: new ActorSizeField({ required: true, initial: "med", label: "DND5E.Size" }),
      di: new DamageTraitField({}, { label: "DND5E.TRAIT.Damage.Immunity.title" }),
      dr: new DamageTraitField({}, { label: "DND5E.TRAIT.Damage.Resistance.title" }),
      dv: new DamageTraitField({}, { label: "DND5E.TRAIT.Damage.Vulnerability.title" }),
      dm: new SchemaField({
        amount: new MappingField(
          new FormulaField({ deterministic: true, labelFormatter: "DND5E.DamageModification.Formatter" }),
          {
            label: "DND5E.TRAIT.Damage.Modification.title", labels: { value: "DND5E.TRAIT.Damage.Modification.title" },
            entryLabel: key => CONFIG.DND5E.damageTypes[key]?.label
          }
        ),
        bypasses: new SetField(new StringField(), {
          label: "DND5E.DAMAGE.PhysicalBypass.Label", hint: "DND5E.DAMAGE.PhysicalBypass.Hint"
        })
      }),
      ci: new SimpleTraitField({}, { label: "DND5E.TRAIT.Condition.Immunity.title" })
    };
  }

  /* -------------------------------------------- */

  /**
   * Fields shared between characters and NPCs.
   * @type {TraitsCreatureData}
   */
  static get creature() {
    return {
      languages: new SimpleTraitField({
        communication: new MappingField(new SchemaField({
          units: new StringField({ initial: () => defaultUnits("length") }),
          value: new NumberField({ required: true, min: 0 })
        }))
      }, { label: "DND5E.Languages" })
    };
  }

  /* -------------------------------------------- */
  /*  Data Preparation                            */
  /* -------------------------------------------- */

  /**
   * Prepare the language labels.
   * @this {CharacterData|NPCData}
   */
  static prepareLanguages() {
    const languages = this.traits.languages;
    const labels = languages.labels = { languages: [], ranged: [] };

    if ( languages.value.has("ALL") ) labels.languages.push(_loc("DND5E.Language.All"));
    else {
      const processCategory = (key, data, group) => {
        // If key is within languages, don't bother with children
        if ( languages.value.has(key) ) (group?.children ?? labels.languages).push(data.label ?? data);

        // Display children as part of this group (e.g. "Primordial (Ignan)")
        else if ( data.children && (data.selectable !== false) ) {
          const topLevel = group === undefined;
          group ??= { label: data.label, children: [] };
          Object.entries(data.children).forEach(([k, d]) => processCategory(k, d, group));
          if ( topLevel && group.children.length ) labels.languages.push(
            `${data.label} (${game.i18n.getListFormatter({ type: "unit" }).format(group.children)})`
          );
        }

        // Display children alone if category isn't selectable
        else if ( data.children ) Object.entries(data.children).forEach(([k, d]) => processCategory(k, d));
      };

      for ( const [key, data] of Object.entries(CONFIG.DND5E.languages) ) {
        if ( data.children ) Object.entries(data.children).forEach(([k, d]) => processCategory(k, d));
        else processCategory(key, data);
      }
    }

    labels.languages.push(...splitSemicolons(languages.custom));

    for ( const [key, { label }] of Object.entries(CONFIG.DND5E.communicationTypes) ) {
      const data = languages.communication?.[key];
      if ( !data?.value ) continue;
      labels.ranged.push(`${label} ${formatLength(data.value, data.units)}`);
    }
  }

  /* -------------------------------------------- */

  /**
   * Prepare condition immunities & petrified condition and handle "All Damage" value.
   * @this {CharacterData|NPCData|VehicleData}
   */
  static prepareResistImmune() {
    // Apply condition immunities
    for ( const condition of this.traits.ci.value ) this.parent.statuses.delete(condition);

    // Apply petrified condition
    if ( this.parent.hasConditionEffect("petrification") ) {
      this.traits.dr.value.add("ALL");
      this.traits.dr.bypasses.clear();
      this.traits.di.value.add("poison");
      this.traits.ci.value.add("poisoned");
      this.traits.ci.value.add("diseased");
    }

    // Clear other damage resistances/immunities/vulnerabilities if All is set
    for ( const key of ["dr", "di", "dv"] ) {
      const entry = this.traits[key];
      if ( entry.value.has("ALL") ) {
        entry.value.clear();
        entry.value.add("ALL");
        if ( key === "di" ) this.traits.dr.value.clear();
      }
      else if ( key === "di" ) entry.value.forEach(k => this.traits.dr.value.delete(k));
    }
  }

  /* -------------------------------------------- */
  /*  Socket Event Handlers                       */
  /* -------------------------------------------- */

  /**
   * Update the prototype token size for newly created actors.
   * @this {CharacterData|NPCData|VehicleData}
   * @param {object} data     The initial data object provided to the document creation request.
   * @param {object} options  Additional options which modify the creation request.
   */
  static async preCreateSize(data, options) {
    if ( this.parent._stats?.compendiumSource?.startsWith("Compendium.") ) return;
    const prototypeToken = {};
    if ( "size" in this.traits ) {
      const size = CONFIG.DND5E.actorSizes[this.traits.size || "med"].token ?? 1;
      if ( !foundry.utils.hasProperty(data, "prototypeToken.width") ) prototypeToken.width = size;
      if ( !foundry.utils.hasProperty(data, "prototypeToken.height") ) prototypeToken.height = size;
    }
    this.parent.updateSource({ prototypeToken });
  }

  /* -------------------------------------------- */

  /**
   * Update the prototype token size when the actor size is changed.
   * @this {CharacterData|NPCData|VehicleData}
   * @param {object} changes  The candidate changes to the Document.
   * @param {object} options  Additional options which modify the update request.
   */
  static async preUpdateSize(changes, options) {
    const newSize = foundry.utils.getProperty(changes, "system.traits.size");
    if ( !dnd5e.settings.tokenSizeSync || !newSize || (newSize === this.traits.size)
      || foundry.utils.hasProperty(changes, "prototypeToken.width") ) return;
    const size = CONFIG.DND5E.actorSizes[newSize].token ?? 1;
    changes.prototypeToken ??= {};
    changes.prototypeToken.height = size;
    changes.prototypeToken.width = size;
  }
}

import { bulkFromUuid } from "../../utils.mjs";
import FormulaField from "../fields/formula-field.mjs";
import GroupTemplate from "./templates/group.mjs";

const { ArrayField, DocumentUUIDField, NumberField, SchemaField } = foundry.data.fields;

/**
 * @import { EncounterPlacementSettingData } from "../settings/_types.mjs";
 * @import { EncounterActorSystemData } from "./_types.mjs";
 */

/**
 * An Actor that represents a collection of adversaries.
 * @extends {GroupTemplate<EncounterActorSystemData>}
 * @mixes EncounterActorSystemData
 */
export default class EncounterData extends GroupTemplate {
  /** @inheritDoc */
  static defineSchema() {
    return this.mergeSchema(super.defineSchema(), {
      members: new ArrayField(new SchemaField({
        uuid: new DocumentUUIDField({ type: "Actor" }),
        quantity: new SchemaField({
          value: new NumberField({ initial: 1, integer: true, min: 0, label: "DND5E.Quantity" }),
          formula: new FormulaField({ label: "DND5E.QuantityFormula" })
        })
      }), { label: "DND5E.Group.Member.other" })
    });
  }

  /* -------------------------------------------- */
  /*  Data Migration                              */
  /* -------------------------------------------- */

  /** @inheritDoc */
  static _migrateData(source) {
    super._migrateData(source);
    EncounterData.#migrateMembers(source);
    return source;
  }

  /* -------------------------------------------- */

  /**
   * Migrate group members from world IDs to UUIDs.
   * @param {object} source  The candidate source data from which the model will be constructed.
   */
  static #migrateMembers(source) {
    const { members } = source;
    if ( !members ) return;
    source.members = members.map(m => {
      if ( m.actor && !m.uuid ) {
        m.uuid = `Actor.${m.actor}`;
        delete m.actor;
      }
      return m;
    });
  }

  /* -------------------------------------------- */
  /*  Data Preparation                            */
  /* -------------------------------------------- */

  /** @inheritDoc */
  prepareBaseData() {
    super.prepareBaseData();
    Object.defineProperty(this.members, "uuids", {
      value: new Set(this.members.map(m => m.uuid)),
      enumerable: false,
      writable: false,
      configurable: true
    });
  }

  /* -------------------------------------------- */

  /** @inheritDoc */
  prepareDerivedData() {
    super.prepareDerivedData();
    this.prepareCurrency();
  }

  /* -------------------------------------------- */
  /*  Methods                                     */
  /* -------------------------------------------- */

  /**
   * Add new members to the group.
   * @param {...Actor5e} actors   The actors to add.
   * @returns {Promise<Actor5e>}  The updated encounter Actor.
   */
  async addMember(...actors) {
    const members = this.toObject().members;
    for ( const actor of actors ) {
      if ( !actor.system.isNPC ) throw new Error("Only NPC actors can be part of encounters.");
      let existing = false;
      for ( const member of members ) {
        if ( (member.uuid === actor.uuid) && member.quantity?.value ) {
          member.quantity.value++;
          existing = true;
        }
      }
      if ( !existing ) members.push({ uuid: actor.uuid });
    }
    return this.parent.update({ "system.members": members });
  }

  /* -------------------------------------------- */

  /**
   * Get the difficulty for this encounter for a given party.
   * @param {Actor5e} [party]  A party to determine difficulty against, otherwise it uses the world's primary party.
   * @returns {Promise<"low"|"moderate"|"high"|null>}
   */
  async getDifficulty(party) {
    party ??= game.actors.party;
    if ( party?.type !== "group" ) return null;
    const xp = await this.getXPValue();
    const { creatures, level } = party.system;
    const [low, med] = (CONFIG.DND5E.ENCOUNTER_DIFFICULTY[level] ?? []).map(t => t * creatures.length);
    if ( !low ) return null;
    if ( xp <= low ) return "low";
    else if ( xp <= med ) return "moderate";
    return "high";
  }

  /* -------------------------------------------- */

  /** @override */
  async getMembers() {
    const members = await bulkFromUuid(this.members.map(m => m.uuid));
    return this.members.map(data => ({
      actor: members.get(data.uuid), ...foundry.utils.deepClone(data)
    })).filter(d => d.actor);
  }

  /* -------------------------------------------- */

  /** @override */
  async getPlaceableMembers() {
    return (await Promise.all((await this.getMembers()).map(async member => {
      const fetchOptions = { folderId: this.parent.folder?.id ?? null };
      member.actor = await dnd5e.documents.Actor5e.fetchExisting(member.actor.uuid, fetchOptions);
      if ( (member.quantity.value === null) && member.quantity.formula ) {
        const roll = new Roll(member.quantity.formula);
        await roll.evaluate();
        if ( roll.total > 0 ) member.quantity.value = roll.total;
      }
      return member;
    }))).filter(m => m.quantity.value);
  }

  /* -------------------------------------------- */

  /**
   * Place all members in the encounter on the current scene and return the associated token documents.
   * @param {object} [config]                                        Configuration options for the encounter placement.
   * @param {EncounterPlacementSettingData} [config.combatBehavior]  Combat tracker options for the placed tokens.
   * @returns {Promise<TokenDocument[]>}
   */
  async placeMembers(config={}) {
    const tokenDocuments = await super.placeMembers();
    config.combatBehavior ??= game.settings.get("jujutsu-system", "encounterPlacementBehavior");
    if ( tokenDocuments.length && (config.combatBehavior !== "none") ) {
      const combatants = await TokenDocument.implementation.createCombatants(tokenDocuments);
      if ( config.combatBehavior === "rollInitiative" ) {
        await game.combats.viewed.rollInitiative(combatants.map(c => c.id));
      }
    }
    return tokenDocuments;
  }

  /* -------------------------------------------- */

  /**
   * Get the XP value of this encounter.
   * @returns {Promise<number>}
   */
  async getXPValue() {
    return (await this.getMembers()).reduce((xp, { actor, quantity }) => {
      return xp + ((quantity.value ?? 0) * (actor?.system.details?.xp?.value ?? 0));
    }, 0);
  }

  /* -------------------------------------------- */

  /**
   * Remove a member from the group.
   * @param {Actor5e|string} actor  An actor or its UUID to remove from this group.
   * @returns {Promise<Actor5e>}    The updated encounter Actor.
   */
  async removeMember(actor) {
    const uuid = typeof actor === "string" ? actor : actor.uuid;
    if ( !this.members.uuids.has(uuid) ) return this.parent;
    const members = this.toObject().members;
    return this.parent.update({ "system.members": members.filter(m => m.uuid !== uuid) });
  }

  /* -------------------------------------------- */

  /**
   * Roll the quantity formulas for each member and replace their quantity. Any entries without formulas
   * will not be modified.
   * @param {object} [options={}]
   * @param {number} [options.index]  Index of a specific member to roll.
   * @returns {Promise<Actor5e>}
   */
  async rollQuantities({ index }={}) {
    const membersCollection = this.toObject().members;
    await Promise.all(membersCollection.map(async (member, i) => {
      if ( !member.quantity?.formula || ((index !== undefined) && (index !== i)) ) return member;
      const roll = new Roll(member.quantity.formula);
      await roll.evaluate();
      if ( roll.total > 0 ) member.quantity.value = roll.total;
    }));
    return this.parent.update({ "system.members": membersCollection });
  }
}

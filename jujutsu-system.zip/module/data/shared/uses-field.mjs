import { ScaleValueTypeUsage } from "../../data/advancement/scale-value-data.mjs";
import { formatNumber, formatRange, getPluralRules, prepareFormulaValue, rollModeAtual } from "../../utils.mjs";
import FormulaField from "../fields/formula-field.mjs";

const { ArrayField, NumberField, SchemaField, StringField } = foundry.data.fields;

/**
 * @import {
 *   BasicRollDialogConfiguration, BasicRollMessageConfiguration, RechargeRollProcessConfiguration
 * } from "../../dice/_types.mjs";
 * @import { ActivityRollData, ActorRollData, ItemRollData } from "../../documents/_types.mjs";
 */

/**
 * Field for storing uses data.
 */
export default class UsesField extends SchemaField {
  constructor(fields={}, options={}) {
    fields = {
      spent: new NumberField({ initial: 0, min: 0, integer: true }),
      max: new FormulaField({ deterministic: true }),
      recovery: new ArrayField(
        new SchemaField({
          period: new StringField({ required: true, initial: "lr", blank: false }),
          type: new StringField({ required: true, initial: "recoverAll", blank: false }),
          formula: new FormulaField()
        })
      ),
      ...fields
    };
    super(fields, options);
  }

  /* -------------------------------------------- */
  /*  Data Preparation                            */
  /* -------------------------------------------- */

  /**
   * Prepare data for this field. Should be called during the `prepareFinalData` stage.
   * @this {ItemDataModel|BaseActivityData}
   * @param {ItemRollData|ActivityRollData} rollData  Roll data used for formula replacements.
   * @param {object} [labels]                         Object in which to insert generated labels.
   */
  static prepareData(rollData, labels) {
    prepareFormulaValue(this, "uses.max", "DND5E.USES.FIELDS.uses.max.label", rollData);
    this.uses.value = this.uses.max ? Math.clamp(this.uses.max - this.uses.spent, 0, this.uses.max) : 0;

    const periods = [];
    for ( const recovery of this.uses.recovery ) {
      recovery.isScaleValue = recovery.period.startsWith("@scale");
      if ( recovery.isScaleValue ) {
        const scaleValue = foundry.utils.getProperty(rollData, recovery.period.slice(1));
        if ( scaleValue?.period ) recovery.period = scaleValue.period;
      }

      if ( recovery.period === "recharge" ) {
        recovery.formula ??= "6";
        recovery.type = "recoverAll";
        recovery.recharge = { options: UsesField.rechargeOptions };
        if ( labels ) labels.recharge ??= `${_loc("DND5E.Recharge")} [${
          recovery.formula}${parseInt(recovery.formula) < 6 ? "+" : ""}]`;
      } else if ( recovery.period in CONFIG.DND5E.limitedUsePeriods ) {
        const config = CONFIG.DND5E.limitedUsePeriods[recovery.period];
        periods.push(config.abbreviation ?? config.label);
      }
    }
    if ( labels ) labels.recovery = game.i18n.getListFormatter({ style: "narrow" }).format(periods);

    this.uses.label ??= UsesField.getStatblockLabel.call(this);

    Object.defineProperty(this.uses, "rollRecharge", {
      value: UsesField.rollRecharge.bind(this.parent?.system ? this.parent : this),
      configurable: true
    });
  }

  /* -------------------------------------------- */

  /**
   * Recharge range options.
   * @returns {FormSelectOption[]}
   */
  static get rechargeOptions() {
    return Array.fromRange(5, 2).reverse().map(min => ({
      value: min,
      label: _loc("DND5E.USES.Recovery.Recharge.Range", {
        range: min === 6 ? formatNumber(6) : formatRange(min, 6)
      })
    }));
  }

  /* -------------------------------------------- */

  /**
   * Recovery options for an item.
   * @param {Item5e} item   Item for which the recovery options will be created.
   * @param {string} value  Current recovery value.
   * @returns {FormSelectOption[]|null}
   */
  static recoveryOptions(item, value) {
    // For non-embedded items with a scale value, just show text input
    if ( !item.isEmbedded && value.startsWith("@scale") ) return null;
    const recoveryOptions = CONFIG.DND5E.limitedUsePeriods.recoveryOptions;

    // For embedded items, build a list of uses scale values to display
    if ( item.isEmbedded ) {
      const usesScaleValues = [];
      for ( const [itemIdentifier, scaleValues] of Object.entries(item.actor.system.scale ?? {}) ) {
        for ( const [scaleIdentifier, scaleValue] of Object.entries(scaleValues) ) {
          if ( scaleValue instanceof ScaleValueTypeUsage ) usesScaleValues.push({
            value: `@scale.${itemIdentifier}.${scaleIdentifier}`,
            label: scaleValue.parent.title
          });
        }
      }
      if ( value.startsWith("@scale") && !usesScaleValues.find(s => s.value === value) ) return null;
      recoveryOptions.push(
        { rule: true },
        ...usesScaleValues.sort((lhs, rhs) => lhs.label.localeCompare(rhs.label, game.i18n.lang))
      );
    }

    // Not embedded, just show single Scale Value option that transform input into freeform text box
    else {
      recoveryOptions.push(
        { rule: true },
        { value: "@scale", label: _loc("DND5E.ADVANCEMENT.ScaleValue.Title") }
      );
    }

    return recoveryOptions;
  }

  /* -------------------------------------------- */

  /**
   * Create a label for uses data that matches the style seen on NPC stat blocks. Complex recovery data might result
   * in no label being generated if it doesn't represent recovery that can be normally found on a NPC.
   * @this {ItemDataModel|BaseActivityData}
   * @returns {string}
   */
  static getStatblockLabel() {
    // Legendary/Mythic Actions
    if ( (this.activation?.type === "legendary") || (this.activation?.type === "mythic") ) {
      if ( this.activation.value < 2 ) return "";
      const pr = getPluralRules();
      return _loc(`DND5E.NPC.ActionCostCounted.${pr.select(this.activation.value)}`, {
        number: formatNumber(this.activation.value)
      });
    }

    if ( !this.uses.max || (this.uses.recovery.length !== 1) ) return "";
    const recovery = this.uses.recovery[0];

    // Ignore combat & special recovery periods
    const type = CONFIG.DND5E.limitedUsePeriods[recovery.period]?.type;
    if ( (type === "combat") || (type === "special") ) return "";

    // Recharge X–Y
    if ( recovery.period === "recharge" ) {
      const value = parseInt(recovery.formula);
      return `${_loc("DND5E.Recharge")} ${value === 6 ? "6" : `${value}–6`}`;
    }

    // Recharge after a Short or Long Rest
    if ( ["lr", "sr"].includes(recovery.period) && (this.uses.max === 1) ) {
      return _loc(`DND5E.Recharge${recovery.period === "sr" ? "Short" : "Long"}`);
    }

    // X/Day
    const period = CONFIG.DND5E.limitedUsePeriods[recovery.period === "sr" ? "sr" : "day"]?.label ?? "";
    if ( !period ) return "";
    return `${this.uses.max}/${period}`;
  }

  /* -------------------------------------------- */
  /*  Helpers                                     */
  /* -------------------------------------------- */

  /**
   * Determine uses recovery.
   * @this {ItemDataModel|BaseActivityData}
   * @param {Map<string, number>} periods            Recovery periods to check, mapped to the number of times occurred.
   * @param {ActorRollData|ItemRollData} [rollData]  Roll data to use when evaluating recovery formulas.
   * @returns {Promise<{ updates: object, rolls: BasicRoll[] }|false>}
   */
  static async recoverUses(periods, rollData={}) {
    if ( foundry.utils.getType(periods) === "Array" ) {
      foundry.utils.logCompatibilityWarning(
        "The periods parameter of `recoverUses` is now a mapping of periods to times triggered.",
        { since: "DnD5e 6.0", until: "DnD5e 6.2" }
      );
      periods = new Map(periods.map(p => [p, 1]));
    }

    if ( !this.uses?.recovery.length ) return false;

    // Search the recovery profiles in order to find the first matching period,
    // and then find the first profile that uses that recovery period
    let count;
    let profile;
    findPeriod: {
      for ( const [period, periodCount] of periods.entries() ) {
        if ( periodCount < 1 ) continue;
        for ( const recovery of this.uses.recovery ) {
          if ( recovery.period === period ) {
            count = periodCount;
            profile = recovery;
            break findPeriod;
          }
        }
      }
    }
    if ( !profile ) return false;

    const updates = {};
    const rolls = [];
    const item = this.item ?? this.parent;

    if ( profile.type === "recoverAll" ) {
      if ( this.uses.spent !== 0 ) updates.spent = 0;
    } else if ( profile.type === "loseAll" ) {
      if ( this.uses.spent !== this.uses.max ) updates.spent = this.uses.max;
    } else if ( profile.formula ) {
      let roll;
      let total;
      try {
        const delta = this.parent instanceof Item
          ? { item: this.parent.id, itemUuid: this.parent.uuid, keyPath: "system.uses.spent" }
          : { item: this.item.id, itemUuid: this.item.uuid, keyPath: `system.activities.${this.id}.uses.spent` };
        roll = new CONFIG.Dice.BasicRoll(profile.formula, rollData, { delta });
        if ( count > 1 ) {
          const minRoll = await roll.clone().evaluate({ minimize: true });
          roll.alter(Math.min(count, Math.ceil(this.uses.max / (minRoll.total || 1))), 0, { multiplyNumeric: true });
        }
        total = (await roll.evaluate()).total;
      } catch (err) {
        Hooks.onError("UsesField#recoverUses", err, {
          msg: _loc("DND5E.ItemRecoveryFormulaWarning", {
            name: item.name, formula: profile.formula, uuid: this.uuid ?? item.uuid
          }),
          log: "error",
          notify: "error"
        });
        return false;
      }

      const newSpent = Math.clamp(this.uses.spent - total, 0, this.uses.max);
      if ( newSpent !== this.uses.spent ) {
        updates.spent = newSpent;
        if ( !roll.isDeterministic ) rolls.push(roll);
      }
    }

    return foundry.utils.isEmpty(updates) ? false : { updates, rolls };
  }

  /* -------------------------------------------- */

  /**
   * Rolls a recharge test for an Item or Activity that uses the d6 recharge mechanic.
   * @this {Item5e|Activity}
   * @param {RechargeRollProcessConfiguration} config  Configuration information for the roll.
   * @param {BasicRollDialogConfiguration} dialog      Configuration for the roll dialog.
   * @param {BasicRollMessageConfiguration} message    Configuration for the roll message.
   * @returns {Promise<BasicRoll[]|{ rolls: BasicRoll[], updates: object }|void>}  The created Roll instances, update
   *                                                                               data, or nothing if not rolled.
   */
  static async rollRecharge(config={}, dialog={}, message={}) {
    const uses = this.system ? this.system.uses : this.uses;
    const recharge = uses?.recovery.find(({ period }) => period === "recharge");
    if ( !recharge || !uses?.spent ) return;

    const rollConfig = foundry.utils.mergeObject({
      rolls: [{
        parts: ["1d6"],
        data: this.getRollData(),
        options: {
          delta: this instanceof Item ? { item: this.id, keyPath: "system.uses.spent" }
            : { item: this.item.id, keyPath: `system.activities.${this.id}.uses.spent` },
          target: parseInt(recharge.formula)
        }
      }]
    }, config);
    rollConfig.hookNames = [...(config.hookNames ?? []), "recharge"];
    rollConfig.subject = this;

    const dialogConfig = foundry.utils.mergeObject({ configure: false }, dialog);

    const sources = this instanceof Item ? {
      item: {
        compendiumSource: this._stats?.compendiumSource, id: this.id, img: this.img, name: this.name, type: this.type,
        uuid: this.uuid
      }
    } : this.messageSources;
    const messageConfig = foundry.utils.mergeObject({
      create: true,
      data: {
        speaker: ChatMessage.getSpeaker({ actor: this.actor, token: this.actor.token }),
        system: sources,
        type: "recharge"
      },
      rollMode: rollModeAtual()
    }, message);

    const rolls = await CONFIG.Dice.BasicRoll.buildConfigure(rollConfig, dialogConfig, messageConfig);
    await CONFIG.Dice.BasicRoll.buildEvaluate(rolls, rollConfig, messageConfig);
    if ( !rolls.length ) return;
    messageConfig.data.flavor = _loc("DND5E.ItemRechargeCheck", {
      name: this.name,
      result: _loc(`DND5E.ItemRecharge${rolls[0].isSuccess ? "Success" : "Failure"}`)
    });
    await CONFIG.Dice.BasicRoll.buildPost(rolls, rollConfig, messageConfig);

    const updates = {};
    if ( rolls[0].isSuccess ) {
      if ( this instanceof Item ) updates["system.uses.spent"] = 0;
      else updates["uses.spent"] = 0;
    }

    /**
     * A hook event that fires after an Item or Activity has rolled to recharge, but before any usage changes have
     * been made.
     * @function dnd5e.rollRecharge
     * @memberof hookEvents
     * @param {BasicRoll[]} rolls             The resulting rolls.
     * @param {object} data
     * @param {Item5e|Activity} data.subject  Item or Activity for which the roll was performed.
     * @param {object} data.updates           Updates to be applied to the subject.
     * @returns {boolean}                     Explicitly return `false` to prevent updates from being performed.
     */
    if ( Hooks.call("dnd5e.rollRecharge", rolls, { subject: this, updates }) === false ) return rolls;
    if ( Hooks.call("dnd5e.rollRechargeV2", rolls, { subject: this, updates }) === false ) return rolls;

    if ( (rollConfig.apply !== false) && !foundry.utils.isEmpty(updates) ) await this.update(updates);

    /**
     * A hook event that fires after an Item or Activity has rolled recharge and usage updates have been performed.
     * @function dnd5e.postRollRecharge
     * @memberof hookEvents
     * @param {BasicRoll[]} rolls     The resulting rolls.
     * @param {object} data
     * @param {Actor5e} data.subject  Item or Activity for which the roll was performed.
     */
    Hooks.callAll("dnd5e.postRollRecharge", rolls, { subject: this });

    return { rolls, updates };
  }
}

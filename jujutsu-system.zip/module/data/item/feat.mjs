import { formatNumber } from "../../utils.mjs";
import ItemDataModel from "../abstract/item-data-model.mjs";
import FormulaField from "../fields/formula-field.mjs";
import IdentifierField from "../fields/identifier-field.mjs";
import ActivitiesTemplate from "./templates/activities.mjs";
import AdvancementTemplate from "./templates/advancement.mjs";
import ItemDescriptionTemplate from "./templates/item-description.mjs";
import ItemTypeTemplate from "./templates/item-type.mjs";
import ItemTypeField from "./fields/item-type-field.mjs";

const { BooleanField, NumberField, SchemaField, SetField, StringField } = foundry.data.fields;

/**
 * @import { FeatItemSystemData } from "./_types.mjs";
 * @import {
 *   ActivitiesTemplateData, AdvancementTemplateData, ItemDescriptionTemplateData, ItemTypeTemplateData
 * } from "./templates/_types.mjs";
 */

/**
 * Data definition for Feature items.
 * @extends {ItemDataModel<
 *   ActivitiesTemplate & AdvancementTemplate & ItemDescriptionTemplate & ItemTypeTemplate & FeatItemSystemData
 * >}
 * @mixes ActivitiesTemplateData
 * @mixes AdvancementTemplateData
 * @mixes ItemDescriptionTemplateData
 * @mixes ItemTypeTemplateData
 * @mixes FeatItemSystemData
 */
export default class FeatData extends ItemDataModel.mixin(
  ActivitiesTemplate, AdvancementTemplate, ItemDescriptionTemplate, ItemTypeTemplate
) {

  /* -------------------------------------------- */
  /*  Model Configuration                         */
  /* -------------------------------------------- */

  /** @override */
  static LOCALIZATION_PREFIXES = ["DND5E.FEATURE", "DND5E.Prerequisites", "DND5E.SOURCE"];

  /* -------------------------------------------- */

  /** @inheritDoc */
  static defineSchema() {
    return this.mergeSchema(super.defineSchema(), {
      cover: new NumberField({ min: 0, max: 1 }),
      crewed: new BooleanField(),
      enchant: new SchemaField({
        max: new FormulaField({ deterministic: true }),
        period: new StringField()
      }),
      prerequisites: new SchemaField({
        items: new SetField(new IdentifierField({ allowType: true })),
        level: new NumberField({ integer: true, min: 0 }),
        repeatable: new BooleanField()
      }),
      properties: new SetField(new StringField()),
      requirements: new StringField({ required: true, nullable: true }),
      type: new ItemTypeField({ baseItem: false })
    });
  }

  /* -------------------------------------------- */

  /** @inheritDoc */
  static metadata = Object.freeze(foundry.utils.mergeObject(super.metadata, {
    enchantable: true,
    hasEffects: true
  }, { inplace: false }));

  /* -------------------------------------------- */

  /** @override */
  static get compendiumBrowserFilters() {
    return new Map([
      ["category", {
        label: "DND5E.ITEM.Category.Label",
        type: "set",
        config: {
          choices: CONFIG.DND5E.featureTypes,
          keyPath: "system.type.value"
        }
      }],
      ["subtype", {
        label: "DND5E.ItemFeatureType",
        type: "set",
        config: {
          choices: filters => {
            const { anyPositive, anyNegative } = Object.values(filters?.additional?.category ?? {}).reduce((o, v) => {
              o.anyPositive ||= v > 0;
              o.anyNegative ||= v < 0;
              return o;
            }, { anyPositive: false, anyNegative: false });
            return Object.entries(CONFIG.DND5E.featureTypes).reduce((obj, [type, config]) => {
              if ( anyPositive && (filters.additional.category[type] !== 1) ) return obj;
              if ( anyNegative && (filters.additional.category[type] < 0) ) return obj;
              for ( const [key, label] of Object.entries(config.subtypes ?? {}) ) obj[key] = label;
              return obj;
            }, {});
          },
          keyPath: "system.type.subtype"
        }
      }],
      ["properties", this.compendiumBrowserPropertiesFilter("feat")],
      ["abilityScoreImprovement", {
        label: "DND5E.ADVANCEMENT.AbilityScoreImprovement.Title",
        type: "set",
        config: {
          choices: CONFIG.DND5E.abilities
        },
        createFilter: (filters, value, def) => {
          const { include, exclude } = Object.entries(value).reduce((d, [key, value]) => {
            if ( value === 1 ) d.include.push(key);
            else if ( value === -1 ) d.exclude.push(key);
            return d;
          }, { include: [], exclude: [] });

          const makeFilter = values => ({
            o: "OR", v: [
              ...values.map(ability => ({
                k: "system.advancement", o: "has", v: { k: `configuration.fixed.${ability}`, o: "gt", v: 0 }
              })),
              {
                k: "system.advancement", o: "has", v: {
                  o: "AND", v: [
                    { k: "configuration.points", o: "gt", v: 0 },
                    { o: "NOT", v: { k: "configuration.locked", o: "hasall", v: values } }
                  ]
                }
              }
            ]
          });

          if ( include.length ) filters.push(makeFilter(include));
          if ( exclude.length ) filters.push({ o: "NOT", v: makeFilter(exclude) });
        }
      }]
    ]);
  }

  /* -------------------------------------------- */
  /*  Properties                                  */
  /* -------------------------------------------- */

  /** @override */
  get advancementClassLinked() {
    return this.type.value !== "feat";
  }

  /* -------------------------------------------- */

  /**
   * Properties displayed in chat.
   * @type {string[]}
   */
  get chatProperties() {
    return this.cardProperties;
  }

  /* -------------------------------------------- */

  /**
   * Properties displayed on the item card.
   * @type {string[]}
   */
  get cardProperties() {
    return this.requirements ? [{ type: "text", text: this.requirements }] : [];
  }

  /* -------------------------------------------- */

  /**
   * Does this feature represent a group of individual enchantments (e.g. the "Infuse Item" feature stores data about
   * all of the character's infusions).
   * @type {boolean}
   */
  get isEnchantmentSource() {
    return CONFIG.DND5E.featureTypes[this.type?.value]?.subtypes?.[this.type?.subtype]
      && (this.type?.subtype in CONFIG.DND5E.featureTypes.enchantment.subtypes);
  }

  /* -------------------------------------------- */

  /** @override */
  get hasProficiency() {
    return true;
  }

  /* -------------------------------------------- */

  /**
   * The proficiency multiplier for this item.
   * @returns {number}
   */
  get proficiencyMultiplier() {
    return 1;
  }

  /* -------------------------------------------- */
  /*  Data Migration                              */
  /* -------------------------------------------- */

  /** @inheritDoc */
  static _migrateData(source) {
    super._migrateData(source);
    FeatData.#migrateEnchantment(source);
    ActivitiesTemplate.migrateActivities(source);
    AdvancementTemplate.migrateAdvancement(source);
    FeatData.#migrateType(source);
    FeatData.#migrateRecharge(source);
    return source;
  }

  /* -------------------------------------------- */

  /**
   * Migrate enchantment data format.
   * @param {object} source  The candidate source data from which the model will be constructed.
   */
  static #migrateEnchantment(source) {
    if ( foundry.utils.getType(source.enchantment?.items) !== "Object" ) return;
    const { items } = source.enchantment;
    source.enchant ??= {};
    if ( "max" in items ) source.enchant.max = items.max;
    if ( "period" in items ) source.enchant.period = items.period;
    delete source.enchantment.items;
  }

  /* -------------------------------------------- */

  /**
   * Ensure feats have a type object.
   * @param {object} source The candidate source data from which the model will be constructed.
   */
  static #migrateType(source) {
    if ( !("type" in source) ) return;
    if ( !source.type ) source.type = {value: "", subtype: ""};
  }

  /* -------------------------------------------- */

  /**
   * Migrate 0 values to null.
   * @param {object} source The candidate source data from which the model will be constructed.
   */
  static #migrateRecharge(source) {
    if ( !("recharge" in source) ) return;
    const value = source.recharge.value;
    if ( (value === 0) || (value === "") ) source.recharge.value = null;
    else if ( (typeof value === "string") && Number.isNumeric(value) ) source.recharge.value = Number(value);
    if ( source.recharge.charged === null ) source.recharge.charged = false;
  }

  /* -------------------------------------------- */
  /*  Data Preparation                            */
  /* -------------------------------------------- */

  /** @inheritDoc */
  prepareDerivedData() {
    super.prepareDerivedData();
    this.prepareDescriptionData();

    if ( this.type.value ) {
      const config = CONFIG.DND5E.featureTypes[this.type.value];
      if ( config ) this.type.label = config.subtypes?.[this.type.subtype] ?? null;
      else this.type.label = _loc(CONFIG.Item.typeLabels.feat);
    }

    let label;
    const activation = this.activities.contents[0]?.activation.type;
    if ( activation === "legendary" ) label = _loc("DND5E.LegendaryAction.Label");
    if ( activation === "mythic" ) label = _loc("DND5E.MythicActionLabel");
    else if ( activation === "lair" ) label = _loc("DND5E.LAIR.Action.Label");
    else if ( activation === "action" && this.hasAttack ) label = _loc("DND5E.Attack");
    else if ( activation ) label = _loc("DND5E.Action");
    else label = _loc("DND5E.Passive");
    this.parent.labels ??= {};
    this.parent.labels.featType = label;
  }

  /* -------------------------------------------- */

  /** @inheritDoc */
  prepareFinalData() {
    this.prepareFinalActivityData(this.parent.getRollData({ deterministic: true }));
  }

  /* -------------------------------------------- */

  /** @inheritDoc */
  async getFavoriteData() {
    return foundry.utils.mergeObject(await super.getFavoriteData(), {
      subtitle: [this.parent.labels.activation, this.parent.labels.recovery],
      uses: this.hasLimitedUses ? this.getUsesData() : null
    });
  }

  /* -------------------------------------------- */

  /** @inheritDoc */
  async getSheetData(context) {
    context.subtitles = [
      { label: this.type.label },
      { label: this.parent.labels.featType },
      { label: this.requirements, value: this._source.requirements, field: this.schema.getField("requirements"),
        placeholder: "DND5E.Requirements" }
    ];

    context.parts = ["dnd5e.details-feat", "dnd5e.field-uses"];
    const itemTypes = CONFIG.DND5E.featureTypes[this._source.type.value];
    if ( itemTypes ) {
      context.itemType = itemTypes.label;
      context.itemSubtypes = itemTypes.subtypes;
    }
  }

  /* -------------------------------------------- */
  /*  Helpers                                     */
  /* -------------------------------------------- */

  /**
   * Validate the prerequisites specified on this item.
   * @param {Actor5e} actor                        Actor against which the prerequisites should be checked.
   * @param {object} [options={}]
   * @param {Item5e[]} [options.added]             Items that are pending addition to the Actor.
   * @param {number} [options.level]               Level to validate. Falls back to character level.
   * @param {Item5e[]} [options.removed]           Items that are pending removal from the Actor.
   * @param {boolean} [options.showMessage=false]  Show a UI message if the validation fails.
   * @param {boolean} [options.throwError=false]   Throw an error if validation fails.
   * @returns {true|string[]}  True if the item is valid or a list of invalid descriptions if validation failed.
   */
  assertPrerequisites(actor, {
    added=[], level=actor.system?.details?.level, removed=[], showMessage=false, throwError=false
  }={}) {
    const results = this.validatePrerequisites({ actor, added, level });
    const messages = [];

    if ( results.get("items")?.valid === false ) {
      messages.push(_loc("DND5E.Prerequisites.Warning.MissingItem", {
        items: game.i18n.getListFormatter({ type: "disjunction" }).format(
          Array.from(this.prerequisites.items).map(i => dnd5e.registry.items.get(i)?.name ?? i)
        )
      }));
    }

    if ( results.get("repeatable")?.valid === false ) {
      messages.push(_loc("DND5E.Prerequisites.Warning.NotRepeatable", { name: this.parent.name }));
    }

    if ( results.get("level")?.valid === false ) {
      messages.push(_loc("DND5E.Prerequisites.Warning.InvalidLevel", { level: this.prerequisites.level }));
    }

    if ( !messages.length ) return true;

    if ( showMessage || throwError ) {
      const message = _loc("DND5E.Prerequisites.Warning.Message", {
        actor: actor.name,
        requirements: game.i18n.getListFormatter().format(messages),
        type: _loc(CONFIG.Item.typeLabels[this.parent.type]).toLowerCase()
      });
      if ( showMessage ) ui.notifications.warn(message);
      if ( throwError ) throw new Error(message);
    }

    return messages;
  }

  /* -------------------------------------------- */

  /**
   * Validate the prerequisites specified on this item.
   * @param {object} [context={}]
   * @param {Actor5e} [context.actor]   Actor against which the prerequisites should be checked.
   * @param {Item5e[]} [context.added]  Items that are pending addition to the Actor.
   * @param {number} [context.level]    Level to validate. Falls back to character level if actor is provided.
   * @param {object} [_options={}]
   * @returns {PrerequisiteValidationResults}
   */
  validatePrerequisites(context={}, _options={}) {
    if ( context instanceof Actor ) {
      foundry.utils.logCompatibilityWarning(
        "`FeatData#validatePrerequisites` has been renamed `assertPrerequisites`.",
        { since: "DnD5e 6.0", until: "DnD5e 7.0" }
      );
      return this.assertPrerequisites(context, _options);
    }

    const { actor, added=[], level=actor?.system?.details?.level } = context;
    const prerequisites = new Map();
    const legacy = (this.source.rules === "2014") || (dnd5e.settings.rulesVersion === "legacy") ? "Legacy" : "";

    // If a feature has a level pre-requisite, make sure it is less than or equal to current level
    if ( Number.isFinite(this.prerequisites.level) ) prerequisites.set("level", {
      label: _loc(`DND5E.Prerequisites.FIELDS.prerequisites.level.display${legacy}`, {
        level: formatNumber(this.prerequisites.level),
        levelOrdinal: formatNumber(this.prerequisites.level, { ordinal: true })
      }),
      quiet: true,
      valid: Number.isFinite(level) ? level >= this.prerequisites.level : null
    });

    // If a feature has item pre-requisites, make sure the other items exist on the actor
    if ( this.prerequisites.items.size ) prerequisites.set("items", {
      label: _loc("DND5E.Prerequisites.FIELDS.prerequisites.items.display", {
        items: game.i18n.getListFormatter({ type: "disjunction" }).format(
          Array.from(this.prerequisites.items).map(i => dnd5e.registry.items.get(i)?.name ?? i)
        )
      }),
      valid: actor ? Array.from(this.prerequisites.items).some(i => actor.identifiedItems.get(i)?.size) : null
    });

    // Check to ensure the item doesn't already exist on actor if it is not repeatable
    if ( actor && !this.prerequisites.repeatable && actor.sourcedItems?.get(this.parent.uuid)?.size
      && !added.find(a => a.uuid === this.parent.uuid) ) prerequisites.set("repeatable", {
      label: _loc("DND5E.Prerequisites.FIELDS.prerequisites.repeatable.display"),
      valid: false
    });

    return prerequisites;
  }

  /* -------------------------------------------- */
  /*  Socket Event Handlers                       */
  /* -------------------------------------------- */

  /** @inheritDoc */
  async _preCreate(data, options, user) {
    if ( (await super._preCreate(data, options, user)) === false ) return false;

    // Set type as "Monster Feature" if created directly on a NPC
    if ( this.parent.actor?.system.isNPC && !foundry.utils.hasProperty(data, "system.type.value") ) {
      this.updateSource({ "type.value": "monster" });
    }
  }
}

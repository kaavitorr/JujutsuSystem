import { convertTime, formatNumber, formatTime, getPluralRules } from "../../utils.mjs";
import { IndividualDeltaField } from "../chat-message/fields/deltas-field.mjs";

/**
 * @import { CalendarFormattingContext, CalendarTimeDeltas, TimePassageData } from "./_types.mjs";
 */

/**
 * Extension of the core calendar with extra formatters.
 */
export default class CalendarData5e extends foundry.data.CalendarData {

  /* -------------------------------------------- */
  /*  Calendar Helper Methods                     */
  /* -------------------------------------------- */

  /**
   * Calculate the decimal hours since the start of the day.
   * @param {number|TimeComponents} [time]  The time to use, by default the current world time.
   * @param {CalendarData} [calendar]       Calendar to use, by default the current world calendar.
   * @returns {number}                      Number of hours since the start of the day as a decimal.
   */
  static hoursOfDay(time=game.time.components, calendar=game.time.calendar) {
    const components = typeof time === "number" ? this.timeToComponents(time) : time;
    const minutes = components.minute + (components.second / calendar.days.secondsPerMinute);
    return components.hour + (minutes / calendar.days.minutesPerHour);
  }

  /* -------------------------------------------- */

  /**
   * Get the number of hours in a given day.
   * @param {number|TimeComponents} [time]  The time to use, by default the current world time.
   * @returns {number}                      Number of hours between sunrise and sunset.
   */
  daylightHours(time=game.time.components) {
    return this.sunset(time) - this.sunrise(time);
  }

  /* -------------------------------------------- */

  /**
   * Progress between sunrise and sunset assuming it is daylight half the day duration.
   * @param {number|TimeComponents} [time]  The time to use, by default the current world time.
   * @returns {number}                      Progress through day period, with 0 representing sunrise and 1 sunset.
   */
  progressDay(time=game.time.components) {
    return (CalendarData5e.hoursOfDay(time) - this.sunrise(time)) / this.daylightHours(time);
  }

  /* -------------------------------------------- */

  /**
   * Progress between sunset and sunrise assuming it is night half the day duration.
   * @param {number|TimeComponents} [time]  The time to use, by default the current world time.
   * @returns {number}                      Progress through night period, with 0 representing sunset and 1 sunrise.
   */
  progressNight(time=game.time.components) {
    const daylightHours = this.daylightHours(time);
    let hour = CalendarData5e.hoursOfDay(time);
    if ( hour < daylightHours ) hour += this.days.hoursPerDay;
    return (hour - this.sunset(time)) / daylightHours;
  }

  /* -------------------------------------------- */

  /**
   * Get the sunrise time for a given day.
   * @param {number|TimeComponents} [time]  The time to use, by default the current world time.
   * @returns {number}                      Sunrise time in hours.
   */
  sunrise(time=game.time.components) {
    return this.days.hoursPerDay * .25;
  }

  /* -------------------------------------------- */

  /**
   * Get the sunset time for a given day.
   * @param {number|TimeComponents} [time]  The time to use, by default the current world time.
   * @returns {number}                      Sunset time in hours.
   */
  sunset(time=game.time.components) {
    return this.days.hoursPerDay * .75;
  }

  /* -------------------------------------------- */
  /*  Set Date Methods                            */
  /* -------------------------------------------- */

  /**
   * Set the date to a specific year, month, or day. Any values not provided will remain the same.
   * @param {object} components
   * @param {number} [components.year]   Visible year (with `yearZero` added in).
   * @param {number} [components.month]  Index of month.
   * @param {number} [components.day]    Day within the month.
   */
  async jumpToDate({ year, month, day }) {
    const components = { ...game.time.components };
    year ??= components.year + this.years.yearZero;
    month ??= components.month;
    day ??= components.dayOfMonth;

    // Subtract out year zero
    components.year = year - this.years.yearZero;
    const { leapYear } = this._decomposeTimeYears(this.componentsToTime(components));

    // Convert days within month to day of year
    let dayOfYear = day - 1;
    for ( let idx=0; idx<month; idx++ ) {
      const m = this.months.values[idx];
      dayOfYear += leapYear ? (m.leapDays ?? m.days) : m.days;
    }
    components.day = dayOfYear;
    components.month = month;

    await game.time.set(components);
  }

  /* -------------------------------------------- */
  /*  Formatter Functions                         */
  /* -------------------------------------------- */

  /**
   * Prepared date parts passed to the localization.
   * @param {CalendarData} calendar      The configured calendar.
   * @param {TimeComponents} components  Time components to format.
   * @returns {CalendarFormattingContext}
   */
  static dateFormattingParts(calendar, components) {
    const month = calendar.months.values[components.month];
    return {
      // Year
      y: components.year + calendar.years.yearZero,
      yyyy: (components.year + calendar.years.yearZero).paddedString(4),

      // Month
      b: month.abbreviation,
      B: _loc(month.name),
      m: month.ordinal,
      mm: month.ordinal.paddedString(2),

      // Week
      // a: Day of week abbreviation (e.g. Mon, Tue)
      // A: Day of week full name (e.g. Monday, Tuesday)
      // W: week number of the year

      // Day
      d: components.dayOfMonth + 1,
      dd: (components.dayOfMonth + 1).paddedString(2),
      D: formatNumber(components.dayOfMonth + 1, { ordinal: true }),
      j: (components.day + 1).paddedString(3),
      w: String(components.dayOfWeek + 1),

      // Hour
      H: components.hour.paddedString(2),

      // Minute
      M: components.minute.paddedString(2),

      // Second
      S: components.second.paddedString(2)
    };
  }

  /* -------------------------------------------- */

  /**
   * Format the date to approximate value based on season (e.g. "Early Spring", "Mid-Winter").
   * @param {CalendarData} calendar      The configured calendar.
   * @param {TimeComponents} components  Time components to format.
   * @param {object} options             Additional formatting options.
   * @returns {string}                   The returned string format.
   */
  static formatApproximateDate(calendar, components, options) {
    const season = calendar.seasons.values[components.season];
    let day = components.day;
    let seasonStart = season.dayStart;
    let seasonEnd = season.dayEnd;
    let days = 0;
    for ( const month of calendar.months.values ) {
      if ( (seasonStart !== null) && (seasonEnd !== null) ) break;
      if ( season.monthStart === month.ordinal ) seasonStart = days;
      if ( season.monthEnd === month.ordinal ) seasonEnd = days;
      days += components.leapYear ? month.leapDays ?? month.days : month.days;
    }
    if ( seasonEnd < seasonStart ) seasonEnd += calendar.days.daysPerYear;
    if ( day < seasonStart ) day += calendar.days.daysPerYear;
    const seasonPercent = (day - seasonStart) / (seasonEnd - seasonStart);
    let formatter = "Mid";
    if ( seasonPercent <= 0.33 ) formatter = "Early";
    else if ( seasonPercent >= 0.66 ) formatter = "Late";
    return _loc(`DND5E.CALENDAR.Formatters.ApproximateDate.${formatter}Season`, {
      season: _loc(season.name)
    });
  }

  /* -------------------------------------------- */

  /**
   * Format the time to approximate value (e.g. "Dawn", "Noon", "Night").
   * @param {CalendarData} calendar      The configured calendar.
   * @param {TimeComponents} components  Time components to format.
   * @param {object} options             Additional formatting options.
   * @returns {string}                   The returned string format.
   */
  static formatApproximateTime(calendar, components, options) {
    const day = calendar.progressDay(components);
    const night = calendar.progressNight(components);
    let formatter;
    if ( (night > 0.96) && (day < 0.04) ) formatter = "Sunrise";
    else if ( (day > 0.96) && (night < 0.04) ) formatter = "Sunset";
    else if ( (day > 0.45) && (day < 0.55) ) formatter = "Noon";
    else if ( (night > 0.45) && (night < 0.55) ) formatter = "Midnight";
    else if ( (night > 0.84) && (day < 0) ) formatter = "Dawn";
    else if ( (day > 1) && (night < 0.16) ) formatter = "Dusk";
    else if ( (day > 0) && (day < 0.5) ) formatter = "Morning";
    else if ( (day > 0.5) && (day <= 0.85) ) formatter = "Afternoon";
    else if ( (day > 0.85) && (night < 0) ) formatter = "Evening";
    else formatter = "Night";
    return _loc(`DND5E.CALENDAR.Formatters.ApproximateTime.${formatter}`);
  }

  /* -------------------------------------------- */

  /**
   * Format the time to a value including hours and minutes.
   * @param {CalendarData} calendar      The configured calendar.
   * @param {TimeComponents} components  Time components to format.
   * @param {object} options             Additional formatting options.
   * @returns {string}                   The returned string format.
   */
  static formatHoursMinutes(calendar, components, options) {
    return CalendarData5e.formatLocalized(
      "DND5E.CALENDAR.Formatters.HoursMinutes.Format", calendar, components, options
    );
  }

  /* -------------------------------------------- */

  /**
   * Format the time to a value including hours, minutes, and seconds.
   * @param {CalendarData} calendar      The configured calendar.
   * @param {TimeComponents} components  Time components to format.
   * @param {object} options             Additional formatting options.
   * @returns {string}                   The returned string format.
   */
  static formatHoursMinutesSeconds(calendar, components, options) {
    return CalendarData5e.formatLocalized(
      "DND5E.CALENDAR.Formatters.HoursMinutesSeconds.Format", calendar, components, options
    );
  }

  /* -------------------------------------------- */

  /**
   * Format the date using the provided localization key and the default formatting parts.
   * @param {string} localizationKey         Key to use for localization.
   * @param {CalendarData} calendar          The configured calendar.
   * @param {TimeComponents} components   Time components to format.
   * @param {object} options                 Additional formatting options.
   * @returns {string}                       The returned string format.
   */
  static formatLocalized(localizationKey, calendar, components, options) {
    return _loc(localizationKey, CalendarData5e.dateFormattingParts(calendar, components));
  }

  /* -------------------------------------------- */

  /**
   * Format the date to a value including month and day.
   * @param {CalendarData} calendar      The configured calendar.
   * @param {TimeComponents} components  Time components to format.
   * @param {object} options                 Additional formatting options.
   * @returns {string}                       The returned string format.
   */
  static formatMonthDay(calendar, components, options) {
    return CalendarData5e.formatLocalized(
      "DND5E.CALENDAR.Formatters.MonthDay.Format", calendar, components, options
    );
  }

  /* -------------------------------------------- */

  /**
   * Format the date to a value including month, day, and year.
   * @param {CalendarData} calendar      The configured calendar.
   * @param {TimeComponents} components  Time components to format.
   * @param {object} options             Additional formatting options.
   * @returns {string}                   The returned string format.
   */
  static formatMonthDayYear(calendar, components, options) {
    return CalendarData5e.formatLocalized(
      "DND5E.CALENDAR.Formatters.MonthDayYear.Format", calendar, components, options
    );
  }

  /* -------------------------------------------- */
  /*  Event Listeners and Handlers                */
  /* -------------------------------------------- */

  /**
   * Inject additional information into time update.
   * @param {number} worldTime
   * @param {number} deltaTime
   * @param {object} options
   * @param {string} userId
   */
  static onUpdateWorldTime(worldTime, deltaTime, options, userId) {
    const previousTime = game.time.calendar.timeToComponents(game.time.worldTime - deltaTime);
    const previousHour = CalendarData5e.hoursOfDay(previousTime);
    const nowTime = game.time.components;
    const nowHour = CalendarData5e.hoursOfDay(nowTime);
    const passedHour = hour => {
      if ( (previousHour < hour) && (nowHour > hour) ) return 1;
      if ( (previousHour > hour) && (nowHour < hour) ) return -1;
      return 0;
    };

    const days = CalendarData5e.dayDifference(previousTime, nowTime);
    foundry.utils.setProperty(options, "dnd5e.deltas", {
      midnights: days,
      middays: days + passedHour(game.time.calendar.days.hoursPerDay / 2),
      sunrises: ("sunrise" in game.time.calendar) ? days + passedHour(game.time.calendar.sunrise(nowTime)) : null,
      sunsets: ("sunset" in game.time.calendar) ? days + passedHour(game.time.calendar.sunset(nowTime)) : null
    });
  }

  /* -------------------------------------------- */

  /**
   * Respond to time changes and trigger the handling of time passage. This hook is split off from
   * `onUpdateWorldTime` and registered late to allow modules to modify the time deltas with their
   * own entries before time passage is handled.
   * @param {number} worldTime
   * @param {number} deltaTime
   * @param {object} options
   * @param {string} userId
   */
  static onTimePassage(worldTime, deltaTime, options, userId) {
    if ( !game.user.isActiveGM || (deltaTime <= 0) ) return;
    const timePassageData = { worldTime, deltaTime, ...(options.dnd5e?.deltas ?? {}) };
    CalendarData5e.handleTimePassage(timePassageData);
  }

  /* -------------------------------------------- */

  /**
   * Trigger recovery for any world actors based on the passage of time.
   * @param {TimePassageData} timePassageData
   */
  static async handleTimePassage(timePassageData) {
    const periods = new Map();
    for ( const [d, p] of CONFIG.DND5E.calendarDeltasRecoveryMapping.entries() ) {
      if ( timePassageData[d] ) periods.set(p, timePassageData[d]);
    }

    const changes = [];
    const rolls = [];
    let hasBastion = false;

    const bastion = dnd5e.settings.bastionConfiguration;
    const advanceFacilities = dnd5e.settings.calendarConfig.enabled && (timePassageData.midnights > 0);
    const recoverUses = !dnd5e.settings.calendarConfig.manualRecovery && periods.size;
    if ( advanceFacilities || recoverUses ) {
      const operations = [];
      for ( const actor of game.actors ) {
        const deltas = { deleted: [], item: {} };
        const deleted = [];
        const updates = [];

        // Advance bastion facilities
        if ( advanceFacilities && bastion.availableForActor(actor) && actor.itemTypes.facility.length ) {
          const results = await dnd5e.bastion.advanceAllFacilities(actor, {
            duration: timePassageData.midnights, performUpdates: false, summary: "auto", turn: false
          });
          updates.push(...results.updates);
          hasBastion = true;
        }

        // Recover item & activity uses
        if ( recoverUses ) {
          for ( const item of actor.items ) {
            const result = await item.system.recoverUses?.(periods) ?? {};
            if ( result?.rolls ) rolls.push(...result.rolls);
            if ( result?.destroy ) {
              deltas.deleted.push(item.toObject());
              deleted.push(item.id);
            } else if ( !foundry.utils.isEmpty(result?.updates) ) {
              deltas.item[item.id] = IndividualDeltaField.getDeltas(item, result.updates);
              updates.push({ _id: item.id, ...result.updates });
            }
          }
        }

        if ( deleted.length ) operations.push({ action: "delete", documentName: "Item", ids: deleted, parent: actor });
        if ( updates.length ) operations.push({ action: "update", documentName: "Item", updates, parent: actor });
        if ( deltas.deleted.length || !foundry.utils.isEmpty(deltas.item) ) changes.push({ deltas, uuid: actor.uuid });
      }
      await foundry.documents.modifyBatch(operations);
    }

    const messageConfig = {
      create: changes.length > 0,
      data: {
        content: this.generateTimePassageMessage(timePassageData),
        rolls,
        system: { changes },
        title: _loc("DND5E.CALENDAR.TimePassage.Title"),
        type: "timePassed"
      }
    };

    // Display bastion turn reminder
    if ( advanceFacilities && bastion.enabled && bastion.reminder && hasBastion ) {
      const lastBastionTurn = dnd5e.settings.bastionTurns.at(-1);
      if ( lastBastionTurn === undefined ) {
        await game.settings.set("jujutsu-system", "bastionTurns", [game.time.worldTime]);
      } else {
        const days = CalendarData5e.dayDifference(
          game.time.calendar.timeToComponents(lastBastionTurn),
          game.time.calendar.timeToComponents(game.time.worldTime)
        );
        const previousDays = days - timePassageData.midnights;
        if ( Math.floor(days / bastion.duration) > Math.floor(previousDays / bastion.duration) ) {
          messageConfig.create = true;
          messageConfig.data.system.bastion = { reminder: true };
        }
      }
    }

    /**
     * A hook event that fires before a time passed chat message is created.
     * @function dnd5e.preCreateTimePassedMessage
     * @memberof hookEvents
     * @param {object} messageConfig
     * @param {boolean} messageConfig.create  Should the chat message be posted?
     * @param {object} messageConfig.data     Data for the created chat message.
     */
    Hooks.callAll("dnd5e.preCreateTimePassedMessage", messageConfig);

    if ( messageConfig.create ) ChatMessage.implementation.create(messageConfig.data);
  }

  /* -------------------------------------------- */

  /**
   * Create the message displayed in a time passage message based on the amount of time passed.
   * @param {TimePassageData} timePassageData
   * @returns {string|void}
   */
  static generateTimePassageMessage(timePassageData) {
    let message;

    // X days have passed
    if ( timePassageData.midnights > 1 ) {
      const pr = getPluralRules();
      const { value, unit } = convertTime(timePassageData.midnights, "day", { strict: false });
      const number = formatTime(value, unit, { words: true });
      message = _loc(`DND5E.CALENDAR.TimePassage.TimePassed.${pr.select(value)}`, {
        number: number.capitalize(), numberLc: number
      });
    }

    // Sun has set and risen again
    else if ( timePassageData.sunsets && timePassageData.sunrises ) {
      message = _loc("DND5E.CALENDAR.TimePassage.SunsetSunrise");
    }

    // Sun has set, risen, or midnight has been passed
    else if ( timePassageData.sunsets ) message = _loc("DND5E.CALENDAR.TimePassage.Sunset");
    else if ( timePassageData.sunrises ) message = _loc("DND5E.CALENDAR.TimePassage.Sunrise");
    else if ( timePassageData.midnights ) message = _loc("DND5E.CALENDAR.TimePassage.Midnight");

    return message ? `<p>${message}</p>` : undefined;
  }

  /* -------------------------------------------- */
  /*  Helpers                                     */
  /* -------------------------------------------- */

  /**
   * Count the total number of full days that have passed between two times.
   * @param {Components} previousTime
   * @param {Components} currentTime
   * @returns {number}
   */
  static dayDifference(previousTime, currentTime) {
    // If years are the same, simple subtraction should work
    if ( previousTime.year === currentTime.year ) return currentTime.day - previousTime.day;

    // Calculate the number of days just in current & previous years
    const daysForYear = year => game.time.calendar.isLeapYear(year)
      ? game.time.calendar.days.daysPerLeapYear : game.time.calendar.days.daysPerYear;
    let days = 0;
    if ( previousTime.year < currentTime.year ) {
      days += currentTime.day + (daysForYear(previousTime.year) - previousTime.day);
    } else {
      days -= (daysForYear(currentTime.year) - currentTime.day) + previousTime.day;
    }

    // If more than one year has passed, count the number of days for each year
    const largerYear = Math.max(currentTime.year, previousTime.year);
    const smallerYear = Math.min(currentTime.year, previousTime.year);
    for ( let year = smallerYear + 1; year < largerYear; year++ ) {
      if ( previousTime.year < currentTime.year ) days += daysForYear(year);
      else days -= daysForYear(year);
    }

    return days;
  }
}

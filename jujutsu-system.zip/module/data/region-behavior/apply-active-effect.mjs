import BaseActivityBehavior from "./base-activity-behavior.mjs";

const { DocumentUUIDField, NumberField, SetField, StringField } = foundry.data.fields;

/**
 * @import { ApplyActiveEffectActivityBehaviorData, ApplyActiveEffectRegionBehaviorSystemData } from "./_types.mjs";
 */

/**
 * The data model for a region behavior that applies active effects to certain tokens.
 * @extends {foundry.data.regionBehaviors.RegionBehaviorType<ApplyActiveEffectRegionBehaviorSystemData>}
 * @mixes ApplyActiveEffectRegionBehaviorSystemData
 */
export default class ApplyActiveEffect5eRegionBehaviorType extends foundry.data.regionBehaviors.RegionBehaviorType {

  /** @override */
  static LOCALIZATION_PREFIXES = ["DND5E.REGIONBEHAVIORS.APPLYACTIVEEFFECT"];

  /* -------------------------------------------- */

  /** @override */
  static defineSchema() {
    const dispositions = { ...foundry.applications.sheets.TokenConfig.TOKEN_DISPOSITIONS };
    delete dispositions[CONST.TOKEN_DISPOSITIONS.SECRET];
    return {
      effects: new SetField(new DocumentUUIDField({ type: "ActiveEffect", nullable: false })),
      dispositions: new SetField(new NumberField({ choices: dispositions })),
      sizes: new SetField(new StringField({ choices: () => CONFIG.DND5E.actorSizes })),
      types: new SetField(new StringField({ choices: () => CONFIG.DND5E.creatureTypes }))
      // TODO: Add FiltersField for arbitrary conditions once https://github.com/foundryvtt/dnd5e/issues/6672 is done
    };
  }

  /* -------------------------------------------- */
  /*  Methods                                     */
  /* -------------------------------------------- */

  /**
   * Check the conditions to decide if effects should be added to this token.
   * @param {TokenDocument5e} token  The token to which to add the effects.
   * @returns {boolean}
   */
  #evaluateConditions(token) {
    if ( token.disposition === CONST.TOKEN_DISPOSITIONS.SECRET ) return false;
    if ( this.dispositions.size && !this.dispositions.has(token.disposition) ) return false;
    if ( this.sizes.size && !this.sizes.has(token.actor.system.traits?.size) ) return false;
    if ( this.types.size && !this.types.has(token.actor.system.details?.type?.value) ) return false;
    return true;
  }

  /* -------------------------------------------- */

  /**
   * Apply the Active Effects when the Token enters the Region.
   * @param {RegionTokenEnterEvent} event
   * @this {ApplyActiveEffect5eRegionBehaviorType}
   */
  static async #onTokenEnter(event) {
    if ( !event.user.isSelf ) return;
    const { token, movement } = event.data;
    const actor = token.actor;
    if ( !actor || !this.#evaluateConditions(token) ) return;
    const resumeMovement = movement ? token.pauseMovement() : undefined;
    const effects = await Promise.all(this.effects.map(fromUuid));
    const toCreate = await this.#getEffectsToCreate(actor, effects);
    if ( toCreate.length ) await actor.createEmbeddedDocuments("ActiveEffect", toCreate);
    await resumeMovement?.();
  }

  /* -------------------------------------------- */

  /**
   * Un-apply the Active Effects when the Token exits the Region.
   * @param {RegionTokenExitEvent} event
   * @this {ApplyActiveEffect5eRegionBehaviorType}
   */
  static async #onTokenExit(event) {
    if ( !event.user.isSelf ) return;
    const { token, movement } = event.data;
    const actor = token.actor;
    if ( !actor ) return;
    const toDelete = this.#getEffectsToDelete(actor);
    if ( !toDelete.length ) return;
    const resumeMovement = movement ? token.pauseMovement() : undefined;
    await actor.deleteEmbeddedDocuments("ActiveEffect", toDelete);
    await resumeMovement?.();
  }

  /* -------------------------------------------- */

  /** @override */
  static events = {
    [CONST.REGION_EVENTS.TOKEN_ENTER]: this.#onTokenEnter,
    [CONST.REGION_EVENTS.TOKEN_EXIT]: this.#onTokenExit
  };

  /* -------------------------------------------- */

  /** @inheritDoc */
  _onUpdate(changed, options, userId) {
    super._onUpdate(changed, options, userId);
    if ( !this.behavior.active || !("system" in changed) ) return;
    this.#recreateEffectsForAllTokens();
  }

  /* -------------------------------------------- */

  /**
   * Recreate the effects of tokens within the region.
   * @returns {Promise<void>}
   */
  async #recreateEffectsForAllTokens() {
    const effects = await Promise.all(this.effects.map(fromUuid));
    const operations = [];
    for ( const token of this.region.tokens ) {
      const actor = token.actor;
      if ( !actor ) continue;
      const toDelete = this.#getEffectsToDelete(actor);
      if ( toDelete.length ) {
        operations.push({
          action: "delete",
          documentName: "ActiveEffect",
          ids: toDelete,
          parent: actor
        });
      }
      if ( !this.#evaluateConditions(token) ) continue;
      const toCreate = await this.#getEffectsToCreate(actor, effects);
      if ( toCreate.length ) {
        operations.push({
          action: "create",
          documentName: "ActiveEffect",
          data: toCreate,
          parent: actor
        });
      }
    }
    await foundry.documents.modifyBatch(operations);
  }

  /* -------------------------------------------- */

  /**
   * Get Active Effects that should be created for the Actor.
   * @param {Actor5e} actor                  The actor the Active Effects should be created for.
   * @param {ActiveEffect5e[]} effects       The effects the Active Effects are created from.
   * @returns {Promise<ActiveEffectData[]>}  The data of Active Effects that should be created.
   */
  async #getEffectsToCreate(actor, effects) {
    const origin = await fromUuid(this.region.getFlag("jujutsu-system", "activity"));
    const toCreate = [];
    for ( const effect of effects ) {
      if ( !effect ) continue;
      const data = effect.toObject();
      delete data._id;
      if ( effect.compendium ) {
        data._stats.duplicateSource = null;
        data._stats.compendiumSource = effect.uuid;
      } else {
        data._stats.duplicateSource = effect.uuid;
        data._stats.compendiumSource = null;
      }
      data._stats.exportSource = null;
      if ( data.system.origin ) {
        delete data.origin;
        data.system.origin = {
          activity: this.region.flags["jujutsu-system"]?.activity,
          behavior: this.behavior.uuid,
          item: this.region.flags["jujutsu-system"]?.item
        };
      }
      else data.origin = this.behavior.uuid;
      data.system.changes = await ActiveEffect.implementation.forApplication(data.system.changes, origin, actor);
      toCreate.push(data);
    }
    return toCreate;
  }

  /* -------------------------------------------- */

  /**
   * Get Active Effects that should be deleted from the Actor.
   * @param {Actor5e} actor  The actor the Active Effects should be deleted from.
   * @returns {string[]}     The IDs of Active Effects that should be deleted.
   */
  #getEffectsToDelete(actor) {
    return actor.effects.reduce((ids, effect) => {
      if ( effect.origin === this.behavior.uuid ) ids.push(effect.id);
      return ids;
    }, []);
  }
}

/* -------------------------------------------- */

/**
 * Data model representing the active effect activity behavior configuration.
 * @extends {foundry.abstract.DataModel<ApplyActiveEffectActivityBehaviorData>}
 * @mixes ApplyActiveEffectActivityBehaviorData
 */
export class ApplyActiveEffectActivityBehavior extends BaseActivityBehavior {

  /** @override */
  static LOCALIZATION_PREFIXES = ["DND5E.REGIONBEHAVIORS.APPLYACTIVEEFFECT"];

  /* -------------------------------------------- */

  /** @override */
  static defineSchema() {
    return {
      effects: new SetField(new DocumentUUIDField({ type: "ActiveEffect", nullable: false })),
      sizes: new SetField(new StringField()),
      types: new SetField(new StringField())
    };
  }

  /* -------------------------------------------- */
  /*  Methods                                     */
  /* -------------------------------------------- */

  /** @override */
  createBehaviorData(activity, { token }={}) {
    const { disposition } = token ?? activity.actor?.token ?? activity.actor?.prototypeToken ?? {};
    return {
      system: {
        dispositions: this.getDispositions(activity.target, { relativeTo: disposition }),
        effects: this.effects,
        sizes: this.sizes,
        types: this.types
      },
      type: "dnd5e.applyActiveEffect"
    };
  }

  /* -------------------------------------------- */
  /*  Helpers                                     */
  /* -------------------------------------------- */

  /** @override */
  customizeField(field, data) {
    if ( field.name === "sizes" ) {
      data.options = Object.entries(CONFIG.DND5E.actorSizes).map(([value, { label }]) => ({ value, label }));
    } else if ( field.name === "types" ) {
      data.options = Object.entries(CONFIG.DND5E.creatureTypes).map(([value, { label }]) => ({ value, label }));
    }
  }
}

import TeleportSheet from "../../applications/activity/teleport-sheet.mjs";
import TeleportActivityData from "../../data/activity/teleport-data.mjs";
import { convertLength, getSceneTargets } from "../../utils.mjs";
import ActivityMixin from "./mixin.mjs";

/**
 * @import { TeleportMovementResult } from "./_types.mjs";
 */

/**
 * Activity for teleporting a token using planned blink movement.
 */
export default class TeleportActivity extends ActivityMixin(TeleportActivityData) {
  /* -------------------------------------------- */
  /*  Model Configuration                         */
  /* -------------------------------------------- */

  /** @inheritDoc */
  static LOCALIZATION_PREFIXES = [...super.LOCALIZATION_PREFIXES, "DND5E.TELEPORT"];

  /* -------------------------------------------- */

  /** @inheritDoc */
  static metadata = Object.freeze(
    foundry.utils.mergeObject(super.metadata, {
      type: "teleport",
      img: "systems/jujutsu-system/icons/svg/activity/teleport.svg",
      title: "DND5E.TELEPORT.Title",
      hint: "DND5E.TELEPORT.Hint",
      sheetClass: TeleportSheet,
      usage: {
        actions: {
          planTeleport: TeleportActivity.#planTeleport
        }
      }
    }, { inplace: false })
  );

  /* -------------------------------------------- */
  /*  Properties                                  */
  /* -------------------------------------------- */

  /**
   * Can this activity currently plan teleport movement?
   * @type {boolean}
   */
  get canPlanTeleport() {
    return !Number.isFinite(this.teleport.value)
      || ((this.teleport.units in CONFIG.DND5E.movementUnits) && (this.teleport.value > 0));
  }

  /* -------------------------------------------- */
  /*  Activation                                  */
  /* -------------------------------------------- */

  /** @inheritDoc */
  _usageChatButtons(message) {
    if ( !this.canPlanTeleport ) return super._usageChatButtons(message);
    return [{
      action: "planTeleport",
      icon: "fa-solid fa-person-walking-dashed-line-arrow-right",
      label: { value: "DND5E.TELEPORT.Action.Teleport" }
    }].concat(super._usageChatButtons(message));
  }

  /* -------------------------------------------- */

  /** @inheritDoc */
  async _triggerSubsequentActions(config, results) {
    // TODO: Automatically plan teleport movement, but only when the spell specifically targets "Self".
    await super._triggerSubsequentActions(config, results);
  }

  /* -------------------------------------------- */

  /**
   * Handle planning teleport for selected tokens.
   * @returns {Promise<TeleportMovementResult[]|null>}
   */
  async planTeleport() {
    if ( !this.canPlanTeleport ) return null;

    const tokens = canvas.tokens?.controlled.length ? getSceneTargets() : [];
    if ( !tokens.length ) {
      ui.notifications.warn("DND5E.ActionWarningNoToken", { localize: true });
      return null;
    }

    const maxDistance = this.#getSceneMaxDistance();
    if ( maxDistance <= 0 ) {
      ui.notifications.warn("DND5E.TELEPORT.Warning.InvalidDistance", { localize: true });
      return null;
    }

    const config = { maxDistance, tokens };

    /**
     * A hook event that fires before teleport movement has been planned.
     * @function dnd5e.preTeleport
     * @memberof hookEvents
     * @param {TeleportActivity} activity                          The activity that is performing the teleportation.
     * @param {{ maxDistance: number, tokens: Token5e[] }} config  Information on the teleport to plan.
     * @returns {boolean}  Explicitly return `false` to prevent teleporting.
     */
    if ( Hooks.call("dnd5e.preTeleport", this, config) === false ) return;

    const plans = [];
    for ( const token of config.tokens ) {
      const plan = await token.planMovement({
        allowedActions: ["blink"],
        direct: true,
        maxDistance: config.maxDistance,
        preventDrop: true
      });
      if ( !plan ) continue;
      plans.push({ token, plan });
    }

    /**
     * A hook event that fires after teleport movement has been planned, but before tokens have been moved.
     * @function dnd5e.teleport
     * @memberof hookEvents
     * @param {TeleportActivity} activity                       The activity that is performing the teleportation.
     * @param {Omit<TeleportMovementResult, "result">[]} plans  Plans for tokens that are to be moved.
     * @returns {boolean}  Explicitly return `false` to prevent teleporting.
     */
    if ( Hooks.call("dnd5e.teleport", this, plans) === false ) return;

    const results = await Promise.all(
      plans.map(({ token, plan }) => token.document.startMovement(plan.id).then(moved => ({ token, plan, moved })))
    );

    /**
     * A hook event that fires after teleport movement has occurred.
     * @function dnd5e.postTeleport
     * @memberof hookEvents
     * @param {TeleportActivity} activity         The activity that is performing the teleportation.
     * @param {TeleportMovementResult[]} results  Information on tokens that have moved.
     */
    Hooks.callAll("dnd5e.postTeleport", this, results);

    return results;
  }

  /* -------------------------------------------- */

  /**
   * Get the maximum teleport distance converted into the current scene's units.
   * @returns {number|null}
   */
  #getSceneMaxDistance() {
    if ( !Number.isFinite(this.teleport.value) ) return Infinity;
    const sceneUnits = canvas.grid?.units;
    if ( !(this.teleport.units in CONFIG.DND5E.movementUnits) || !(this.teleport.value > 0)
      || !(sceneUnits in CONFIG.DND5E.movementUnits) ) return null;
    return convertLength(this.teleport.value, this.teleport.units, sceneUnits);
  }

  /* -------------------------------------------- */
  /*  Event Listeners and Handlers                */
  /* -------------------------------------------- */

  /**
   * Handle planning teleport movement from the chat card.
   * @this {TeleportActivity}
   * @param {PointerEvent} event     Triggering click event.
   * @param {HTMLElement} target     The capturing HTML element which defined a [data-action].
   * @param {ChatMessage5e} message  Message associated with the activation.
   * @returns {Promise<TeleportMovementResult[]|null>}
   */
  static #planTeleport(event, target, message) {
    return this.planTeleport();
  }
}

import ActivitySheet from "../../applications/activity/activity-sheet.mjs";
import ActivityUsageDialog from "../../applications/activity/activity-usage-dialog.mjs";
import TemplatePlacement from "../../canvas/template-placement.mjs";
import { ConsumptionError } from "../../data/activity/fields/consumption-targets-field.mjs";
import { ActorDeltasField } from "../../data/chat-message/fields/deltas-field.mjs";
import TargetsField from "../../data/chat-message/fields/targets-field.mjs";
import PropertyField from "../../data/shared/property-field.mjs";
import { formatNumber, generateIcon, getSceneTargets, localizeSchema, rollModeAtual } from "../../utils.mjs";
import AppliedRules from "../applied-rules.mjs";
import DependentDocumentMixin from "../mixins/dependent.mjs";
import PseudoDocumentMixin from "../mixins/pseudo-document.mjs";
import Ruleset from "../../systems/ruleset.mjs";
import { activationChoices, hasLegacy2Activation, energyConsumptionPlan, withoutEnergyConsumption } from "../../applications/activity/legacy2-activation.mjs";
import { stashLegacy2Activation, finishLegacy2Damage } from "../../applications/actor/jj/native-cards.mjs";

/**
 * @import { FavoriteData5e } from "../../data/abstract/_types.mjs";
 * @import { ActorDeltasData } from "../../data/chat-message/fields/_types.mjs";
 * @import {
 *   BasicRollDialogConfiguration, BasicRollMessageConfiguration,
 *   DamageRollConfiguration, DamageRollProcessConfiguration
 * } from "../../dice/_types.mjs";
 * @import {
 *   ActivityConsumptionDescriptor, ActivityDialogConfiguration, ActivityMessageConfiguration, ActivityMetadata,
 *   ActivityUsageChatButton, ActivityUsageResults, ActivityUsageUpdates, ActivityUseConfiguration
 * } from "./_types.mjs";
 */

/**
 * Mixin used to provide base logic to all activities.
 * @template {BaseActivityData} T
 * @param {typeof T} Base  The base activity data class to wrap.
 * @returns {typeof Activity}
 * @mixin
 */
export default function ActivityMixin(Base) {
  class Activity extends DependentDocumentMixin(PseudoDocumentMixin(Base)) {
    /**
     * Configuration information for this PseudoDocument.
     * @type {Readonly<ActivityMetadata>}
     */
    static metadata = Object.freeze({
      collection: "activities",
      label: "DOCUMENT.Activity",
      name: "Activity",
      sheetClass: ActivitySheet,
      targetPhase: "",
      usage: {
        actions: {},
        applyEffectsInChat: true,
        dialog: ActivityUsageDialog,
        messageType: "usage"
      }
    });

    /* -------------------------------------------- */

    /**
     * The handlebars template for rendering activity tooltips.
     * @type {string}
     */
    static ACTIVITY_TOOLTIP_TEMPLATE = "systems/jujutsu-system/templates/activity/parts/activity-tooltip.hbs";

    /* -------------------------------------------- */

    /**
     * Perform the pre-localization of this data model.
     */
    static localize() {
      foundry.helpers.Localization.localizeDataModel(this);
      const fields = this.schema.fields;
      if ( fields.damage?.fields.parts ) {
        localizeSchema(fields.damage.fields.parts.element, ["DND5E.DAMAGE.FIELDS.damage.parts"]);
      }
      if ( fields.consumption ) {
        localizeSchema(fields.consumption.fields.targets.element, ["DND5E.CONSUMPTION.FIELDS.consumption.targets"]);
      }
      if ( fields.uses ) localizeSchema(fields.uses.fields.recovery.element, ["DND5E.USES.FIELDS.uses.recovery"]);
    }

    /* -------------------------------------------- */

    /**
     * Perform pre-localization on the contents of a SchemaField. Necessary because the `localizeSchema` method
     * on `Localization` is private.
     * @param {SchemaField} schema
     * @param {string[]} prefixes
     * @internal
     */
    static _localizeSchema(schema, prefixes) {
      localizeSchema(schema, prefixes);
    }

    /* -------------------------------------------- */
    /*  Properties                                  */
    /* -------------------------------------------- */

    /**
     * Should this activity be visible on the item sheet?
     * @type {boolean}
     */
    get canConfigure() {
      if ( CONFIG.DND5E.activityTypes[this.type]?.configurable === false ) return false;
      if ( this.visibility?.requireIdentification && !this.item.system.identified && !game.user.isGM ) return false;
      if ( this.dependentOrigin?.active === false ) return false;
      return true;
    }

    /* -------------------------------------------- */

    /**
     * Should this activity be able to be used?
     * @type {boolean}
     */
    get canUse() {
      return this.item.canUse && !this.isHidden;
    }

    /* -------------------------------------------- */

    /**
     * Description used in chat message flavor for messages created with `rollDamage`.
     * @type {string}
     */
    get damageFlavor() {
      return _loc("DND5E.DamageRoll");
    }

    /* -------------------------------------------- */

    /**
     * Active effect that granted this activity as a rider.
     * @type {ActiveEffect5e|null}
     */
    get dependentOrigin() {
      return this.item.effects.get(this.flags?.["jujutsu-system"]?.dependentOn) ?? null;
    }

    /* -------------------------------------------- */

    /**
     * Whether this activity supports pass/fail outcomes.
     * @type {boolean}
     */
    get hasOutcomes() {
      return false;
    }

    /* -------------------------------------------- */

    /**
     * Is this activity hidden from display?
     * @type {boolean}
     */
    get isHidden() {
      if ( this.isRider ) return true;
      if ( this.item.isHidden ) return true;
      if ( this.dependentOrigin?.active === false ) return true;
      if ( this.visibility?.requireAttunement && !this.item.system.attuned ) return true;
      if ( this.visibility?.requireMagic && (this.item.system.magicAvailable === false) ) return true;
      if ( this.visibility?.requireIdentification && !this.item.system.identified ) return true;
      const level = this.relevantLevel;
      if ( ((this.visibility?.level?.min ?? -Infinity) > level)
        || ((this.visibility?.level?.max ?? Infinity) < level) ) return true;
      return false;
    }

    /* -------------------------------------------- */

    /**
     * References to this activity and its item, stored on the messages it creates.
     * @type {{ activity: SourceReferenceData, item: ItemReferenceData }}
     */
    get messageSources() {
      const { item } = this;
      return {
        activity: {
          id: this.id, img: this.img, name: this.name, type: this.type, uuid: this.uuid
        },
        item: {
          compendiumSource: item?._stats?.compendiumSource, id: item?.id, img: item?.img,
          name: item?.name, type: item?.type, uuid: item?.uuid
        }
      };
    }

    /* -------------------------------------------- */

    /**
     * Relative UUID for this activity on an actor.
     * @type {string}
     */
    get relativeUUID() {
      return `.Item.${this.item.id}.Activity.${this.id}`;
    }

    /* -------------------------------------------- */

    /**
     * Consumption targets that can be use for this activity.
     * @type {Set<string>}
     */
    get validConsumptionTypes() {
      const types = new Set(Object.keys(CONFIG.DND5E.activityConsumptionTypes));
      if ( this.isSpell ) types.delete("spellSlots");
      return types;
    }

    /* -------------------------------------------- */
    /*  Activation                                  */
    /* -------------------------------------------- */

    /**
     * Activate this activity.
     * @param {ActivityUseConfiguration} usage        Configuration info for the activation.
     * @param {ActivityDialogConfiguration} dialog    Configuration info for the usage dialog.
     * @param {ActivityMessageConfiguration} message  Configuration info for the created chat message.
     * @returns {Promise<ActivityUsageResults|void>}  Details on the usage process if not canceled.
     */
    async use(usage={}, dialog={}, message={}) {
      if ( !this.item.isEmbedded ) return;
      if ( !this.item.isOwner ) {
        ui.notifications.error("DND5E.DocumentUseWarn", { localize: true });
        return;
      }
      if ( !this.canUse ) {
        ui.notifications.error("DND5E.ACTIVITY.Warning.UsageNotAllowed", { localize: true });
        return;
      }

      // Create an item clone to work with throughout the rest of the process
      let item = this.item.clone({}, { keepId: true });
      let activity = item.system.activities.get(this.id);

      const usageConfig = activity._prepareUsageConfig(usage);

      const dialogConfig = foundry.utils.mergeObject({
        configure: true,
        applicationClass: this.metadata.usage.dialog
      }, dialog);

      const messageConfig = foundry.utils.mergeObject({
        create: true,
        data: {
          system: { targets: TargetsField.getDescriptors() }
        },
        hasConsumption: usageConfig.hasConsumption
      }, message);

      /**
       * A hook event that fires before an activity usage is configured.
       * @function dnd5e.preUseActivity
       * @memberof hookEvents
       * @param {Activity} activity                           Activity being used.
       * @param {ActivityUseConfiguration} usageConfig        Configuration info for the activation.
       * @param {ActivityDialogConfiguration} dialogConfig    Configuration info for the usage dialog.
       * @param {ActivityMessageConfiguration} messageConfig  Configuration info for the created chat message.
       * @returns {boolean}  Explicitly return `false` to prevent activity from being used.
       */
      if ( Hooks.call("dnd5e.preUseActivity", activity, usageConfig, dialogConfig, messageConfig) === false ) return;

      // Display configuration window if necessary
      if ( dialogConfig.configure && activity._requiresConfigurationDialog(usageConfig) ) {
        try {
          await dialogConfig.applicationClass.create(activity, usageConfig, dialogConfig.options);
        } catch {
          return;
        }
      }

      // Handle scaling
      await activity._prepareUsageScaling(usageConfig, messageConfig, item);
      activity = item.system.activities.get(this.id);
      if (hasLegacy2Activation(activity)) usageConfig.legacy2 = activationChoices(activity, usageConfig.legacy2);

      // Handle consumption
      const updates = await activity.consume(usageConfig, messageConfig);
      if ( updates === false ) return;
      if (hasLegacy2Activation(activity)) {
        activity._jj2Activation = { ...usageConfig.legacy2, prepaid: true };
        foundry.utils.setProperty(messageConfig, "data.flags.jujutsu-system.activation", {
          ...activity._jj2Activation, scaleFormula: activity.jjScale?.formula ?? ""
        });
      }
      const results = { effects: [], templates: [], updates };

      // Create concentration effect & end previous effects
      if ( usageConfig.concentration?.begin ) {
        const effect = await item.actor.beginConcentrating(activity, { "flags.JujutsuLegacy.scaling": usageConfig.scaling });
        if ( effect ) {
          results.effects ??= [];
          results.effects.push(effect);
          foundry.utils.setProperty(messageConfig.data, "system.concentration", effect.id);
        }
        if ( usageConfig.concentration?.end ) {
          const deleted = await item.actor.endConcentration(usageConfig.concentration.end);
          results.effects.push(...deleted);
        }
      }

      // Create chat message
      activity._finalizeMessageConfig(usageConfig, messageConfig, results);
      results.message = await activity._createUsageMessage(messageConfig);
      if (hasLegacy2Activation(activity)) {
        activity._jj2OriginMessage = results.message?.id;
        stashLegacy2Activation(activity, usageConfig.legacy2, { origin: activity._jj2OriginMessage });
      }

      // Perform any final usage steps
      await activity._finalizeUsage(usageConfig, results);

      /**
       * A hook event that fires when an activity is activated.
       * @function dnd5e.postUseActivity
       * @memberof hookEvents
       * @param {Activity} activity                     Activity being activated.
       * @param {ActivityUseConfiguration} usageConfig  Configuration data for the activation.
       * @param {ActivityUsageResults} results          Final details on the activation.
       * @returns {boolean}  Explicitly return `false` to prevent any subsequent actions from being triggered.
       */
      if ( Hooks.call("dnd5e.postUseActivity", activity, usageConfig, results) === false ) return results;

      // Trigger any primary action provided by this activity
      if ( usageConfig.subsequentActions !== false ) {
        const deltas = results.message?.system?.deltas ?? results.message?.data?.system?.deltas;
        const consumed = this.createConsumedFlag(this.actor, deltas);
        if ( consumed ) item.updateSource({ "flags.JujutsuLegacy.consumed": consumed });
        activity._triggerSubsequentActions(usageConfig, results);
      }

      return results;
    }

    /* -------------------------------------------- */

    /**
     * Consume this activation's usage.
     * @param {ActivityUseConfiguration} usageConfig        Usage configuration.
     * @param {ActivityMessageConfiguration} messageConfig  Configuration data for the chat message.
     * @returns {ActivityUsageUpdates|false}
     */
    async consume(usageConfig, messageConfig) {
      /**
       * A hook event that fires before an item's resource consumption is calculated.
       * @function dnd5e.preActivityConsumption
       * @memberof hookEvents
       * @param {Activity} activity                           Activity being activated.
       * @param {ActivityUseConfiguration} usageConfig        Configuration data for the activation.
       * @param {ActivityMessageConfiguration} messageConfig  Configuration info for the created chat message.
       * @returns {boolean}  Explicitly return `false` to prevent activity from being activated.
       */
      if ( Hooks.call("dnd5e.preActivityConsumption", this, usageConfig, messageConfig) === false ) return false;

      const updates = await this._prepareUsageUpdates(Ruleset.isV2() ? withoutEnergyConsumption(this, usageConfig) : usageConfig);
      if ( !updates ) return false;
      let energyPlan;
      if (Ruleset.isV2()) {
        try {
          energyPlan = energyConsumptionPlan(this, usageConfig);
          if (energyPlan.payer === this.actor) Object.assign(updates.actor, energyPlan.updates);
        } catch (error) {
          ui.notifications.warn(error.message);
          return false;
        }
      }

      /**
       * A hook event that fires after an item's resource consumption is calculated, but before any updates are
       * performed.
       * @function dnd5e.activityConsumption
       * @memberof hookEvents
       * @param {Activity} activity                           Activity being activated.
       * @param {ActivityUseConfiguration} usageConfig        Configuration data for the activation.
       * @param {ActivityMessageConfiguration} messageConfig  Configuration info for the created chat message.
       * @param {ActivityUsageUpdates} updates                Updates to apply to the actor and other documents.
       * @returns {boolean}  Explicitly return `false` to prevent activity from being activated.
       */
      if ( Hooks.call("dnd5e.activityConsumption", this, usageConfig, messageConfig, updates) === false ) return false;

      if (energyPlan && energyPlan.payer !== this.actor && Object.keys(energyPlan.updates).length) {
        const payer = energyPlan.payer;
        updates.operations ??= [];
        updates.operations.push(payer.parent ? {
          action: "update", documentName: "ActorDelta", parent: payer.parent,
          updates: [{ ...energyPlan.updates, _id: payer.parent.delta.id }], isEnergySystem: true
        } : {
          action: "update", documentName: "Actor", updates: [{ ...energyPlan.updates, _id: payer.id }], isEnergySystem: true
        });
      }

      const consumed = await this.#applyUsageUpdates(updates);
      if ( !foundry.utils.isEmpty(consumed) ) {
        foundry.utils.setProperty(messageConfig, "data.system.deltas", consumed);
      }
      if ( usageConfig.cause?.activity ) {
        foundry.utils.setProperty(messageConfig, "data.system.cause", usageConfig.cause.activity);
      }

      /**
       * A hook event that fires after an item's resource consumption is calculated and applied.
       * @function dnd5e.postActivityConsumption
       * @memberof hookEvents
       * @param {Activity} activity                           Activity being activated.
       * @param {ActivityUseConfiguration} usageConfig        Configuration data for the activation.
       * @param {ActivityMessageConfiguration} messageConfig  Configuration info for the created chat message.
       * @param {ActivityUsageUpdates} updates                Applied updates to the actor and other documents.
       * @returns {boolean}  Explicitly return `false` to prevent activity from being activated.
       */
      if ( Hooks.call("dnd5e.postActivityConsumption", this, usageConfig, messageConfig, updates) === false ) return false;

      return updates;
    }

    /* -------------------------------------------- */

    /**
     * Refund previously used consumption for an activity.
     * @param {ActorDeltasData} consumed  Data on the consumption that occurred.
     */
    async refund(consumed) {
      const updates = {
        activity: {}, actor: {}, create: consumed.deleted ?? [], delete: consumed.created ?? [], item: []
      };
      for ( const { keyPath, delta } of consumed.actor ?? [] ) {
        const value = foundry.utils.getProperty(this.actor, keyPath) - delta;
        if ( !Number.isNaN(value) ) updates.actor[keyPath] = value;
      }
      for ( const [id, changes] of Object.entries(consumed.item ?? {}) ) {
        const item = this.actor.items.get(id);
        if ( !item ) continue;
        const itemUpdate = {};
        for ( const { keyPath, delta } of changes ) {
          let currentValue;
          if ( keyPath.startsWith("system.activities") ) {
            const [id, ...kp] = keyPath.slice(18).split(".");
            currentValue = foundry.utils.getProperty(item.system.activities?.get(id) ?? {}, kp.join("."));
          } else currentValue = foundry.utils.getProperty(item, keyPath);
          const value = currentValue - delta;
          if ( !Number.isNaN(value) ) itemUpdate[keyPath] = value;
        }
        if ( !foundry.utils.isEmpty(itemUpdate) ) {
          itemUpdate._id = id;
          updates.item.push(itemUpdate);
        }
      }
      await this.#applyUsageUpdates(updates);
    }

    /* -------------------------------------------- */

    /**
     * Merge activity updates into the appropriate item updates and apply.
     * @param {ActivityUsageUpdates} updates
     * @returns {ActorDeltasData}  Information on consumption performed to store in message flag.
     */
    async #applyUsageUpdates(updates) {
      this._mergeActivityUpdates(updates);

      // Ensure no existing items are created again & no non-existent items try to be deleted
      updates.create = updates.create?.filter(i => !this.actor.items.has(i._id));
      updates.delete = updates.delete?.filter(i => this.actor.items.has(i));

      // Create the consumed deltas
      const consumed = ActorDeltasField.getDeltas(this.actor, updates);

      // Update documents with consumption
      await this.actor.performBulkUpdate(updates, Ruleset.isV2() ? { isEnergySystem: true } : {});

      return consumed;
    }

    /* -------------------------------------------- */

    /**
     * Prepare usage configuration with the necessary defaults.
     * @param {ActivityUseConfiguration} config  Configuration object passed to the `use` method.
     * @returns {ActivityUseConfiguration}
     * @protected
     */
    _prepareUsageConfig(config) {
      config = foundry.utils.deepClone(config);
      const linked = this.getLinkedActivity(config.cause?.activity);

      if ( config.create !== false ) {
        config.create ??= {};
        config.create.measuredTemplate ??= !!this.target.template.type && this.target.prompt;
        // TODO: Handle permissions checks in `ActivityUsageDialog`
      }

      const ignoreLinkedConsumption = this.isSpell && !this.consumption.spellSlot;
      if ( config.consume !== false ) {
        const activationConfig = CONFIG.DND5E.activityActivationTypes[this.activation.type] ?? {};
        const hasActionConsumption = activationConfig.consume
          && (activationConfig.consume.canConsume?.(this) !== false);
        const hasResourceConsumption = !!this.consumption.targets.find(c => !c.hasZeroCost(config));
        const hasLinkedConsumption = (linked?.consumption.targets.length > 0) && !ignoreLinkedConsumption;
        const hasSpellSlotConsumption = this.requiresSpellSlot && this.consumption.spellSlot;
        config.consume ??= {};
        config.consume.action ??= hasActionConsumption;
        config.consume.resources ??= Array.from(this.consumption.targets.entries())
          .filter(([, target]) => !target.combatOnly || this.actor.inCombat)
          .map(([index]) => index);
        config.consume.spellSlot ??= !linked && hasSpellSlotConsumption;
        config.hasConsumption = hasActionConsumption || hasResourceConsumption || hasLinkedConsumption
          || (!linked && hasSpellSlotConsumption);
      }

      const levelingFlag = this.item.getFlag("jujutsu-system", "spellLevel");
      if ( levelingFlag ) {
        // Handle fixed scaling from spell scrolls
        config.scaling = false;
        config.spell ??= {};
        config.spell.slot = levelingFlag.value;
      }

      else {
        const canScale = linked ? linked.consumption.scaling.allowed : this.canScale;
        const linkedDelta = (linked?.spell?.level ?? Infinity) - this.item.system.level;
        if ( !canScale ) config.scaling = false;
        else if ( Number.isFinite(linkedDelta) ) config.scaling ??= linkedDelta;

        if ( this.requiresSpellSlot ) {
          const { level, method } = this.item.system;
          const model = CONFIG.DND5E.spellcasting[method];
          config.spell ??= {};
          config.spell.slot ??= linked?.spell?.level
            ? `spell${linked.spell.level}`
            : (model?.getSpellSlotKey(level) ?? `spell${level}`);
          const scaling = (this.actor.system.spells?.[config.spell.slot]?.level ?? 0) - this.item.system.level;
          if ( scaling > 0 ) config.scaling ??= scaling;
        }
        config.scaling ??= 0;
      }

      if ( this.requiresConcentration && !game.settings.get("jujutsu-system", "disableConcentration") ) {
        config.concentration ??= {};
        config.concentration.begin ??= true;
        const { effects } = this.actor.concentration;
        const limit = this.actor.system.attributes?.concentration?.limit ?? 0;
        if ( limit && (limit <= effects.size) ) config.concentration.end ??= effects.find(e => {
          const data = e.flags.JujutsuLegacy?.item?.data ?? {};
          return (data === this.id) || (data._id === this.id);
        })?.id ?? effects.first()?.id ?? null;
      }

      if ( linked ) {
        config.cause ??= {};
        config.cause.activity ??= linked.relativeUUID;
        config.cause.resources ??= (linked.consumption.targets.length > 0) && !ignoreLinkedConsumption;
      }

      return config;
    }

    /* -------------------------------------------- */

    /**
     * Determine scaling values and update item clone if necessary.
     * @param {ActivityUseConfiguration} usageConfig        Configuration data for the activation.
     * @param {ActivityMessageConfiguration} messageConfig  Configuration data for the chat message.
     * @param {Item5e} item                                 Clone of the item that contains this activity.
     * @protected
     */
    async _prepareUsageScaling(usageConfig, messageConfig, item) {
      const levelingFlag = this.item.getFlag("jujutsu-system", "spellLevel");
      if ( levelingFlag ) {
        usageConfig.scaling = Math.max(0, levelingFlag.value - levelingFlag.base);
      } else if ( this.isSpell ) {
        const level = this.actor.system.spells?.[usageConfig.spell?.slot]?.level;
        if ( level ) usageConfig.scaling = level - item.system.level;
      }

      if ( usageConfig.scaling ) {
        foundry.utils.setProperty(messageConfig, "data.system.scaling", usageConfig.scaling);
        if ( usageConfig.scaling !== item.flags.JujutsuLegacy?.scaling ) {
          item.actor._embeddedPreparation = true;
          item.updateSource({ "flags.JujutsuLegacy.scaling": usageConfig.scaling });
          delete item.actor._embeddedPreparation;
          item.prepareFinalAttributes();
        }
      }
    }

    /* -------------------------------------------- */

    /**
     * Calculate changes to actor, items, & this activity based on resource consumption.
     * @param {ActivityUseConfiguration} config                  Usage configuration.
     * @param {object} [options={}]
     * @param {boolean} [options.returnErrors=false]             Return array of errors, rather than displaying them.
     * @returns {ActivityUsageUpdates|ConsumptionError[]|false}  Updates to perform, an array of ConsumptionErrors,
     *                                                           or `false` if a consumption error occurred.
     * @protected
     */
    async _prepareUsageUpdates(config, { returnErrors=false }={}) {
      const updates = { activity: {}, actor: {}, create: [], delete: [], item: [], rolls: [] };
      if ( config.consume === false ) return updates;
      const errors = [];

      // Handle auto consumption.
      const activationConfig = CONFIG.DND5E.activityActivationTypes[this.activation.type];
      if ( ((config.consume === true) || config.consume.action) && activationConfig?.consume ) {
        const { property } = activationConfig.consume;
        const valueProperty = `${property}.value`;
        const containsConsumption = this.consumption.targets.find(t => {
          return (t.type === "attribute") && (t.target === valueProperty);
        });
        const count = this.activation.value ?? 1;
        const current = foundry.utils.getProperty(this.actor.system, property);
        if ( current && !containsConsumption ) {
          let message;
          if ( current.value < 1 ) message = "DND5E.ACTIVATION.Warning.NoActions";
          else if ( count > current.value ) message = "DND5E.ACTIVATION.Warning.NotEnoughActions";
          if ( message ) {
            const err = new ConsumptionError(_loc(message, {
              type: activationConfig.label,
              required: formatNumber(count),
              available: formatNumber(current.value)
            }));
            errors.push(err);
          } else {
            updates.actor[`system.${property}.spent`] = current.spent + count;
          }
        }
      }

      // Handle consumption targets
      if ( (config.consume === true) || config.consume.resources ) {
        const indexes = (config.consume === true) || (config.consume.resources === true)
          ? this.consumption.targets.keys() : config.consume.resources;
        for ( const index of indexes ) {
          const target = this.consumption.targets[index];
          if ( target.hasZeroCost(config) ) continue;
          try {
            await target.consume(config, updates);
          } catch (err) {
            if ( err instanceof ConsumptionError ) errors.push(err);
            else throw err;
          }
        }
      }

      // Handle consumption on a linked activity
      if ( config.cause ) {
        const linkedActivity = this.getLinkedActivity(config.cause.activity);
        if ( linkedActivity ) {
          const consume = {
            resources: (config.consume === true) || (config.cause?.resources === true)
              ? linkedActivity.consumption.targets.keys() : config.cause?.resources,
            spellSlot: false
          };
          const usageConfig = foundry.utils.mergeObject(config, { consume, cause: false }, { inplace: false });
          const results = await linkedActivity._prepareUsageUpdates(usageConfig, { returnErrors: true });
          if ( foundry.utils.getType(results) === "Object" ) {
            linkedActivity._mergeActivityUpdates(results);
            foundry.utils.mergeObject(updates.actor, results.actor);
            updates.delete.push(...results.delete);
            updates.item.push(...results.item);
            updates.rolls.push(...results.rolls);
            // Mark this item for deletion if it is linked to a cast activity that will be deleted
            const otherLinkedActivity = linkedActivity.type === "forward"
              ? linkedActivity.item.system.activities.get(linkedActivity.activity.id) : linkedActivity;
            if ( updates.delete.includes(linkedActivity.item.id)
              && (this.item.getFlag("jujutsu-system", "cachedFor") === otherLinkedActivity?.relativeUUID) ) {
              updates.delete.push(this.item.id);
            }
          } else if ( results?.length ) {
            errors.push(...results);
          }
        }
      }

      // Handle spell slot consumption
      else if ( ((config.consume === true) || config.consume.spellSlot)
        && this.requiresSpellSlot && this.consumption.spellSlot ) {
        const spellcasting = CONFIG.DND5E.spellcasting[this.item.system.method];
        const effectiveLevel = this.item.system.level + (config.scaling ?? 0);
        const slot = config.spell?.slot ?? spellcasting?.getSpellSlotKey(effectiveLevel) ?? this.item.system.method;
        const slotData = this.actor.system.spells?.[slot];
        if ( slotData ) {
          if ( slotData.value ) {
            const newValue = Math.max(slotData.value - 1, 0);
            foundry.utils.mergeObject(updates.actor, { [`system.spells.${slot}.value`]: newValue });
          } else {
            const err = new ConsumptionError(_loc("DND5E.SpellCastNoSlots", {
              name: this.item.name, level: slotData.label
            }));
            errors.push(err);
          }
        }
      }

      // Ensure concentration can be handled
      if ( config.concentration?.begin ) {
        const { effects } = this.actor.concentration;
        // Ensure existing concentration effect exists when replacing concentration
        if ( config.concentration.end ) {
          const replacedEffect = effects.find(i => i.id === config.concentration.end);
          if ( !replacedEffect ) errors.push(
            new ConsumptionError(_loc("DND5E.CONCENTRATION.Warning.MissingItem"))
          );
        }

        // Cannot begin more concentrations than the limit
        else if ( effects.size >= this.actor.system.attributes?.concentration?.limit ) errors.push(
          new ConsumptionError(_loc("DND5E.CONCENTRATION.Limit.Reached"))
        );
      }

      if ( !returnErrors ) errors.forEach(err => ui.notifications.error(err.message, { console: false }));
      return errors.length ? returnErrors ? errors : false : updates;
    }

    /* -------------------------------------------- */

    /**
     * Determine if the configuration dialog is required based on the configuration options. Does not guarantee a dialog
     * is shown if the dialog is suppressed in the activation dialog configuration.
     * @param {ActivityUseConfiguration} config
     * @returns {boolean}
     * @protected
     */
    _requiresConfigurationDialog(config) {
      if (hasLegacy2Activation(this)) return true;
      const checkObject = obj => (foundry.utils.getType(obj) === "Object")
        && Object.values(obj).some(v => v === true || v?.length);
      return config.concentration?.begin === true
        || checkObject(config.create)
        || ((checkObject(config.consume) || (config.cause?.resources === true)) && config.hasConsumption)
        || (config.scaling !== false);
    }

    /* -------------------------------------------- */

    /**
     * Apply any final modifications to message config immediately before message is created.
     * @param {ActivityUseConfiguration} usageConfig        Configuration data for the activation.
     * @param {ActivityMessageConfiguration} messageConfig  Configuration data for the chat message.
     * @param {ActivityUsageResults} results                Final details on the activation.
     * @protected
     */
    _finalizeMessageConfig(usageConfig, messageConfig, results) {
      messageConfig.data.rolls = (messageConfig.data.rolls ?? []).concat(results.updates.rolls);
      if ( this.metadata.usage.applyEffectsInChat ) {
        const effects = this.applicableEffects?.map(e => e.relativeUUID);
        if ( effects ) foundry.utils.setProperty(messageConfig.data, "system.effects", effects);
      }
    }

    /* -------------------------------------------- */

    /**
     * Create the buttons that will be displayed in chat.
     * @param {ActivityMessageConfiguration} message  Configuration info for the created message.
     * @returns {ActivityUsageChatButton[]}
     * @protected
     */
    _usageChatButtons(message) {
      const buttons = [];

      if ( this.target?.template?.type ) buttons.push({
        action: "placeTemplate",
        icon: "fa-solid fa-bullseye",
        label: { value: "DND5E.TARGET.Action.PlaceTemplate" }
      });

      if ( message.hasConsumption ) buttons.push({
        action: "consumeResource",
        icon: "fa-solid fa-cubes-stacked",
        label: { value: "DND5E.CONSUMPTION.Action.ConsumeResource" }
      }, {
        action: "refundResource",
        icon: "fa-solid fa-clock-rotate-left",
        label: { value: "DND5E.CONSUMPTION.Action.RefundResource" }
      });

      return buttons;
    }

    /* -------------------------------------------- */

    /**
     * Determine whether the provided button in a chat message should be visible.
     * @param {ActivityUsageChatButton} button  Descriptor for the button to check.
     * @param {ChatMessage5e} message           Chat message containing the button.
     * @returns {boolean}
     */
    shouldHideChatButton(button, message) {
      switch ( button.action ) {
        case "consumeResource": return !!message.system.deltas;
        case "refundResource": return !message.system.deltas;
        case "placeTemplate": return !game.user.can("REGION_CREATE") || !game.canvas.scene;
      }
      return false;
    }

    /* -------------------------------------------- */

    /**
     * Display a chat message for this usage.
     * @param {ActivityMessageConfiguration} message  Configuration info for the created message.
     * @returns {Promise<ChatMessage5e|object>}
     * @protected
     */
    async _createUsageMessage(message) {
      const { messageType } = this.metadata.usage;
      const data = {
        flags: {
          core: { canPopout: true }
        },
        speaker: ChatMessage.implementation.getSpeaker({ actor: this.item.actor }),
        system: await this.item.system.getCardData({ activity: this }),
        title: `${this.item.name} - ${this.name}`,
        type: messageType
      };
      const buttons = this._usageChatButtons(message);
      this.#migrateLegacyChatButtons(buttons);
      if ( buttons.length ) foundry.utils.setProperty(data, "system.buttons", buttons);
      const legacyContent = await this.#legacyUsageContent(message);
      if ( legacyContent ) data.content = legacyContent;
      const messageConfig = foundry.utils.mergeObject({
        data,
        rollMode: rollModeAtual()
      }, message);

      /**
       * A hook event that fires before an activity usage card is created.
       * @function dnd5e.preCreateUsageMessage
       * @memberof hookEvents
       * @param {Activity} activity                     Activity for which the card will be created.
       * @param {ActivityMessageConfiguration} message  Configuration info for the created message.
       */
      Hooks.callAll("dnd5e.preCreateUsageMessage", this, messageConfig);

      ChatMessage.applyMode(messageConfig.data, messageConfig.rollMode);
      const card = messageConfig.create === false ? messageConfig.data : await ChatMessage.create(messageConfig.data);

      /**
       * A hook event that fires after an activity usage card is created.
       * @function dnd5e.postCreateUsageMessage
       * @memberof hookEvents
       * @param {Activity} activity          Activity for which the card was created.
       * @param {ChatMessage5e|object} card  Created card or configuration data if not created.
       */
      Hooks.callAll("dnd5e.postCreateUsageMessage", this, card);

      return card;
    }

    /* -------------------------------------------- */

    /**
     * Apply any activity-type specific modifications to the rendered chat card.
     * @param {ChatMessage} message  Associated chat message.
     * @param {HTMLElement} element  Element in the chat log.
     * @abstract
     */
    onRenderChatCard(message, element) {}

    /* -------------------------------------------- */

    /**
     * Perform any final steps of the activation including creating measured templates.
     * @param {ActivityUseConfiguration} config  Configuration data for the activation.
     * @param {ActivityUsageResults} results     Final details on the activation.
     * @protected
     */
    async _finalizeUsage(config, results) {
      results.templates = config.create?.measuredTemplate ? await this.#placeTemplate() : [];
    }

    /* -------------------------------------------- */

    /**
     * Trigger a primary activation action defined by the activity (such as opening the attack dialog for attack rolls).
     * @param {ActivityUseConfiguration} config  Configuration data for the activation.
     * @param {ActivityUsageResults} results     Final details on the activation.
     * @protected
     */
    async _triggerSubsequentActions(config, results) {}

    /* -------------------------------------------- */
    /*  Rolling                                     */
    /* -------------------------------------------- */

    /**
     * Perform a damage roll.
     * @param {Partial<DamageRollProcessConfiguration>} config  Configuration information for the roll.
     * @param {Partial<BasicRollDialogConfiguration>} dialog    Configuration for the roll dialog.
     * @param {Partial<BasicRollMessageConfiguration>} message  Configuration for the roll message.
     * @returns {Promise<DamageRoll[]|void>}
     */
    async rollDamage(config={}, dialog={}, message={}) {
      const rollConfig = this.getDamageConfig(config);
      rollConfig.hookNames = [...(config.hookNames ?? []), "damage"];
      rollConfig.subject = this;

      if (Ruleset.isV2()) rollConfig.jj2Origin = message.data?.system?.origin
        ?? config.event?.target?.closest("[data-message-id]")?.dataset.messageId ?? this._jj2OriginMessage;

      const buildConfig = this._buildDamageConfig.bind(this);
      const dialogConfig = foundry.utils.mergeObject({
        options: {
          buildConfig,
          position: {
            width: 400,
            top: config.event ? config.event.clientY - 80 : null,
            left: window.innerWidth - 710
          },
          window: {
            title: this.damageFlavor,
            subtitle: this.item.name,
            icon: this.item.img
          }
        }
      }, dialog);

      const messageConfig = foundry.utils.mergeObject({
        create: true,
        data: {
          flavor: `${this.item.name} - ${this.damageFlavor}`,
          speaker: ChatMessage.getSpeaker({ actor: this.actor }),
          system: { ...this.messageSources, targets: TargetsField.getDescriptors() },
          type: "damage"
        }
      }, message);

      if (Ruleset.isV2() && rollConfig.jj2Origin && game.messages?.get(rollConfig.jj2Origin)?.flags?.["jujutsu-system"]?.activation) {
        foundry.utils.setProperty(messageConfig, "data.flags.jujutsu-system.activationDamage", rollConfig.jj2Origin);
      }
      const rolls = await CONFIG.Dice.DamageRoll.build(rollConfig, dialogConfig, messageConfig);
      if ( !rolls?.length ) return;
      if (Ruleset.isV2()) await finishLegacy2Damage(this, rollConfig);

      const canUpdate = this.item.isOwner && !this.item.inCompendium;
      const lastDamageTypes = rolls.reduce((obj, roll, index) => {
        if ( roll.options.type ) obj[index] = roll.options.type;
        return obj;
      }, {});
      if ( canUpdate && !foundry.utils.isEmpty(lastDamageTypes)
        && (this.actor && this.actor.items.has(this.item.id)) ) {
        await this.item.setFlag("jujutsu-system", `last.${this.id}.damageType`, lastDamageTypes);
      }

      /**
       * A hook event that fires after damage has been rolled.
       * @function dnd5e.rollDamage
       * @memberof hookEvents
       * @param {DamageRoll[]} rolls       The resulting rolls.
       * @param {object} [data]
       * @param {Activity} [data.subject]  The activity that performed the roll.
       */
      Hooks.callAll("dnd5e.rollDamage", rolls, { subject: this });
      Hooks.callAll("dnd5e.rollDamageV2", rolls, { subject: this });

      return rolls;
    }

    /* -------------------------------------------- */

    /**
     * Adjust rules applied to damage parts when damage type is changed.
     * @param {DamageRollProcessConfiguration} process  Configuration for the entire rolling process.
     * @param {DamageRollConfiguration} config          Configuration for a specific roll.
     * @param {FormDataExtended|void} formData          Any data entered into the rolling prompt.
     * @param {number} index                            Index of the roll within all rolls being prepared.
     * @returns {DamageRollConfiguration}
     */
    _buildDamageConfig(process, config, formData, index) {
      if (Ruleset.isV2()) {
        if (index === 0) process.jj2BaseDamageType = config.options.type;
        else if (config.options.jj2InheritDamageType) {
          config.options.type = formData?.get("roll.0.damageType") || process.jj2BaseDamageType;
        }
      }
      if ( index === 0 ) process.rules = {
        bonus: AppliedRules.collect(`${this.constructor.damageRuleCategory}:bonus`, this.actor, this.item).toArray(),
        consumed: new Set()
      };

      config.data.roll ??= {};
      config.data.roll.damageType = config.options.type;
      const ruleBonus = AppliedRules.createIterator(process.rules.bonus)
        .filterWith(config.data, { consumed: process.rules.consumed })
        .toFormula();
      const rulePartIndex = config.parts.findIndex(p => p === "@ruleBonus");
      if ( ruleBonus ) {
        config.data.ruleBonus = ruleBonus;
        if ( rulePartIndex < 0 ) config.parts.push("@ruleBonus");
      } else if ( rulePartIndex >= 0 ) {
        config.parts.splice(rulePartIndex, 1);
      }

      return config;
    }

    /* -------------------------------------------- */
    /*  Event Listeners and Handlers                */
    /* -------------------------------------------- */

    /**
     * Construct context menu options for this Activity.
     * @returns {ContextMenuEntry[]}
     */
    getContextMenuOptions() {
      const entries = [];
      const compendiumLocked = this.item.collection?.locked;

      if ( this.item.isOwner && !compendiumLocked ) {
        entries.push({
          label: "DND5E.ContextMenuActionEdit",
          icon: "fa-solid fa-pen-to-square",
          onClick: () => this.item.sheet._renderChild(this.sheet)
        }, {
          label: "DND5E.ContextMenuActionDuplicate",
          icon: "fa-solid fa-copy",
          onClick: () => {
            const createData = this.toObject();
            delete createData._id;
            this.item.createActivity(createData.type, createData, { renderSheet: false });
          }
        }, {
          label: "DND5E.ContextMenuActionDelete",
          icon: "fa-solid fa-trash",
          onClick: () => this.deleteDialog({ sheet: this.item.sheet })
        });
      } else {
        entries.push({
          label: "DND5E.ContextMenuActionView",
          icon: "fa-solid fa-eye",
          onClick: () => this.item.sheet._renderChild(this.sheet)
        });
      }

      if ( "favorites" in (this.actor?.system ?? {}) ) {
        const uuid = `${foundry.utils.buildRelativeUuid(this.item, this.actor)}.Activity.${this.id}`;
        const isFavorited = this.actor.system.hasFavorite(uuid);
        entries.push({
          label: isFavorited ? "DND5E.FavoriteRemove" : "DND5E.Favorite",
          icon: "fa-solid fa-bookmark",
          group: "state",
          visible: () => this.item.isOwner && !compendiumLocked,
          onClick: () => {
            if ( isFavorited ) this.actor.system.removeFavorite(uuid);
            else this.actor.system.addFavorite({ type: "activity", id: uuid });
          }
        });
      }

      return entries;
    }

    /* -------------------------------------------- */

    /**
     * Handle an action activated from an activity's chat message.
     * @param {PointerEvent} event     Triggering click event.
     * @param {HTMLElement} target     The capturing HTML element which defined a [data-action].
     * @param {ChatMessage5e} message  Message associated with the activation.
     */
    async onChatAction(event, target, message) {
      const consumed = this.createConsumedFlag(message.getAssociatedActor(), message.system.deltas);
      const scaling = message.system.scaling ?? 0;
      const item = (consumed || scaling) ? this.item.clone({
        "flags.JujutsuLegacy": { consumed, scaling }
      }, { keepId: true }) : this.item;
      const activity = item.system.activities.get(this.id);
      const action = target.dataset.action ?? message.system.getButton(target)?.action;
      const handler = this.metadata.usage?.actions?.[action];
      target.disabled = true;
      try {
        if ( handler ) await handler.call(activity, event, target, message);
        else if ( action === "consumeResource" ) await this.#consumeResource(event, target, message);
        else if ( action === "refundResource" ) await this.#refundResource(event, target, message);
        else if ( action === "placeTemplate" ) await this.#placeTemplate();
        else await activity._onChatAction(event, target, message);
      } catch (err) {
        Hooks.onError("Activity#onChatAction", err, { log: "error", notify: "error" });
      } finally {
        target.disabled = false;
      }
    }

    /* -------------------------------------------- */

    /**
     * Handle an action activated from an activity's chat message. Action handlers in metadata are called first.
     * This method is only called for actions which have no defined handler.
     * @param {PointerEvent} event     Triggering click event.
     * @param {HTMLElement} target     The capturing HTML element which defined a [data-action].
     * @param {ChatMessage5e} message  Message associated with the activation.
     * @protected
     */
    async _onChatAction(event, target, message) {}

    /* -------------------------------------------- */

    /**
     * Handle context menu events on activities.
     * @param {Item5e} item         The Item the Activity belongs to.
     * @param {HTMLElement} target  The element the menu was triggered on.
     */
    static onContextMenu(item, target) {
      const { activityId } = target.closest("[data-activity-id]")?.dataset ?? {};
      const activity = item.system.activities?.get(activityId);
      if ( !activity ) return;
      const menuItems = activity.getContextMenuOptions();

      /**
       * A hook even that fires when the context menu for an Activity is opened.
       * @function dnd5e.getItemActivityContext
       * @memberof hookEvents
       * @param {Activity} activity             The Activity.
       * @param {HTMLElement} target            The element that menu was triggered on.
       * @param {ContextMenuEntry[]} menuItems  The context menu entries.
       */
      Hooks.callAll("dnd5e.getItemActivityContext", activity, target, menuItems);
      ui.context.menuItems = menuItems;
    }

    /* -------------------------------------------- */

    /**
     * Handle consuming resources from the chat card.
     * @param {PointerEvent} event     Triggering click event.
     * @param {HTMLElement} target     The capturing HTML element which defined a [data-action].
     * @param {ChatMessage5e} message  Message associated with the activation.
     */
    async #consumeResource(event, target, message) {
      const messageConfig = { message };
      const usageConfig = this._prepareConsumeResourceUsageConfig(event, message);
      const linkedActivity = this.getLinkedActivity(message.system.cause);
      if ( linkedActivity ) usageConfig.cause = {
        activity: linkedActivity.relativeUUID, resources: linkedActivity.consumption.targets.length > 0
      };
      await this.consume(usageConfig, messageConfig);
      if ( !foundry.utils.isEmpty(messageConfig.data) ) await message.update(messageConfig.data);
    }

    /* -------------------------------------------- */

    /**
     * Prepare necessary parts of usage configuration from message data for resource consumption.
     * @param {PointerEvent} event     Triggering click event.
     * @param {ChatMessage5e} message  Message associated with the activation.
     * @returns {Partial<ActivityUseConfiguration>}
     */
    _prepareConsumeResourceUsageConfig(event, message) {
      const scaling = message.system.scaling;
      return { consume: true, event, scaling };
    }

    /* -------------------------------------------- */

    /**
     * Handle refunding consumption from a chat card.
     * @param {PointerEvent} event     Triggering click event.
     * @param {HTMLElement} target     The capturing HTML element which defined a [data-action].
     * @param {ChatMessage5e} message  Message associated with the activation.
     */
    async #refundResource(event, target, message) {
      if ( message.system.deltas ) {
        await this.refund(message.system.deltas);
        await message.update({ "system.deltas": null });
      }
    }

    /* -------------------------------------------- */

    /**
     * Handle placing a measured template in the scene.
     * @returns {MeasuredTemplateDocument[]}
     */
    async #placeTemplate() {
      const templates = [];
      try {
        const result = await TemplatePlacement.fromActivity(this);
        if ( result ) templates.push(...result);
      } catch (err) {
        Hooks.onError("Activity#placeTemplate", err, {
          msg: _loc("DND5E.TARGET.Warning.PlaceTemplate"),
          log: "error",
          notify: "error"
        });
      }
      return templates;
    }

    /* -------------------------------------------- */

    /**
     * Handle attaching region behaviors to a newly created template.
     * @param {Region} region
     * @param {object} options
     * @param {string} userId
     */
    static async placeTemplateBehaviors(region, options, userId) {
      if ( !game.user.isActiveGM || (options.dnd5e?.createActivityBehaviors === false) ) return;

      const activity = await fromUuid(region.getFlag("jujutsu-system", "activity"));
      const behaviors = activity?.applicableBehaviors;
      if ( !behaviors?.length ) return;

      const token = fromUuidSync(region.getFlag("jujutsu-system", "origin"));
      const toCreate = [];
      for ( const behavior of behaviors ) {
        const data = behavior.config.createBehaviorData(activity, { token });
        if ( !data ) continue;
        data.name ??= behavior.name;
        toCreate.push(data);
      }

      // TODO: Add pre- and post- hooks

      region.createEmbeddedDocuments("RegionBehavior", toCreate);
    }

    /* -------------------------------------------- */
    /*  Helpers                                     */
    /* -------------------------------------------- */

    /** @override */
    async _buildEmbedHTML(config, options={}) {
      if ( !this.description?.value ) return null;
      const enriched = await foundry.applications.ux.TextEditor.implementation.enrichHTML(this.description.value, {
        ...options, rollData: this.getRollData(), relativeTo: this.item
      });
      const container = document.createElement("div");
      container.innerHTML = enriched;
      return container.children;
    }

    /* -------------------------------------------- */

    /**
     * Retrieve consumed flag for given update data.
     * @param {Actor5e} actor
     * @type {ActorDeltasData} deltas
     * @returns {{ hd: string }|void}
     */
    createConsumedFlag(actor, deltas) {
      if ( !actor || !deltas ) return;
      const hitDice = Object.entries(deltas.item ?? [])
        .reduce((obj, [id, changes]) => {
          const hdChange = changes.find(c => (c.keyPath === "system.hd.spent") && (c.delta > 0))?.delta;
          const hdDenom = actor.items.get(changes._id ?? id)?.system?.hd?.denomination;
          if ( hdChange && hdDenom ) obj[hdDenom] = (obj[hdDenom] ?? 0) + hdChange;
          return obj;
        }, {});
      if ( foundry.utils.isEmpty(hitDice) ) return;
      return { hd: Object.entries(hitDice).map(([d, n]) => `${n}${d}`).join(" + ") };
    }

    /* -------------------------------------------- */

    /**
     * Retrieve any modifications to be made to an applied effect.
     * @param {ActiveEffect5e} effect                The base effect that will be applied.
     * @param {object} [options={}]
     * @param {ChatMessage5e} [options.chatMessage]  Message associated with the application.
     * @param {Actor5e|Item5e} [options.target]      Actor or item to which the effect will be applied.
     * @returns {object}
     */
    getAppliedEffectChanges(effect, { chatMessage, target }={}) {
      const changes = {};
      if ( !effect.duration.expiry ) {
        if ( !Number.isFinite(effect.duration.value) ) {
          const duration = this.duration?.getEffectData();
          if ( !foundry.utils.isEmpty(duration) ) changes.duration = duration;
        } else if ( effect.duration.units !== "turns" ) {
          changes.duration = { expiry: "turnStart" };
        }
      }
      return changes;
    }

    /* -------------------------------------------- */

    /**
     * Prepare activity favorite data.
     * @returns {Promise<FavoriteData5e>}
     */
    async getFavoriteData() {
      return {
        img: this.img,
        title: this.name,
        subtitle: [this.labels.activation, this.labels.recovery],
        range: this.range,
        uses: { ...this.uses, name: "uses.value" }
      };
    }

    /* -------------------------------------------- */

    /**
     * Retrieve a linked activity based on the provided relative UUID, or the stored `cachedFor` value.
     * @param {string} relativeUUID  Relative UUID for an activity on this actor.
     * @returns {Activity|null}
     */
    getLinkedActivity(relativeUUID) {
      if ( !this.actor ) return null;
      relativeUUID ??= this.item.getFlag("jujutsu-system", "cachedFor");
      return fromUuidSync(relativeUUID, { relative: this.actor, strict: false });
    }

    /* -------------------------------------------- */

    /**
     * Get the best matched token from which this activity is being used if one can be found for this actor
     * in the current scene.
     * @returns {TokenDocument|void}
     */
    getUsageToken() {
      return getSceneTargets(this.actor)[0]?.document;
    }

    /* -------------------------------------------- */

    /**
     * Merge the activity updates into this activity's item updates.
     * @param {ActivityUsageUpdates} updates
     * @internal
     */
    _mergeActivityUpdates(updates) {
      if ( foundry.utils.isEmpty(updates.activity) ) return;
      const itemIndex = updates.item.findIndex(i => i._id === this.item.id);
      const keyPath = `system.activities.${this.id}`;
      const activityUpdates = foundry.utils.expandObject(updates.activity);
      if ( itemIndex === -1 ) updates.item.push({ _id: this.item.id, [keyPath]: activityUpdates });
      else updates.item[itemIndex][keyPath] = activityUpdates;
    }

    /* -------------------------------------------- */

    /**
     * Render a rich tooltip for this activity.
     * @param {EnrichmentOptions} [enrichmentOptions={}]  Options for text enrichment.
     * @param {string} [enrichmentOptions.extras]         Extra HTML displayed with the tooltip.
     * @returns {Promise<{content: string, classes: string[]}>|null}
     */
    async richTooltip(enrichmentOptions={}) {
      return {
        content: await foundry.applications.handlebars.renderTemplate(
          this.constructor.ACTIVITY_TOOLTIP_TEMPLATE, await this.getTooltipData(enrichmentOptions)
        ),
        classes: ["dnd5e2", "dnd5e-tooltip", "activity-tooltip", "document-tooltip"]
      };
    }

    /* -------------------------------------------- */
    /*  Importing and Exporting                     */
    /* -------------------------------------------- */

    /**
     * Can an activity of this type be added to the provided item?
     * @param {Item5e} item  Candidate item to which the activity might be added.
     * @returns {boolean}    Should this activity be available?
     */
    static availableForItem(item) {
      return true;
    }

    /* -------------------------------------------- */

    /** @override */
    static _createDialogTypes(parent) {
      return Object.entries(CONFIG.DND5E.activityTypes)
        .filter(([, c]) => !c.hidden && (c.configurable !== false) && c.documentClass.availableForItem(parent))
        .map(([k]) => k);
    }

    /* -------------------------------------------- */
    /*  Deprecations                                */
    /* -------------------------------------------- */

    /**
     * @deprecated
     * @since 6.0.0
     * @ignore
     */
    activateChatListeners(message, html) {}

    /* -------------------------------------------- */

    /**
     * @deprecated
     * @since 6.0.0
     * @ignore
     */
    _activateLegacyChatListeners(message, html) {
      if ( foundry.utils.getDefiningClass(this, "activateChatListeners") === Activity ) return;
      foundry.utils.logCompatibilityWarning(
        `The "${this.type}" activity defines "activateChatListeners". Register chat card actions through the `
        + '"usage.actions" metadata or "_onChatAction" instead.',
        { since: "DnD5e 6.0", until: "DnD5e 6.2", once: true }
      );
      this.activateChatListeners(message, html);
    }

    /* -------------------------------------------- */

    /**
     * @deprecated
     * @since 6.0.0
     * @ignore
     */
    async _usageChatContext(message) {
      const data = await this.item.system.getCardData({ activity: this });
      const properties = PropertyField.getLabels(data.properties.filter(p => !p.identity), {
        ...data, properties: data.item.properties
      });
      const supplements = [];
      if ( this.activation.condition ) {
        supplements.push(`<strong>${_loc("DND5E.Trigger")}</strong> ${this.activation.condition}`);
      }
      if ( data.materials ) {
        supplements.push(`<strong>${_loc("DND5E.Materials")}</strong> ${data.materials}`);
      }
      const buttons = this._usageChatButtons(message);
      this.#migrateLegacyChatButtons(buttons);
      const legacy = buttons.map(button => {
        const label = _loc(button.label?.value ?? "");
        return {
          ...button,
          dataset: { ...button.dataset, action: button.action },
          icon: generateIcon(button.icon)?.outerHTML ?? "",
          label: button.label?.hidden
            ? `<span class="visible-dc">${label}</span><span class="hidden-dc">${_loc(button.label.hidden)}</span>`
            : label
        };
      });

      return {
        activity: this,
        actor: this.item.actor,
        item: this.item,
        token: this.item.actor?.token,
        buttons: legacy.length ? legacy : null,
        concealed: data.concealed,
        description: data.description,
        properties: properties.length ? properties : null,
        subtitle: this.description.chatFlavor || data.subtitle.filterJoin(" • "),
        supplements
      };
    }

    /* -------------------------------------------- */

    /**
     * @deprecated
     * @since 6.0.0
     * @ignore
     */
    #migrateLegacyChatButtons(buttons) {
      const legacy = buttons.filter(b => !b.action || (typeof b.label === "string") || b.icon?.startsWith("<"));
      if ( !legacy.length ) return;
      foundry.utils.logCompatibilityWarning(
        `The "${this.type}" activity supplies chat buttons in a legacy format. Buttons must now define an "action", `
        + 'a "label" object, and an "icon" given as FontAwesome classes or an image path.',
        { since: "DnD5e 6.0", until: "DnD5e 6.2", once: true }
      );
      for ( const button of legacy ) {
        button.action ??= button.dataset?.action;
        if ( typeof button.label === "string" ) {
          const label = foundry.utils.parseHTML(`<div>${button.label}</div>`);
          const dc = label.querySelector(".visible-dc");
          button.label = dc
            ? { hidden: label.querySelector(".hidden-dc")?.textContent.trim(), value: dc.textContent.trim() }
            : { value: button.label };
        }
        if ( button.icon?.startsWith("<") ) {
          const icon = foundry.utils.parseHTML(button.icon);
          button.icon = icon?.dataset?.src ?? icon?.getAttribute?.("src") ?? icon?.className ?? "";
        }
      }
    }

    /* -------------------------------------------- */

    /**
     * @deprecated
     * @since 6.0.0
     * @ignore
     */
    async #legacyUsageContent(message) {
      const { chatCard } = this.metadata.usage;
      if ( !chatCard
        && (foundry.utils.getDefiningClass(this, "_usageChatContext") === Activity) ) return;
      foundry.utils.logCompatibilityWarning(
        `The "${this.type}" activity supplies a legacy usage card. "usage.chatCard" and "_usageChatContext" are `
        + 'deprecated. Set "message.data.content" in "_createUsageMessage" to keep custom card content.',
        { since: "DnD5e 6.0", until: "DnD5e 6.2", once: true }
      );
      return foundry.applications.handlebars.renderTemplate(
        chatCard ?? "systems/jujutsu-system/templates/chat/activity-card.hbs", await this._usageChatContext(message)
      );
    }
  }
  return Activity;
}

import Ruleset from "../../systems/ruleset.mjs";
import { applyNumericResistances } from "../../systems/legacy2-resistances.mjs";
import { absorbShieldDamage } from "../../systems/legacy2-shield.mjs";
import BaseRestDialog from "../../applications/actor/rest/base-rest-dialog.mjs";
import { EnergySystem } from "../../systems/energy.mjs";
import CreateDocumentDialog from "../../applications/create-document-dialog.mjs";
import SkillToolRollConfigurationDialog from "../../applications/dice/skill-tool-configuration-dialog.mjs";
import PropertyAttribution from "../../applications/property-attribution.mjs";
import TravelField from "../../data/actor/fields/travel-field.mjs";
import AttributesFields from "../../data/actor/templates/attributes.mjs";
import BastionTurnMessageData from "../../data/chat-message/bastion-turn-message-data.mjs";
import ActivationsField from "../../data/chat-message/fields/activations-field.mjs";
import { ActorDeltasField } from "../../data/chat-message/fields/deltas-field.mjs";
import D20RollModificationField from "../../data/shared/d20-roll-modification-field.mjs";
import TransformationSetting from "../../data/settings/transformation-setting.mjs";
import { Filter } from "../../filter.mjs";
import {
  convertTime, defaultUnits, formatLength, formatNumber, formatTime, rollModeAtual, simplifyBonus, staticID
} from "../../utils.mjs";
import ActiveEffect5e from "../active-effect.mjs";
import Item5e from "../item.mjs";
import SystemDocumentMixin from "../mixins/document.mjs";
import Proficiency from "./proficiency.mjs";
import SelectChoices from "./select-choices.mjs";
import * as Trait from "./trait.mjs";
import ConditionData from "../../data/active-effect/condition.mjs";
import { performValidatedCustomizationBatch } from "../../applications/actor/jj/legacy2-customization.mjs";

/**
 * @import { RequestOptions5e } from "../../_types.mjs";
 * @import { AttributionDescription } from "../../applications/_types.mjs";
 * @import { TravelPace5e } from "../../data/actor/fields/_types.mjs";
 * @import { SkillData } from "../../data/actor/templates/_types.mjs";
 * @import {
 *   AbilityRollProcessConfiguration,
 *   BasicRollDialogConfiguration, BasicRollMessageConfiguration,
 *   HitDieRollProcessConfiguration, InitiativeRollOptions,
 *   SkillToolRollDialogConfiguration, SkillToolRollProcessConfiguration
 * } from "../../dice/_types.mjs";
 * @import {
 *   ActorRollData, ActorUpdatesDescription, DamageAffectCategory, DamageApplicationOptions,
 *   DamageDescription, DamageSummary, DeathSaveOutcome, RestConfiguration, RestResult, RollDataOptions,
 *   SpellcastingDescription
 * } from "../_types.mjs";
 */

/**
 * Extend the base Actor class to implement additional system-specific logic.
 */
export default class Actor5e extends SystemDocumentMixin(Actor) {

  /** @override */
  static DEFAULT_ICON = "systems/jujutsu-system/icons/svg/documents/actor.svg";

  /* -------------------------------------------- */

  /**
   * A queue for updating falling state. Several post-CRUD hooks fire falling checks independently and are serialized
   * here.
   * @type {Promise<void>}
   * @internal
   */
  _falling = this._falling ?? Promise.resolve();

  /* -------------------------------------------- */

  /**
   * Lazily computed store of classes, subclasses, background, and species.
   * @type {Record<string, Record<string, Item5e|Item5e[]|string>>}
   */
  _lazy = {};

  /* -------------------------------------------- */

  /**
   * Cached copy of the preferred artwork.
   * @type {{ src: string, isToken: boolean, isRandom: boolean, isVideo: boolean }|null}
   */
  _preferredArtwork = this._preferredArtwork;

  /* -------------------------------------------- */

  /**
   * List of IDs of items that should be hidden on the sheet.
   * @type {Set<string>}
   */
  hiddenItems = this.hiddenItems;

  /* -------------------------------------------- */

  /**
   * Mapping of item identifiers to the items.
   * @type {IdentifiedItemsMap<string, Set<Item5e>>}
   */
  identifiedItems = this.identifiedItems;

  /* -------------------------------------------- */

  /**
   * Mapping of item compendium source UUIDs to the items.
   * @type {SourcedItemsMap<string, Set<Item5e>>}
   */
  sourcedItems = this.sourcedItems;

  /* -------------------------------------------- */

  /**
   * Types that can be selected within the compendium browser.
   * @param {object} [options={}]
   * @param {Set<string>} [options.chosen]  Types that have been selected.
   * @returns {SelectChoices}
   */
  static compendiumBrowserTypes({ chosen=new Set() }={}) {
    return new SelectChoices(Actor.TYPES.filter(t => t !== CONST.BASE_DOCUMENT_TYPE).reduce((obj, type) => {
      obj[type] = {
        label: CONFIG.Actor.typeLabels[type],
        chosen: chosen.has(type)
      };
      return obj;
    }, {}));
  }

  /* -------------------------------------------- */
  /*  Properties                                  */
  /* -------------------------------------------- */

  /**
   * A mapping of classes belonging to this Actor.
   * @type {Record<string, Item5e>}
   */
  get classes() {
    if ( this._lazy?.classes !== undefined ) return this._lazy.classes;
    return this._lazy.classes = Object.fromEntries(this.itemTypes.class.map(cls => [cls.identifier, cls]));
  }

  /* -------------------------------------------- */

  /**
   * Total reduction to this actor's D20 Tests from conditions.
   * @type {number}
   */
  get conditionRollReduction() {
    return Object.values(this.conditionRollReductions).reduce((total, reduction) => total + reduction, 0);
  }

  /* -------------------------------------------- */

  /**
   * Reductions to this actor's D20 Tests from conditions, keyed by the status applying them.
   * @type {Record<string, number>}
   */
  get conditionRollReductions() {
    if ( this._lazy.conditionRollReductions !== undefined ) return this._lazy.conditionRollReductions;
    const immunities = this.system.traits?.ci?.value ?? new Set();
    return this._lazy.conditionRollReductions = this.statuses.difference(immunities).reduce((obj, status) => {
      const reduction = CONFIG.DND5E.conditionTypes[status]?.reduction?.rolls ?? 0;
      const levels = ConditionData.hasLevels(status) ? this.system.conditions[status] ?? 0 : 1;
      if ( reduction && levels ) obj[status] = -levels * reduction;
      return obj;
    }, {});
  }

  /* -------------------------------------------- */

  /**
   * Calculate the bonus from any cover the actor is affected by.
   * @type {number}     The cover bonus to AC and dexterity saving throws.
   */
  get coverBonus() {
    const { coverHalf, coverThreeQuarters } = CONFIG.DND5E.statusEffects;
    if ( this.statuses.has("coverThreeQuarters") ) return coverThreeQuarters?.coverBonus;
    else if ( this.statuses.has("coverHalf") ) return coverHalf?.coverBonus;
    return 0;
  }

  /* -------------------------------------------- */

  /**
   * Highest ability associated with a spellcasting class.
   * @type {string}
   */
  get spellcastingAbility() {
    if ( this._lazy.spellcastingAbility !== undefined ) return this._lazy.spellcastingAbility;
    return this._lazy.spellcastingAbility = Object.values(this.spellcastingClasses).reduce((o, c) => {
      const ability = c.system.spellcasting.ability;
      if ( this.system.abilities[ability]?.mod > o.mod ) return { ability, mod: this.system.abilities[ability].mod };
      return o;
    }, { ability: null, mod: -Infinity })?.ability ?? this.system.attributes?.spellcasting ?? "int";
  }

  /* -------------------------------------------- */

  /**
   * Get all classes which have spellcasting ability.
   * @type {Record<string, Item5e>}
   */
  get spellcastingClasses() {
    if ( this._lazy.spellcastingClasses !== undefined ) return this._lazy.spellcastingClasses;
    return this._lazy.spellcastingClasses = Object.entries(this.classes).reduce((obj, [identifier, cls]) => {
      if ( cls.spellcasting && (cls.spellcasting.progression !== "none") ) obj[identifier] = cls;
      return obj;
    }, {});
  }

  /* -------------------------------------------- */

  /**
   * A mapping of subclasses belonging to this Actor.
   * @type {Record<string, Item5e>}
   */
  get subclasses() {
    if ( this._lazy?.subclasses !== undefined ) return this._lazy.subclasses;
    return this._lazy.subclasses = Object.fromEntries(this.itemTypes.subclass.map(i => [i.identifier, i]));
  }

  /* -------------------------------------------- */

  /**
   * Is this Actor currently polymorphed into some other creature?
   * @type {boolean}
   */
  get isPolymorphed() {
    return this.getFlag("jujutsu-system", "isPolymorphed") || false;
  }

  /* -------------------------------------------- */

  /**
   * The Actor's currently equipped armor, if any.
   * @type {Item5e|null}
   */
  get armor() {
    return this.system.attributes?.ac?.equippedArmor ?? null;
  }

  /* -------------------------------------------- */

  /**
   * The Actor's currently equipped shield, if any.
   * @type {Item5e|null}
   */
  get shield() {
    return this.system.attributes?.ac?.equippedShield ?? null;
  }

  /* -------------------------------------------- */

  /**
   * The items this actor is concentrating on, and the relevant effects.
   * @type {{items: Set<Item5e>, effects: Set<ActiveEffect5e>}}
   */
  get concentration() {
    if ( this._lazy.concentration !== undefined ) return this._lazy.concentration;
    const concentration = this._lazy.concentration = {
      items: new Set(),
      effects: new Set()
    };

    const limit = this.system.attributes?.concentration?.limit ?? 0;
    if ( !limit ) return concentration;

    for ( const effect of this.effects ) {
      if ( !effect.active || !effect.statuses.has(CONFIG.specialStatusEffects.CONCENTRATING) ) continue;
      const data = effect.getFlag("jujutsu-system", "item");
      concentration.effects.add(effect);
      if ( data ) {
        let item = this.items.get(data.id);
        if ( !item && (foundry.utils.getType(data.data) === "Object") ) {
          item = new Item.implementation(data.data, { keepId: true, parent: this });
        }
        if ( item ) concentration.items.add(item);
      }
    }
    return concentration;
  }

  /* -------------------------------------------- */

  /**
   * Creatures summoned by this actor.
   * @type {Actor5e[]}
   */
  get summonedCreatures() {
    return dnd5e.registry.summons.creatures(this);
  }

  /* -------------------------------------------- */
  /*  Data Migration                              */
  /* -------------------------------------------- */

  /** @inheritDoc */
  _initializeSource(source, options={}) {
    if ( source instanceof foundry.abstract.DataModel ) source = source.toObject();

    /**
     * A hook event that fires before source data is initialized for an Actor in a compendium.
     * @function dnd5e.initializeActorSource
     * @memberof hookEvents
     * @param {Actor5e} actor   Actor for which the data is being initialized.
     * @param {object} source   Source data being initialized.
     * @param {object} options  Additional data initialization options.
     */
    if ( options.pack ) Hooks.callAll("dnd5e.initializeActorSource", this, source, options);

    // Migrate encounter groups to their own Actor type.
    if ( (source.type === "group") && (source.system?.type?.value === "encounter") ) {
      source.type = "encounter";
      foundry.utils.setProperty(source, "flags.JujutsuLegacy.persistSourceMigration", true);
    }

    return super._initializeSource(source, options);
  }

  /* -------------------------------------------- */
  /*  Methods                                     */
  /* -------------------------------------------- */

  /**
   * Apply package-provided art to a compendium Document.
   * @param {object} source                  The Document's source data.
   * @param {CompendiumCollection} pack      The Document's compendium.
   * @param {CompendiumArtInfo} art          The art being applied.
   */
  static applyCompendiumArt(source, pack, art) {
    const biography = source.system.details?.biography;
    if ( art.credit && biography ) {
      if ( typeof biography.value !== "string" ) biography.value = "";
      biography.value += `<p>${art.credit}</p>`;
    }
  }

  /* -------------------------------------------- */

  /**
   * Format a type object into a string.
   * @param {object} typeData          The type data to convert to a string.
   * @returns {string}
   */
  static formatCreatureType(typeData) {
    if ( typeof typeData === "string" ) return typeData; // Backwards compatibility
    let localizedType;
    if ( typeData.value === "custom" ) localizedType = typeData.custom;
    else if ( typeData.value in CONFIG.DND5E.creatureTypes ) {
      const code = CONFIG.DND5E.creatureTypes[typeData.value];
      localizedType = _loc(typeData.swarm ? code.plural : code.label);
    }
    let type = localizedType;
    if ( typeData.swarm ) {
      type = _loc("DND5E.CreatureSwarmPhrase", {
        size: _loc(CONFIG.DND5E.actorSizes[typeData.swarm].label),
        type: localizedType
      });
    }
    if ( typeData.subtype ) type = `${type} (${typeData.subtype})`;
    return type;
  }

  /* --------------------------------------------- */

  /** @inheritDoc */
  _clearCachedValues() {
    super._clearCachedValues();
    this._lazy = {};
    this._preferredArtwork = null;
    this._preparationWarnings = [];
    this.labels = {};
    this.hiddenItems = new Set();
    this.identifiedItems = new IdentifiedItemsMap();
    this.sourcedItems = new SourcedItemsMap();
  }

  /* --------------------------------------------- */

  /** @inheritDoc */
  prepareEmbeddedDocuments() {
    this._embeddedPreparation = true;
    super.prepareEmbeddedDocuments();
    delete this._embeddedPreparation;
  }

  /* -------------------------------------------- */

  /**
   * Prepares data for a specific skill.
   * @param {string} skillId    The id of the skill to prepare data for.
   * @param {object} [options]  Additional options passed to {@link CreatureTemplate#prepareSkill}.
   * @returns {SkillData}
   * @internal
   */
  _prepareSkill(skillId, options) {
    return this.system.prepareSkill?.(skillId, options) ?? {};
  }

  /* --------------------------------------------- */

  /** @inheritDoc */
  applyActiveEffects(phase) {
    if ( (this.system?.prepareEmbeddedData instanceof Function) && (phase === "initial") ) {
      this.system.prepareEmbeddedData();
    }

    // Pre-collect statuses so they can be reliably used for conditions
    if ( phase === "initial" ) {
      const replacementData = this.getRollData();
      for ( const effect of this.allApplicableEffects() ) {
        if ( effect.statuses.size ) effect.system.evaluateCondition?.(replacementData);
        if ( effect.active ) for ( const statusId of effect.statuses ) this.statuses.add(statusId);
      }
    }

    // Prepare final attributes & spellcasting so that they can be used/modified in "final" phase
    if ( phase === "final" ) {
      this.items.forEach(item => item.prepareFinalAttributes());
      this._prepareSpellcasting();
    }

    super.applyActiveEffects(phase);

    // Ensure conditions are evaluated for all effects even if they don't have changes
    if ( phase === "final" ) {
      const replacementData = this.getRollData();
      for ( const effect of this.allApplicableEffects() ) {
        effect.system.evaluateCondition?.(replacementData);
      }
    }

    if ( (phase !== "initial") || !this.system.isCreature || !dnd5e.settings.tokenSizeSync ) return;

    // Translate this Actor's size category into Token changes
    const sizeData = CONFIG.DND5E.actorSizes[this.system.traits?.size];
    if ( !sizeData ) return;
    const tokenSize = sizeData.token ?? 1;
    this.tokenActiveEffectChanges[phase].push(...["width", "height", "depth"].map(key => ({
      key, phase,
      type: "override",
      priority: 0,
      value: tokenSize,
      conditions: new Filter({ o: "NOT", v: { k: "token.flags.jujutsu-system.lockSize", v: true } })
    })));
  }

  /* -------------------------------------------- */

  /** @inheritDoc */
  *allApplicableEffects() {
    for ( const effect of super.allApplicableEffects() ) {
      if ( effect.parent?.flags?.JujutsuLegacy?.riders?.effect?.includes(effect.id) ) continue;
      if ( effect.applicableType === "Actor" ) yield effect;
    }
  }

  /* -------------------------------------------- */

  /**
   * Fetch an Actor by UUID and obtain a version of it in the World. If the Actor is inside a compendium, check if a
   * version has already been imported before importing it again.
   * @param {string} uuid                  The Actor's UUID.
   * @param {object} [options]
   * @param {string} [options.folderId]    Folder ID for importing the Actor from a compendium.
   * @param {object} [options.origin]      Optionally check if the Actor has a specific origin. If not supplied, any
   *                                       Actor that matches the criteria will be returned.
   * @param {string} [options.origin.key]  The origin property.
   * @param {any} [options.origin.value]   The origin value.
   * @returns {Promise<Actor5e>}
   * @throws {Error}                       If the Actor cannot be found, or cannot be imported.
   */
  static async fetchExisting(uuid, options={}) {
    const { origin, folderId } = options;
    const actor = await fromUuid(uuid);
    if ( !actor ) throw new Error(_loc("DND5E.ACTOR.Warning.NoActor", { uuid }));

    const { actorLink } = actor.prototypeToken;
    const matchesOrigin = !origin || (foundry.utils.getProperty(actor, origin.key) === origin.value);
    if ( !actor.pack && (!actorLink || matchesOrigin) ) return actor;

    // Search world actors to see if any had been previously imported for this purpose.
    // Linked actors must match the origin to be considered.
    const localActor = game.actors.find(a => {
      const matchesOrigin = !origin || (foundry.utils.getProperty(a, origin.key) === origin.value);
      // Has been auto-imported by this process.
      return (a.getFlag("jujutsu-system", "isAutoImported") || a.getFlag("jujutsu-system", "summonedCopy")) // Back-compat
      // User has ownership of existing actor
      && a.isOwner
      // Sourced from the desired actor UUID.
      && ((a._stats?.compendiumSource === uuid) || (a._stats?.duplicateSource === uuid))
      // Unlinked or created from a specific source.
      && (!a.prototypeToken.actorLink || matchesOrigin);
    });
    if ( localActor ) return localActor;

    // Check permissions to create actors.
    if ( !game.user.can("ACTOR_CREATE") ) throw new Error(_loc("DND5E.ACTOR.Warning.CreateActor"));

    // No suitable world actor was found, create one.
    if ( actor.pack ) {
      // Template actor resides only in a compendium, import the actor into the world.
      return game.actors.importFromCompendium(game.packs.get(actor.pack), actor.id, {
        "flags.jujutsu-system.isAutoImported": true,
        folder: game.folders.get(folderId) ?? null
      }, { keepId: false });
    } else {
      // A linked world actor was found. Create a copy to avoid affecting the original.
      return actor.clone({
        "flags.jujutsu-system.isAutoImported": true,
        folder: game.folders.get(folderId) ?? null,
        "_stats.compendiumSource": actor._stats.compendiumSource,
        "_stats.duplicateSource": actor.uuid
      }, { save: true });
    }
  }

  /* -------------------------------------------- */

  /**
   * Select appropriate artwork to display on sheet & chat cards based on `showTokenPortrait` flag.
   * @returns {Promise<{ src: string, token: boolean, isRandom: boolean, isVideo: boolean }>}
   */
  async getPreferredArtwork() {
    if ( !this._preferredArtwork ) {
      const showTokenPortrait = this.getFlag("jujutsu-system", "showTokenPortrait") === true;
      const token = this.isToken ? this.token : this.prototypeToken;
      const defaultArtwork = Actor.implementation.getDefaultArtwork(this._source)?.img;
      let texture = token?.texture.src;
      if ( showTokenPortrait && token?.randomImg ) {
        const images = await this.getTokenImages();
        texture = images[Math.floor(Math.random() * images.length)];
      }
      const src = (showTokenPortrait ? texture : this.img) ?? defaultArtwork;
      this._preferredArtwork = {
        src,
        isRandom: showTokenPortrait && token?.randomImg,
        isToken: showTokenPortrait,
        isVideo: foundry.helpers.media.VideoHelper.hasVideoExtension(src)
      };
    }
    return this._preferredArtwork;
  }

  /* -------------------------------------------- */

  /** @inheritDoc */
  prepareDerivedData() {
    const origin = this.getFlag("jujutsu-system", "summon.origin");
    if ( origin && this.token?.id ) {
      const { collection, primaryId } = foundry.utils.parseUuid(origin);
      dnd5e.registry.summons.track(collection?.get?.(primaryId)?.uuid, this.uuid);
    }
  }

  /* -------------------------------------------- */

  /**
   * Calculate the DC of a concentration save required for a given amount of damage.
   * @param {number} damage  Amount of damage taken.
   * @returns {number}       DC of the required concentration save.
   */
  getConcentrationDC(damage) {
    return Math.clamp(
      Math.floor(damage / 2), 10, dnd5e.settings.rulesVersion === "modern" ? 30 : Infinity
    );
  }

  /* -------------------------------------------- */

  /**
   * Return the amount of experience required to gain a certain character level.
   * @param {number} level  The desired level.
   * @returns {number}      The XP required.
   */
  getLevelExp(level) {
    const levels = CONFIG.DND5E.CHARACTER_EXP_LEVELS;
    return levels[Math.min(level, levels.length - 1)];
  }

  /* -------------------------------------------- */

  /**
   * Return the amount of experience granted by killing a creature of a certain CR.
   * @param {number|null} cr  The creature's challenge rating.
   * @returns {number|null}   The amount of experience granted per kill.
   */
  getCRExp(cr) {
    if ( cr === null ) return null;
    if ( cr < 1.0 ) return Math.max(200 * cr, 10);
    return CONFIG.DND5E.CR_EXP_LEVELS[cr] ?? Object.values(CONFIG.DND5E.CR_EXP_LEVELS).pop();
  }

  /* -------------------------------------------- */

  /**
   * @inheritdoc
   * @param {RollDataOptions} [options]
   * @returns {ActorRollData}
   */
  getRollData(options={}) {
    let rollData;
    if ( this.system.getRollData ) rollData = this.system.getRollData(options);
    else rollData = { ...super.getRollData() };
    rollData.flags = this.flags;
    rollData.name = this.name;
    if ( options.roll ) rollData.roll ??= {};
    rollData.statuses = {};
    for ( const status of this.statuses ) {
      if ( ConditionData.hasLevels(status) ) rollData.statuses[status] = this.system.conditions[status];
      else if ( status === "concentrating" ) rollData.statuses[status] = this.concentration.effects.size;
      else rollData.statuses[status] = 1;
    }
    return rollData;
  }

  /* -------------------------------------------- */

  /**
   * Is this actor under the effect of this property from some status or due to its level of a condition?
   * @param {string} key      A key in `DND5E.conditionEffects`.
   * @returns {boolean}       Whether the actor is affected.
   */
  hasConditionEffect(key) {
    const props = CONFIG.DND5E.conditionEffects[key] ?? new Set();
    const conditions = this.system.conditions ?? {};
    const imms = this.system.traits?.ci?.value ?? new Set();

    const applyCondition = prop => {
      let [status, level] = prop.split("-");

      // If immune, naturally never applied.
      if ( imms.has(status) ) return false;

      // You cannot be dodging while incapacitated or while you have no movement.
      if ( status === "dodging" ) {
        if ( this.statuses.has("incapacitated") ) return false;
        if ( CONFIG.DND5E.conditionEffects.noMovement?.some(applyCondition) ) return false;
      }

      // If not leveled, or not requiring a level, need only check if status is active.
      if ( !ConditionData.hasLevels(status) || !level ) return this.statuses.has(status);

      // If leveled condition, needs to be high enough.
      return Number(level) <= conditions[status];
    };

    return props.some(applyCondition);
  }

  /* -------------------------------------------- */
  /*  Spellcasting Preparation                    */
  /* -------------------------------------------- */

  /**
   * Prepare data related to the spell-casting capabilities of the Actor.
   * Mutates the value of the system.spells object. Must be called after final item preparation.
   * @protected
   */
  _prepareSpellcasting() {
    if ( !this.system.spells ) return;

    // Translate the list of classes into spellcasting progression
    const progression = Object.values(CONFIG.DND5E.spellcasting).reduce((acc, model) => {
      if ( model.slots ) acc[model.key] = 0;
      return acc;
    }, {});
    const types = {};

    // Grab all classes with spellcasting
    const classes = this.itemTypes.class.filter(cls => {
      const type = cls.spellcasting.type;
      if ( !type ) return false;
      types[type] = (types[type] ?? 0) + 1;
      return true;
    });

    for ( const cls of classes ) {
      this.constructor.computeClassProgression(progression, cls, { actor: this, count: types[cls.spellcasting.type] });
    }

    if ( this.system.isNPC && ("spell" in (this.system.attributes ?? {})) ) {
      const level = Object.values(progression).find(_ => _);
      if ( level ) this.system.attributes.spell.level = level;
      else if ( this.system.attributes.spell.level > 0 ) {
        const methods = this.itemTypes.spell.reduce((m, s) => {
          if ( s.system.level && CONFIG.DND5E.spellcasting[s.system.method]?.slots ) m.add(s.system.method);
          return m;
        }, new Set());
        if ( methods.size ) methods.forEach(k => progression[k] = this.system.attributes.spell.level);
        else progression.spell = this.system.attributes.spell.level;
      }
    }

    for ( const [type, model] of Object.entries(CONFIG.DND5E.spellcasting) ) {
      if ( !model.slots ) continue;
      // Assume spellcasting methods without progression are based on character level rather than class level.
      if ( foundry.utils.isEmpty(model.progression) ) model.computeProgression(progression, this);
      this.constructor.prepareSpellcastingSlots(this.system.spells, type, progression, { actor: this });
    }
  }

  /* -------------------------------------------- */

  /**
   * Contribute to the actor's spellcasting progression.
   * @param {object} progression                             Spellcasting progression data. *Will be mutated.*
   * @param {Item5e} cls                                     Class for whom this progression is being computed.
   * @param {object} [config={}]
   * @param {Actor5e} [config.actor]                         Actor for whom the data is being prepared.
   * @param {SpellcastingDescription} [config.spellcasting]  Spellcasting descriptive object.
   * @param {number} [config.count=1]                        Number of classes with this type of spellcasting.
   */
  static computeClassProgression(progression, cls, { actor, spellcasting, count=1 }={}) {
    const type = cls.spellcasting.type;
    spellcasting ??= cls.spellcasting;

    /**
     * A hook event that fires while computing the spellcasting progression for each class on each actor.
     * The actual hook names include the spellcasting type (e.g. `dnd5e.computeLeveledProgression`).
     * @param {object} progression                    Spellcasting progression data. *Will be mutated.*
     * @param {Actor5e|void} actor                    Actor for whom the data is being prepared.
     * @param {Item5e} cls                            Class for whom this progression is being computed.
     * @param {SpellcastingDescription} spellcasting  Spellcasting descriptive object.
     * @param {number} count                          Number of classes with this type of spellcasting.
     * @returns {boolean}  Explicitly return false to prevent default progression from being calculated.
     * @function dnd5e.computeSpellcastingProgression
     * @memberof hookEvents
     */
    const allowed = Hooks.call(
      `dnd5e.compute${type.capitalize()}Progression`, progression, actor, cls, spellcasting, count
    );
    const model = CONFIG.DND5E.spellcasting[type];
    if ( (allowed === false) || !model.slots ) return;

    // Otherwise proceed with calculation.
    model.computeProgression(progression, actor, cls, spellcasting, count);
  }

  /* -------------------------------------------- */

  /**
   * Prepare actor's spell slots using progression data.
   * @param {object} spells           The `data.spells` object within actor's data. *Will be mutated.*
   * @param {string} type             Type of spellcasting slots being prepared.
   * @param {object} progression      Spellcasting progression data.
   * @param {object} [config]
   * @param {Actor5e} [config.actor]  Actor for whom the data is being prepared.
   */
  static prepareSpellcastingSlots(spells, type, progression, { actor }={}) {
    /**
     * A hook event that fires to convert the provided spellcasting progression into spell slots.
     * The actual hook names include the spellcasting type (e.g. `dnd5e.prepareLeveledSlots`).
     * @param {object} spells        The `data.spells` object within actor's data. *Will be mutated.*
     * @param {Actor5e|void} actor   Actor for whom the data is being prepared, if any.
     * @param {object} progression   Spellcasting progression data.
     * @returns {boolean}            Explicitly return false to prevent default preparation from being performed.
     * @function dnd5e.prepareSpellcastingSlots
     * @memberof hookEvents
     */
    const allowed = Hooks.call(`dnd5e.prepare${type.capitalize()}Slots`, spells, actor, progression);
    if ( allowed === false ) return;
    const model = CONFIG.DND5E.spellcasting[type];

    // Otherwise proceed with calculation.
    if ( model.slots ) model.prepareSlots(spells, actor, progression);
  }

  /* -------------------------------------------- */
  /*  Gameplay Mechanics                          */
  /* -------------------------------------------- */

  /** @override */
  async modifyTokenAttribute(attribute, value, isDelta, isBar) {
    if ( attribute === "attributes.hp" ) {
      const hp = this.system.attributes.hp;
      const delta = isDelta ? (-1 * value) : (hp.value + hp.temp) - value;
      return this.applyDamage(delta, { isDelta });
    } else if ( attribute.startsWith(".") ) {
      const item = fromUuidSync(attribute, { relative: this });
      let newValue = item?.system.uses?.value ?? 0;
      if ( isDelta ) newValue += value;
      else newValue = value;
      return item?.update({ "system.uses.spent": item.system.uses.max - newValue });
    }
    return super.modifyTokenAttribute(attribute, value, isDelta, isBar);
  }

  /* -------------------------------------------- */

  /**
   * Apply a certain amount of damage or healing to the health pool for Actor
   * @param {DamageDescription[]|number} damages     Damages to apply.
   * @param {DamageApplicationOptions} [options={}]  Damage application options.
   * @returns {Promise<Actor5e>}                     A Promise which resolves once the damage has been applied.
   */
  async applyDamage(damages, options={}) {
    const hp = this.system.attributes.hp;
    const hpSource = this.system._source.attributes.hp;
    if ( !hp ) return this; // Group actors don't have HP at the moment

    if ( Number.isNumeric(damages) ) {
      damages = [{ value: damages }];
      options.ignore ??= true;
    }

    damages = this.calculateDamage(damages, options);
    if ( !damages ) return this;

    let { amount } = damages;
    const { temp, tempMax } = damages;
    const impulse = Ruleset.isV2() ? this.getFlag("jujutsu-system", "explosaoDefensivaPendente") : null;
    const consumeImpulse = impulse?.physicalImpulse === true && amount > 0 && Number(impulse.reducao) > 0;
    if (consumeImpulse) amount = Math.max(0, amount - Number(impulse.reducao));
    const shield = Ruleset.isV2() && amount > 0
      ? absorbShieldDamage(this.system.armorPoints?.value, amount) : null;
    const remaining = shield?.remaining ?? amount;
    const deltaTemp = remaining > 0 ? Math.min(hp.temp, remaining) : 0;
    const deltaHP = Math.clamp(remaining - deltaTemp, -hp.damage + tempMax, hp.value - tempMax);
    const updates = {
      "system.attributes.hp.temp": hp.temp - deltaTemp,
      "system.attributes.hp.tempmax": hpSource.tempmax - tempMax,
      "system.attributes.hp.value": hp.value - deltaHP
    };
    if (consumeImpulse) updates["flags.jujutsu-system.-=explosaoDefensivaPendente"] = null;
    if (shield?.spent) updates["system.armorPoints.value"] = shield.value;

    if ( temp > updates["system.attributes.hp.temp"] ) updates["system.attributes.hp.temp"] = temp;

    /**
     * A hook event that fires before damage is applied to an actor.
     * @param {Actor5e} actor                     Actor the damage will be applied to.
     * @param {number} amount                     Amount of damage that will be applied.
     * @param {object} updates                    Distinct updates to be performed on the actor.
     * @param {DamageApplicationOptions} options  Additional damage application options.
     * @returns {boolean}                         Explicitly return `false` to prevent damage application.
     * @function dnd5e.preApplyDamage
     * @memberof hookEvents
     */
    if ( Hooks.call("dnd5e.preApplyDamage", this, amount, updates, options) === false ) return this;

    // Delegate damage application to a hook
    // TODO: Replace this in the future with a better modifyTokenAttribute function in the core
    if ( Hooks.call("modifyTokenAttribute", {
      attribute: "attributes.hp",
      value: amount,
      isDelta: false,
      isBar: true
    }, updates) === false ) return this;

    // O escopo de flags do sistema é "jujutsu-system" — ler "dnd5e" lança
    // "Flag scope not valid" e quebra o botão Aplicar da bandeja de dano
    // (que passa a mensagem como options.origin). Nenhum código grava esse
    // flag hoje; a leitura permanece para compatibilidade futura.
    const context = options.origin?.getFlag?.("jujutsu-system", "context");
    await this.update(updates, context ? { jujutsuSystem: context } : {});

    /**
     * A hook event that fires after damage has been applied to an actor.
     * @param {Actor5e} actor                     Actor that has been damaged.
     * @param {number} amount                     Amount of damage that has been applied.
     * @param {DamageApplicationOptions} options  Additional damage application options.
     * @function dnd5e.applyDamage
     * @memberof hookEvents
     */
    Hooks.callAll("dnd5e.applyDamage", this, amount, options);

    return this;
  }

  /* -------------------------------------------- */

  /**
   * Calculate the damage that will be applied to this actor.
   * @param {DamageDescription[]} damages            Damages to calculate.
   * @param {DamageApplicationOptions} [options={}]  Damage calculation options.
   * @returns {DamageSummary|false}                  New damage descriptions with changes applied, or `false` if the
   *                                                 calculation was canceled.
   */
  calculateDamage(damages, options={}) {
    damages = foundry.utils.deepClone(damages);
    damages.amount = 0;
    damages.temp = 0;
    damages.tempMax = 0;

    /**
     * A hook event that fires before damage amount is calculated for an actor.
     * @param {Actor5e} actor                     The actor being damaged.
     * @param {DamageDescription[]} damages       Damage descriptions.
     * @param {DamageApplicationOptions} options  Additional damage application options.
     * @returns {boolean}                         Explicitly return `false` to prevent damage application.
     * @function dnd5e.preCalculateDamage
     * @memberof hookEvents
     */
    if ( Hooks.call("dnd5e.preCalculateDamage", this, damages, options) === false ) return false;

    const multiplier = options.multiplier ?? 1;
    const { isHealing } = options.originatingMessage?.system ?? {};
    let treatAs = isHealing === undefined ? (options.only ?? "damage") : isHealing ? "healing" : "damage";
    const legacyType = options.originatingMessage?.flags?.JujutsuLegacy?.roll?.type;
    if ( isHealing === undefined && legacyType ) treatAs = legacyType === "healing" ? "healing" : "damage";

    const skipped = type => {
      if ( type === "maximum" ) return options.only ? options.only !== treatAs : false;
      if ( options.only === "damage" ) return type in CONFIG.DND5E.healingTypes;
      if ( options.only === "healing" ) return type in CONFIG.DND5E.damageTypes;
      return false;
    };

    const dm = Ruleset.isV2() ? {} : this.system.traits?.dm ?? {};
    const rollData = this.getRollData({ deterministic: true });
    const modifications = Object.entries(dm.amount ?? {}).reduce((obj, [type, formula]) => {
      obj[type] = simplifyBonus(formula, rollData);
      return obj;
    }, {});
    const applyModification = (d, type=d.type) => {
      if ( !modifications[type] || this.#changeIsIgnored("modification", type, { options }) ) return;
      const originalValue = d.value;
      if ( Math.sign(d.value) !== Math.sign(d.value + modifications[type]) ) d.value = 0;
      else d.value += modifications[type];
      (d.active[type === "ALL" ? "all" : "type"] ??= {}).modification = true;
      modifications[type] += originalValue - d.value;
    };

    damages.forEach(d => {
      d.active ??= {};

      // Skip damage types with immunity
      if ( skipped(d.type) || (!Ruleset.isV2() && this.#changeHasEffect("immunity", d, { options })) ) {
        d.value = 0;
        d.active.multiplier = 0;
        return;
      }

      // Apply damage modification
      if ( !CONFIG.DND5E.damageTypes[d.type]?.isPhysical || !d.properties?.size
        || !dm.bypasses?.intersection(d.properties).size ) {
        applyModification(d);
        if ( !(d.type in CONFIG.DND5E.healingTypes) ) applyModification(d, "ALL");
      }

      let damageMultiplier = multiplier;
      let appliedDamage = d.value * multiplier;

      // Apply damage resistance
      if ( !Ruleset.isV2() && this.#changeHasEffect("resistance", d, { options }) ) {
        damageMultiplier /= 2;
        appliedDamage = Math.trunc(appliedDamage / 2);
      }

      // Apply damage vulnerability
      if ( !Ruleset.isV2() && this.#changeHasEffect("vulnerability", d, { options }) ) {
        damageMultiplier *= 2;
        appliedDamage *= 2;
      }

      // Negate healing types
      if ( (options.invertHealing !== false) && ((d.type === "healing")
        || ((d.type === "maximum") && (treatAs === "healing"))) ) {
        damageMultiplier *= -1;
        appliedDamage *= -1;
      }

      d.value = appliedDamage;
      d.active.multiplier = (d.active.multiplier ?? 1) * damageMultiplier;
      if ( d.type === "temphp" ) damages.temp += d.value;
      else if ( d.type === "maximum" ) damages.tempMax += d.value;
      else damages.amount += d.value;
    });

    if (Ruleset.isV2()) {
      applyNumericResistances(this, damages, options);
      damages.amount = damages.reduce((sum, damage) => ["temphp", "maximum"].includes(damage.type) ? sum : sum + damage.value, 0);
    }
    if ( damages.tempMax < 0 ) damages.amount += damages.tempMax;
    damages.amount = Math.trunc(damages.amount);

    // Apply damage threshold
    if ( ((damages.amount > 0) && (damages.amount < (this.system.attributes?.hp?.dt ?? -Infinity)))
      && !((options.ignore === true) || options.ignore?.threshold) ) {
      damages.amount = 0;
      damages.forEach(d => {
        d.value = 0;
        d.active.multiplier = 0;
        d.active.threshold = true;
      });
    }

    /**
     * A hook event that fires after damage values are calculated for an actor.
     * @param {Actor5e} actor                     The actor being damaged.
     * @param {DamageSummary} damages             Damage descriptions.
     * @param {DamageApplicationOptions} options  Additional damage application options.
     * @returns {boolean}                         Explicitly return `false` to prevent damage application.
     * @function dnd5e.calculateDamage
     * @memberof hookEvents
     */
    if ( Hooks.call("dnd5e.calculateDamage", this, damages, options) === false ) return false;

    return damages;
  }

  /* -------------------------------------------- */

  /**
   * Determine whether a specific type of change to a damage value will have an effect.
   * @param {DamageAffectCategory} category                  Type of change that should be considered.
   * @param {DamageDescription|string} damage                Damage description to consider or a specific type.
   * @param {object} [options={}]
   * @param {DamageApplicationOptions} [options.options={}]  Damage application options.
   * @param {boolean} [options.skipDowngrade=false]          Should downgrades be skipped?
   * @returns {boolean}
   */
  #changeHasEffect(category, damage, { options={}, skipDowngrade=false }={}) {
    const config = this.system.traits?.[`d${category.slice(0, 1)}`];
    const downgrade = type => options.downgrade === true || options.downgrade?.has?.(type);
    const setActive = type => {
      if ( damage.active ) {
        damage.active[type] ??= {};
        damage.active[type][category] = true;
      }
      return true;
    };
    const type = typeof damage === "string" ? damage : damage.type;
    const isHealingType = type in CONFIG.DND5E.healingTypes;

    // If category is resistance, check for downgraded immunities
    if ( category === "resistance" ) {
      if ( !isHealingType && downgrade("ALL") && this.#changeHasEffect("immunity", "ALL", { skipDowngrade: true }) ) {
        return setActive("all");
      }
      if ( downgrade(type) && this.#changeHasEffect("immunity", type, { skipDowngrade: true }) ) {
        return setActive("type");
      }
    }

    // If damage type is physical and bypass present in properties, skip further checks
    if ( CONFIG.DND5E.damageTypes[type]?.isPhysical && damage.properties?.size
      && config?.bypasses?.intersection(damage.properties)?.size ) return false;

    // If all damage resistance is present and not ignored (healing types are excluded from "All Damage")
    if ( !isHealingType
      && !this.#changeIsIgnored(category, "ALL", { options, skipDowngrade })
      && config?.value.has("ALL") ) {
      return setActive("all");
    }

    // If specific type damage resistance is present and not ignored
    if ( !this.#changeIsIgnored(category, type, { options, skipDowngrade }) && config?.value.has(type) ) {
      return setActive("type");
    }

    return false;
  }

  /* -------------------------------------------- */

  /**
   * Determine whether a specific damage change type should be ignored.
   * @param {DamageAffectCategory} category                  Type of change that should be considered.
   * @param {string} type                                    Specific damage type to consider.
   * @param {object} [options={}]
   * @param {DamageApplicationOptions} [options.options={}]  Damage application options.
   * @param {boolean} [options.skipDowngrade=false]          Should downgrades not be taken into account?
   * @returns {boolean}
   */
  #changeIsIgnored(category, type, { options={}, skipDowngrade=false }={}) {
    const downgrade = type => options.downgrade === true || options.downgrade?.has?.(type);

    // All categories are ignored
    if ( options.ignore === true ) return true;

    // Specific category is ignored, or specific category has this type in its ignore list
    if ( (options.ignore?.[category] === true) || (options.ignore?.[category]?.has?.(type)) ) return true;

    // When downgrading, always ignore immunities unless `skipDowngrade` option is set
    if ( (category === "immunity") && downgrade(type) && !skipDowngrade ) return true;

    // When downgrading, resistances should be decided by whether immunity is applied
    if ( (category === "resistance") && downgrade(type) && !this.#changeHasEffect("immunity", type) ) return true;

    return false;
  }

  /* -------------------------------------------- */

  /**
   * Apply a certain amount of temporary hit point, but only if it's more than the actor currently has.
   * @param {number} amount       An amount of temporary hit points to set
   * @returns {Promise<Actor5e>}  A Promise which resolves once the temp HP has been applied
   */
  async applyTempHP(amount=0) {
    amount = parseInt(amount);
    const hp = this.system.attributes.hp;

    // Update the actor if the new amount is greater than the current
    const tmp = parseInt(hp.temp) || 0;
    return amount > tmp ? this.update({"system.attributes.hp.temp": amount}) : this;
  }

  /* -------------------------------------------- */

  /**
   * Get a color used to represent the current hit points of an Actor.
   * @param {number} current        The current HP value
   * @param {number} max            The maximum HP value
   * @returns {Color}               The color used to represent the HP percentage
   */
  static getHPColor(current, max) {
    const pct = Math.clamp(current, 0, max) / max;
    return Color.fromRGB([(1-(pct/2)), pct, 0]);
  }

  /* -------------------------------------------- */

  /**
   * Initiate concentration on an item.
   * @param {Activity} activity                  The activity on which to being concentration.
   * @param {object} [effectData]                Effect data to merge into the created effect.
   * @returns {Promise<ActiveEffect5e|void>}     A promise that resolves to the created effect.
   */
  async beginConcentrating(activity, effectData={}) {
    effectData = ActiveEffect5e.createConcentrationEffectData(activity, effectData);

    /**
     * A hook that is called before a concentration effect is created.
     * @function dnd5e.preBeginConcentrating
     * @memberof hookEvents
     * @param {Actor5e} actor         The actor initiating concentration.
     * @param {Item5e} item           The item that will be concentrated on.
     * @param {object} effectData     Data used to create the ActiveEffect.
     * @param {Activity} activity     The activity that triggered the concentration.
     * @returns {boolean}             Explicitly return false to prevent the effect from being created.
     */
    if ( Hooks.call("dnd5e.preBeginConcentrating", this, activity.item, effectData, activity) === false ) return;

    const effect = await ActiveEffect5e.create(effectData, { parent: this });

    /**
     * A hook that is called after a concentration effect is created.
     * @function dnd5e.createConcentrating
     * @memberof hookEvents
     * @param {Actor5e} actor             The actor initiating concentration.
     * @param {Item5e} item               The item that is being concentrated on.
     * @param {ActiveEffect5e} effect     The created ActiveEffect instance.
     * @param {Activity} activity         The activity that triggered the concentration.
     */
    Hooks.callAll("dnd5e.beginConcentrating", this, activity.item, effect, activity);

    return effect;
  }

  /* -------------------------------------------- */

  /**
   * End concentration on an item.
   * @param {Item5e|ActiveEffect5e|string} [target]    An item or effect to end concentration on, or id of an effect.
   *                                                   If not provided, all maintained effects are removed.
   * @returns {Promise<ActiveEffect5e[]>}              A promise that resolves to the deleted effects.
   */
  async endConcentration(target) {
    let effect;
    const { effects } = this.concentration;

    if ( !target ) {
      return effects.reduce(async (acc, effect) => {
        acc = await acc;
        return acc.concat(await this.endConcentration(effect));
      }, []);
    }

    if ( foundry.utils.getType(target) === "string" ) effect = effects.find(e => e.id === target);
    else if ( target instanceof ActiveEffect5e ) effect = effects.has(target) ? target : null;
    else if ( target instanceof Item5e ) {
      effect = effects.find(e => {
        const data = e.getFlag("jujutsu-system", "item") ?? {};
        return (data.id === target._id) || (data.data?._id === target._id);
      });
    }
    if ( !effect ) return [];

    /**
     * A hook that is called before a concentration effect is deleted.
     * @function dnd5e.preEndConcentration
     * @memberof hookEvents
     * @param {Actor5e} actor             The actor ending concentration.
     * @param {ActiveEffect5e} effect     The ActiveEffect that will be deleted.
     * @returns {boolean}                 Explicitly return false to prevent the effect from being deleted.
     */
    if ( Hooks.call("dnd5e.preEndConcentration", this, effect) === false) return [];

    await effect.delete();

    /**
     * A hook that is called after a concentration effect is deleted.
     * @function dnd5e.endConcentration
     * @memberof hookEvents
     * @param {Actor5e} actor             The actor ending concentration.
     * @param {ActiveEffect5e} effect     The ActiveEffect that was deleted.
     */
    Hooks.callAll("dnd5e.endConcentration", this, effect);

    return [effect];
  }

  /* -------------------------------------------- */

  /**
   * Create a chat message for this actor with a prompt to challenge concentration.
   * @param {object} [options]
   * @param {number} [options.dc]         The target value of the saving throw.
   * @param {string} [options.ability]    An ability to use instead of the default.
   * @returns {Promise<ChatMessage5e>}    A promise that resolves to the created chat message.
   */
  async challengeConcentration({ dc=10, ability=null }={}) {
    const isConcentrating = this.concentration.effects.size > 0;
    if ( !isConcentrating ) return null;

    const button = { dc, format: "short", type: "concentration" };
    if ( ability in CONFIG.DND5E.abilities ) button.ability = ability;

    return ChatMessage.implementation.create({
      speaker: ChatMessage.implementation.getSpeaker({ actor: this }),
      system: { broadcast: false, buttons: [button] },
      type: "prompt",
      whisper: game.users.filter(user => this.testUserPermission(user, "OWNER"))
    });
  }

  /* -------------------------------------------- */

  /**
   * Create a chat message for this actor with a prompt to end concentration.
   * @returns {Promise<ChatMessage5e|null>}  A promise that resolves to the created chat message.
   */
  async promptConcentrationEnd() {
    const isConcentrating = this.concentration.effects.size > 0;
    if ( !isConcentrating ) return null;

    return ChatMessage.implementation.create({
      speaker: ChatMessage.implementation.getSpeaker({ actor: this }),
      system: { broadcast: false, buttons: [{ type: "endConcentration" }] },
      type: "prompt",
      whisper: game.users.filter(user => this.testUserPermission(user, "OWNER"))
    });
  }

  /* -------------------------------------------- */

  /**
   * Determine whether the provided ability is usable for remarkable athlete.
   * @param {string} ability  Ability type to check.
   * @returns {boolean}       Whether the actor has the remarkable athlete flag and the ability is physical.
   * @private
   */
  _isRemarkableAthlete(ability) {
    return (dnd5e.settings.rulesVersion === "legacy") && this.getFlag("jujutsu-system", "remarkableAthlete")
      && CONFIG.DND5E.characterFlags.remarkableAthlete.abilities.includes(ability);
  }

  /* -------------------------------------------- */
  /*  Rolling                                     */
  /* -------------------------------------------- */

  /**
   * Add the reduction to this roll from conditions.
   * @param {string[]} parts  Roll parts.
   * @param {object} data     Roll data.
   */
  addRollExhaustion(parts, data) {
    foundry.utils.logCompatibilityWarning(
      "The `addRollExhaustion` method has been deprecated in favor of a `addConditionRollReduction`.",
      { since: "DnD5e 6.0", until: "DnD5e 6.2", once: true }
    );
    this.addConditionRollReduction(parts, data);
  }

  /* -------------------------------------------- */

  /**
   * Add the reduction to this roll from conditions.
   * @param {string[]} parts  Roll parts.
   * @param {object} data     Roll data.
   */
  addConditionRollReduction(parts, data) {
    for ( const [status, reduction] of Object.entries(this.conditionRollReductions) ) {
      parts.push(`@reductions.${status}`);
      data.reductions ??= {};
      data.reductions[status] = reduction;
    }
  }

  /* -------------------------------------------- */

  /**
   * Handle rolling a saving throw as part of a requested group saving throw.
   * @param {Actor5e} actor                                    The actor.
   * @param {ChatMessage5e} request                            The request message.
   * @param {Partial<AbilityRollProcessConfiguration>} config  Roll configuration.
   * @param {RequestOptions5e} [requestOptions]                Options that configure the request.
   * @returns {Promise<ChatMessage5e|null>}
   */
  static async handleSavingThrowRequest(actor, request, config, { event }={}) {
    const data = {};
    foundry.utils.setProperty(data, "flags.jujutsu-system.requestResult", { actorUuid: actor.uuid, requestId: request.id });
    const [roll] = (await actor.rollSavingThrow({ ...config, event }, {}, { data })) ?? [];
    return roll?.parent ?? null;
  }

  /* -------------------------------------------- */

  /**
   * Handle rolling a skill as part of a requested group check.
   * @param {Actor5e} actor                                      The actor.
   * @param {ChatMessage5e} request                              The request message.
   * @param {Partial<SkillToolRollProcessConfiguration>} config  Roll configuration.
   * @param {RequestOptions5e} [requestOptions]                  Options that configure the request.
   * @returns {Promise<ChatMessage5e|null>}
   */
  static async handleSkillCheckRequest(actor, request, config, { event }={}) {
    const data = {};
    foundry.utils.setProperty(data, "flags.jujutsu-system.requestResult", { actorUuid: actor.uuid, requestId: request.id });
    const [roll] = (await actor.rollSkill({ ...config, event }, {}, { data })) ?? [];
    return roll?.parent ?? null;
  }

  /* -------------------------------------------- */

  /**
   * Roll an ability check with a skill.
   * @param {Partial<SkillToolRollProcessConfiguration>} config  Configuration information for the roll.
   * @param {Partial<SkillToolRollDialogConfiguration>} dialog   Configuration for the roll dialog.
   * @param {Partial<BasicRollMessageConfiguration>} message     Configuration for the roll message.
   * @returns {Promise<D20Roll[]|null>}                          A Promise which resolves to the created Roll instance.
   */
  async rollSkill(config={}, dialog={}, message={}) {
    if ( (typeof this.system.rollSkill === "function")
      && (await this.system.rollSkill(config, dialog, message) === false) ) return null;
    if ( !this.system.skills ) return null;
    const skillLabel = CONFIG.DND5E.skills[config.skill]?.label ?? "";
    if ( config.ability === "spellcasting" ) config = { ...config, ability: this.spellcastingAbility };
    const ability = config.ability ?? this.system.skills[config.skill]?.ability
      ?? CONFIG.DND5E.skills[config.skill]?.ability ?? "";
    const abilityLabel = CONFIG.DND5E.abilities[ability]?.label ?? "";
    const dialogConfig = foundry.utils.mergeObject({
      options: {
        window: {
          title: _loc("DND5E.SkillPromptTitle", { skill: skillLabel, ability: abilityLabel }),
          subtitle: this.name
        }
      }
    }, dialog);
    return this.#rollSkillTool("skill", config, dialogConfig, message);
  }

  /* -------------------------------------------- */

  /**
   * Roll an ability check with a tool.
   * @param {Partial<SkillToolRollProcessConfiguration>} config  Configuration information for the roll.
   * @param {Partial<SkillToolRollDialogConfiguration>} dialog   Configuration for the roll dialog.
   * @param {Partial<BasicRollMessageConfiguration>} message     Configuration for the roll message.
   * @returns {Promise<D20Roll[]|null>}                          A Promise which resolves to the created Roll instance.
   */
  async rollToolCheck(config={}, dialog={}, message={}) {
    if ( config.ability === "spellcasting" ) config = { ...config, ability: this.spellcastingAbility };
    const toolLabel = Trait.keyLabel(config.tool, { trait: "tool" }) ?? "";
    const dialogConfig = foundry.utils.mergeObject({
      options: {
        window: {
          title: _loc("DND5E.ToolPromptTitle", { tool: toolLabel }),
          subtitle: this.name
        }
      }
    }, dialog);
    return this.#rollSkillTool("tool", config, dialogConfig, message);
  }

  /* -------------------------------------------- */

  /**
   * Shared rolling functionality between skill & tool checks.
   * @param {"skill"|"tool"} type                                Type of roll.
   * @param {Partial<SkillToolRollProcessConfiguration>} config  Configuration information for the roll.
   * @param {Partial<SkillToolRollDialogConfiguration>} dialog   Configuration for the roll dialog.
   * @param {Partial<BasicRollMessageConfiguration>} message     Configuration for the roll message.
   * @returns {Promise<D20Roll[]|null>}                          A Promise which resolves to the created Roll instance.
   */
  async #rollSkillTool(type, config={}, dialog={}, message={}) {
    let oldFormat = false;
    const name = type === "skill" ? "Skill" : "ToolCheck";

    const skillConfig = CONFIG.DND5E.skills[config.skill];
    const toolConfig = CONFIG.DND5E.tools[config.tool] ?? CONFIG.DND5E.vehicleTypes[config.tool];
    if ( ((type === "skill") && !skillConfig) || ((type === "tool") && !toolConfig) ) {
      return this.rollAbilityCheck(config, dialog, message);
    }

    const relevant = type === "skill" ? this.system.skills?.[config.skill] : this.system.tools?.[config.tool];
    const alternate = type === "skill" ? this.system.tools?.[config.tool] : this.system.skills?.[config.skill];
    const abilityId = config.ability ?? relevant?.ability
      ?? (type === "skill" ? skillConfig.ability : toolConfig.ability) ?? "int";
    const hostActor = this.isPolymorphed && this.flags?.["jujutsu-system"]?.transformOptions?.mergeSkills && (type === "skill")
      ? game.actors.get(this.flags["jujutsu-system"]?.originalActor) : null;
    const buildConfig = this._buildSkillToolConfig.bind(this, type, hostActor);
    const doubleProf = !!relevant?.prof.hasProficiency && !!alternate?.prof.hasProficiency;
    const pace = TravelField.getTravelPaceMode(config.pace, config.skill);

    const rollData = this.getRollData({ roll: true });
    rollData.roll = {
      ability: abilityId,
      proficient: dnd5e.dataModels.actor.CommonTemplate
        .calculateSkillToolProficiency(this, abilityId, config).multiplier >= 1,
      [type]: config[type],
      type
    };
    const { advantage, disadvantage } = D20RollModificationField.combineFields(this.system, [
      `abilities.${abilityId}.check.roll`,
      "rolls.ability.check",
      `rolls.ability.${type}`,
      `${type}s.${type === "skill" ? config.skill : config.tool}.roll`
    ], {
      advantages: { count: Number(doubleProf) + Number(pace.advantage) },
      disadvantages: { count: Number(pace.disadvantage) },
      rules: { category: "check", actor: this, rollData }
    });

    const rollConfig = foundry.utils.mergeObject({
      advantage, disadvantage,
      ability: relevant?.ability ?? (type === "skill" ? skillConfig.ability : toolConfig?.ability),
      halflingLucky: this.getFlag("jujutsu-system", "halflingLucky"),
      reliableTalent: (relevant?.value >= 1) && this.getFlag("jujutsu-system", "reliableTalent")
    }, config);
    rollConfig.hookNames = [...(config.hookNames ?? []), type, "abilityCheck", "d20Test"];
    rollConfig.rolls = [CONFIG.Dice.D20Roll.mergeConfigs({ options: {} }, config.rolls?.shift())]
      .concat(config.rolls ?? []);
    rollConfig.subject = this;

    const dialogConfig = foundry.utils.mergeObject({
      applicationClass: SkillToolRollConfigurationDialog,
      options: {
        buildConfig,
        chooseAbility: true
      }
    }, dialog);

    const abilityLabel = CONFIG.DND5E.abilities[abilityId]?.label ?? "";

    const messageConfig = foundry.utils.mergeObject({
      create: true,
      data: {
        flavor: type === "skill"
          ? _loc("DND5E.SkillPromptTitle", { skill: skillConfig.label, ability: abilityLabel })
          : _loc("DND5E.ToolPromptTitle", { tool: Trait.keyLabel(config.tool, { trait: "tool" }) ?? "" }),
        speaker: ChatMessage.getSpeaker({ actor: this }),
        system: { ability: abilityId, skill: config.skill, tool: config.tool },
        type: "check"
      }
    }, message);

    const rolls = await CONFIG.Dice.D20Roll.build(rollConfig, dialogConfig, messageConfig);
    if ( !rolls.length ) return null;

    /**
     * A hook event that fires after a skill or tool check has been rolled.
     * @function dnd5e.rollSkill
     * @function dnd5e.rollToolCheck
     * @memberof hookEvents
     * @param {D20Roll[]} rolls       The resulting rolls.
     * @param {object} data
     * @param {string} data.ability   Ability used as defined in `CONFIG.DND5E.abilities`.
     * @param {string} [data.skill]   ID of the skill that was rolled as defined in `CONFIG.DND5E.skills`.
     * @param {string} [data.tool]    ID of the tool that was rolled as defined in `CONFIG.DND5E.tools`.
     * @param {Actor5e} data.subject  Actor for which the roll has been performed.
     */
    const data = {
      ability: rollConfig.ability, skill: rollConfig.skill, subject: this, tool: rollConfig.tool
    };
    Hooks.callAll(`dnd5e.roll${name}`, rolls, data);
    Hooks.callAll(`dnd5e.roll${name}V2`, rolls, data);

    return oldFormat ? rolls[0] : rolls;
  }

  /* -------------------------------------------- */

  /**
   * Configure a roll config for each roll performed as part of the skill or tool check process. Will be called once
   * per roll in the process each time an option is changed in the roll configuration interface.
   * @param {"skill"|"tool"} type                          Type of roll.
   * @param {Actor5e|null} hostActor                       The original actor from which this one was transformed.
   * @param {D20RollProcessConfiguration} process          Configuration for the entire rolling process.
   * @param {D20RollConfiguration} config                  Configuration for a specific roll.
   * @param {FormDataExtended} [formData]                  Any data entered into the rolling prompt.
   * @param {number} index                                 Index of the roll within all rolls being prepared.
   */
  _buildSkillToolConfig(type, hostActor, process, config, formData, index) {
    const abilityId = formData?.get("ability") ?? process.ability;
    const ability = this.system.abilities?.[abilityId];
    const { calculateSkillToolProficiency } = dnd5e.dataModels.actor.CommonTemplate;
    let prof = calculateSkillToolProficiency(this, abilityId, process);
    const originalProf = calculateSkillToolProficiency(hostActor, abilityId, process);
    if ( originalProf?.multiplier > prof.multiplier ) prof = originalProf;
    const rollData = this.getRollData({ roll: true });
    Object.assign(rollData.roll, {
      ability: abilityId,
      proficient: prof.multiplier >= 1,
      [type]: process[type],
      type: type
    });

    const { bonus, maximum, minimum } = D20RollModificationField.combineFields(this.system, [
      `abilities.${abilityId}.check.roll`,
      "rolls.ability.check",
      `rolls.ability.${type}`,
      `${type}s.${type === "skill" ? process.skill : process.tool}.roll`
    ], { rules: { category: "check", actor: this, rollData } });

    let { parts, data } = Ruleset.isV2()
      ? CONFIG.Dice.D20Roll.constructParts({
        // 2.0: atributo inteiro (1-12) + degrau da perícia + vantagens ±2
        mod: ability?.value,
        legacyRank: Ruleset.rankPart(type === "skill" ? Ruleset.skillRank(this, process.skill) : 0),
        legacyAdv: Ruleset.advantagePart(process.legacy2 ?? {}),
        extraBonus: process.bonus,
        ruleBonus: bonus
      }, { ...rollData })
      : CONFIG.Dice.D20Roll.constructParts({
        mod: ability?.mod,
        prof: prof?.hasProficiency ? prof.term : null,
        extraBonus: process.bonus,
        ruleBonus: bonus
      }, { ...rollData });

    // Add condition reductions.
    this.addConditionRollReduction(parts, data);

    config.options = CONFIG.Dice.D20Roll.mergeOptions({ maximum, minimum }, config.options ?? {});
    config.parts = [...(config.parts ?? []), ...parts];
    config.data = { ...data, ...(config.data ?? {}) };
    config.data.abilityId = abilityId;
  }

  /* -------------------------------------------- */

  /**
   * Roll a generic ability test or saving throw.
   * Prompt the user for input on which variety of roll they want to do.
   * @param {Partial<AbilityRollProcessConfiguration>} config  Configuration information for the roll.
   * @param {Partial<BasicRollDialogConfiguration>} dialog     Configuration for the roll dialog.
   * @param {Partial<BasicRollMessageConfiguration>} message   Configuration for the roll message.
   */
  rollAbility(config={}, dialog={}, message={}) {
    const abilityId = config.ability;
    const label = CONFIG.DND5E.abilities[abilityId]?.label ?? "";
    new foundry.applications.api.Dialog({
      window: { title: `${_loc("DND5E.AbilityPromptTitle", { ability: label })}: ${this.name}` },
      position: { width: 400 },
      content: `<p>${_loc("DND5E.AbilityPromptText", { ability: label })}</p>`,
      buttons: [
        {
          action: "test",
          label: _loc("DND5E.ActionAbil"),
          callback: () => this.rollAbilityCheck(config, dialog, message)
        },
        {
          action: "save",
          label: _loc("DND5E.ActionSave"),
          callback: () => this.rollSavingThrow(config, dialog, message)
        }
      ]
    }).render({ force: true });
  }

  /* -------------------------------------------- */

  /**
   * Roll an Ability Check.
   * @param {Partial<AbilityRollProcessConfiguration>} config  Configuration information for the roll.
   * @param {Partial<BasicRollDialogConfiguration>} dialog     Configuration for the roll dialog.
   * @param {Partial<BasicRollMessageConfiguration>} message   Configuration for the roll message.
   * @returns {Promise<D20Roll[]|null>}                        A Promise which resolves to the created Roll instance.
   */
  async rollAbilityCheck(config={}, dialog={}, message={}) {
    if ( config.ability === "spellcasting" ) config = { ...config, ability: this.spellcastingAbility };
    const abilityLabel = CONFIG.DND5E.abilities[config.ability]?.label ?? "";
    const dialogConfig = foundry.utils.mergeObject({
      options: {
        window: {
          title: _loc("DND5E.AbilityPromptTitle", { ability: abilityLabel }),
          subtitle: this.name
        }
      }
    }, dialog);
    return this.#rollD20Test("check", config, dialogConfig, message);
  }

  /* -------------------------------------------- */

  /**
   * Roll a Saving Throw.
   * @param {Partial<AbilityRollProcessConfiguration>} config  Configuration information for the roll.
   * @param {Partial<BasicRollDialogConfiguration>} dialog     Configuration for the roll dialog.
   * @param {Partial<BasicRollMessageConfiguration>} message   Configuration for the roll message.
   * @returns {Promise<D20Roll[]|null>}                        A Promise which resolves to the created Roll instances.
   */
  async rollSavingThrow(config={}, dialog={}, message={}) {
    if ( (typeof this.system.rollSavingThrow === "function")
      && (await this.system.rollSavingThrow(config, dialog, message) === false) ) return null;
    if ( !this.system.abilities ) return null;
    if ( config.ability === "spellcasting" ) config = { ...config, ability: this.spellcastingAbility };
    const alternative = Ruleset.alternativeSave(this, config.ability);
    if ( alternative && !this.system.abilities[config.ability] ) config = { ...config, ability: alternative.ability };
    const abilityLabel = alternative?.label ?? CONFIG.DND5E.abilities[config.ability]?.label ?? "";
    const dialogConfig = foundry.utils.mergeObject({
      options: {
        window: {
          title: _loc("DND5E.SavePromptTitle", { ability: abilityLabel }),
          subtitle: this.name
        }
      }
    }, dialog);
    return this.#rollD20Test("save", config, dialogConfig, message);
  }

  /* -------------------------------------------- */

  /**
   * Shared rolling functionality between ability checks & saving throws.
   * @param {"check"|"save"} type                     D20 test type.
   * @param {Partial<AbilityRollProcessConfiguration>} config  Configuration information for the roll.
   * @param {Partial<BasicRollDialogConfiguration>} dialog     Configuration for the roll dialog.
   * @param {Partial<BasicRollMessageConfiguration>} message   Configuration for the roll message.
   * @returns {Promise<D20Roll[]|null>}               A Promise which resolves to the created Roll instance.
   */
  async #rollD20Test(type, config={}, dialog={}, message={}) {
    let oldFormat = false;
    const name = type === "check" ? "AbilityCheck" : "SavingThrow";

    const ability = this.system.abilities?.[config.ability];
    const abilityConfig = CONFIG.DND5E.abilities[config.ability];
    const alternative = type === "save" ? Ruleset.alternativeSave(this, config.ability) : null;

    const rollData = this.getRollData({ roll: true });
    Object.assign(rollData.roll, {
      ability: config.ability,
      proficient: alternative ? alternative.rank >= 1 : ability?.[type]?.prof?.multiplier >= 1,
      type: config[`${type}Type`] ?? "ability"
    });
    const { bonus, ...options } = D20RollModificationField.combineFields(this.system, [
      `abilities.${config.ability}.${type}.roll`, `rolls.ability.${type}`
    ], { rules: { category: type, actor: this, rollData } });
    let { parts, data } = Ruleset.isV2()
      ? CONFIG.Dice.D20Roll.constructParts({
        // 2.0: atributo inteiro (1-12); salvaguarda soma o degrau
        mod: alternative?.base ?? ability?.value,
        legacyRank: Ruleset.rankPart(type === "save" ? Ruleset.saveRank(this, config.ability) : 0),
        legacyAdv: Ruleset.advantagePart(config.legacy2 ?? {}),
        ruleBonus: bonus,
        cover: (config.ability === "dex" || alternative?.key === "reflexo") && (type === "save") ? this.system.attributes?.ac?.cover : null
      }, rollData)
      : CONFIG.Dice.D20Roll.constructParts({
        mod: ability?.mod,
        prof: ability?.[type].prof.hasProficiency ? ability[type].prof.term : null,
        ruleBonus: bonus,
        cover: (config.ability === "dex") && (type === "save") ? this.system.attributes?.ac?.cover : null
      }, rollData);

    const rollConfig = foundry.utils.mergeObject({
      halflingLucky: this.getFlag("jujutsu-system", "halflingLucky")
    }, config);
    rollConfig.hookNames = [...(config.hookNames ?? []), name, "d20Test"];
    rollConfig.rolls = [
      CONFIG.Dice.D20Roll.mergeConfigs({ parts, data, options }, config.rolls?.shift())
    ].concat(config.rolls ?? []);
    rollConfig.rolls.forEach(({ parts, data }) => this.addConditionRollReduction(parts, data));
    rollConfig.subject = this;

    const dialogConfig = foundry.utils.deepClone(dialog);

    const messageData = {
      flavor: _loc(`DND5E.${type === "check" ? "Ability" : "Save"}PromptTitle`, {
        ability: alternative?.label ?? abilityConfig?.label ?? ""
      }),
      speaker: ChatMessage.getSpeaker({ actor: this })
    };
    Object.assign(messageData, { type, system: { ability: config.ability } });

    const messageConfig = foundry.utils.mergeObject({ create: true, data: messageData }, message);

    const rolls = await CONFIG.Dice.D20Roll.build(rollConfig, dialogConfig, messageConfig);

    // TODO: Temporary fix to re-apply roll mode back to original config object to allow calling methods to
    // access the roll mode set in the dialog. There should be a better fix for this that works for all rolls.
    message.rollMode = messageConfig.rollMode;

    if ( !rolls.length ) return null;

    /**
     * A hook event that fires after an ability check or save has been rolled.
     * @function dnd5e.rollAbilityCheck
     * @function dnd5e.rollSavingThrow
     * @memberof hookEvents
     * @param {D20Roll[]} rolls       The resulting rolls.
     * @param {object} data
     * @param {string} data.ability   ID of the ability that was rolled as defined in `CONFIG.DND5E.abilities`.
     * @param {Actor5e} data.subject  Actor for which the roll has been performed.
     */
    Hooks.callAll(`dnd5e.roll${name}`, rolls, { ability: config.ability, subject: this });

    return oldFormat ? rolls[0] : rolls;
  }

  /* -------------------------------------------- */

  /**
   * Perform a death saving throw, rolling a d20 plus any global save bonuses.
   * @param {Partial<D20RollProcessConfiguration>} config     Configuration information for the roll.
   * @param {Partial<BasicRollDialogConfiguration>} dialog    Configuration for the roll dialog.
   * @param {Partial<BasicRollMessageConfiguration>} message  Configuration for the roll message.
   * @returns {Promise<D20Roll[]|null>}                       A Promise which resolves to the Roll instance.
   */
  async rollDeathSave(config={}, dialog={}, message={}) {
    let oldFormat = false;
    const death = this.system.attributes?.death;
    if ( !death ) throw new Error(`Actors of the type '${this.type}' don't support death saves.`);

    // Display a warning if we are not at zero HP or if we already have reached 3
    if ( (this.system.attributes.hp.value > 0) || (death.failure >= 3) || (death.success >= 3) ) {
      ui.notifications.warn("DND5E.DeathSaveUnnecessary", { localize: true });
      return null;
    }

    const { bonus, ...options } = D20RollModificationField.combineFields(this.system, [
      "attributes.death.roll"
    ]);
    const { parts, data } = CONFIG.Dice.D20Roll.constructParts({
      prof: this.getFlag("jujutsu-system", "diamondSoul") ? new Proficiency(this.system.attributes.prof, 1).term : null,
      deathBonus: bonus
    }, {});

    const rollConfig = foundry.utils.mergeObject({ saveType: "death", target: 10 }, config);
    rollConfig.hookNames = [...(config.hookNames ?? []), "deathSave"];
    rollConfig.rolls = [
      CONFIG.Dice.D20Roll.mergeConfigs({ parts, data, options }, config.rolls?.shift())
    ].concat(config.rolls ?? []);

    const dialogConfig = foundry.utils.deepClone(dialog);

    const messageConfig = foundry.utils.mergeObject({
      data: {
        flavor: _loc("DND5E.DeathSavingThrow"),
        system: { type: "death" }
      }
    }, message);

    const rolls = await this.rollSavingThrow(rollConfig, dialogConfig, messageConfig);
    if ( !rolls?.length ) return null;

    // Take action depending on the result
    const details = { subject: this };
    const roll = rolls[0];
    const returnValue = oldFormat ? roll : rolls;
    const card = roll.parent;

    const { outcome, updates } = AttributesFields.applyDeathSaveResult(death, {
      isSuccess: roll.total >= (roll.options.target ?? 10),
      isCritical: roll.isCritical,
      isFumble: roll.isFumble
    });
    details.updates = updates;
    details.outcome = outcome;

    /**
     * A hook event that fires after a death saving throw has been rolled for an Actor, but before
     * updates have been performed.
     * @function dnd5e.rollDeathSave
     * @memberof hookEvents
     * @param {D20Roll[]} rolls                The resulting rolls.
     * @param {object} data
     * @param {DeathSaveOutcome} data.outcome  Terminal outcome rendered on the save card, if any.
     * @param {object} data.updates            Updates that will be applied to the actor as a result of this save.
     * @param {Actor5e} data.subject           Actor for which the death saving throw has been rolled.
     * @returns {boolean}                      Explicitly return `false` to prevent updates from being performed.
     */
    if ( Hooks.call("dnd5e.rollDeathSave", rolls, details) === false ) return returnValue;
    if ( Hooks.call("dnd5e.rollDeathSaveV2", rolls, details) === false ) return returnValue;

    const deltas = ActorDeltasField.getDeltas(this, { actor: details.updates, item: [] });
    if ( !foundry.utils.isEmpty(details.updates) ) await this.update(details.updates);
    if ( card ) await card.update({ "system.deltas": deltas, "system.outcome": details.outcome ?? null });

    /**
     * A hook event that fires after a death saving throw has been rolled and after changes have been applied.
     * @function dnd5e.postRollDeathSave
     * @memberof hookEvents
     * @param {D20Roll[]} rolls                  The resulting rolls.
     * @param {object} data
     * @param {ChatMessage5e|void} data.message  The save card chat message, if one was created.
     * @param {Actor5e} data.subject             Actor for which the death saving throw has been rolled.
     */
    Hooks.callAll("dnd5e.postRollDeathSave", rolls, { message: card, subject: this });

    return returnValue;
  }

  /* -------------------------------------------- */

  /**
   * Perform a saving throw to maintain concentration.
   * @param {Partial<AbilityRollProcessConfiguration>} config  Configuration information for the roll.
   * @param {Partial<BasicRollDialogConfiguration>} dialog     Configuration for the roll dialog.
   * @param {Partial<BasicRollMessageConfiguration>} message   Configuration for the roll message.
   * @returns {Promise<D20Roll[]|null>}                        A Promise which resolves to the created Roll instance.
   */
  async rollConcentration(config={}, dialog={}, message={}) {
    let oldFormat = false;
    if ( !this.isOwner ) return null;
    const conc = this.system.attributes?.concentration;
    if ( !conc ) throw new Error("You may not make a Concentration Saving Throw with this Actor.");

    const { bonus, ...options } = D20RollModificationField.combineFields(this.system, [
      "attributes.concentration.roll"
    ]);
    options.isConcentration = true;
    const { parts, data } = CONFIG.Dice.D20Roll.constructParts({ concentrationBonus: bonus }, {});

    const rollConfig = foundry.utils.mergeObject({
      ability: (conc.ability in CONFIG.DND5E.abilities) ? conc.ability : CONFIG.DND5E.defaultAbilities.concentration,
      isConcentration: true,
      saveType: "concentration",
      target: 10
    }, config);
    rollConfig.hookNames = [...(config.hookNames ?? []), "concentration"];
    rollConfig.rolls = [
      CONFIG.Dice.D20Roll.mergeConfigs({ parts, data, options }, config.rolls?.shift())
    ].concat(config.rolls ?? []);

    const dialogConfig = foundry.utils.mergeObject({
      options: {
        window: {
          title: _loc("DND5E.SavePromptTitle", { ability: _loc("DND5E.Concentration") })
        }
      }
    }, dialog);

    const messageConfig = foundry.utils.mergeObject({
      data: { system: { type: "concentration" } }
    }, message);

    const rolls = await this.rollSavingThrow(rollConfig, dialogConfig, messageConfig);
    if ( !rolls?.length ) return null;

    /**
     * A hook event that fires after a saving throw to maintain concentration is rolled for an Actor.
     * @function dnd5e.rollConcentration
     * @memberof hookEvents
     * @param {D20Roll[]} rolls     The resulting rolls.
     * @param {object} data
     * @param {Actor5e} data.actor  Actor for which the saving throw has been rolled.
     */
    Hooks.callAll("dnd5e.rollConcentration", rolls, { subject: this });
    Hooks.callAll("dnd5e.rollConcentrationV2", rolls, { subject: this });

    return oldFormat ? rolls[0] : rolls;
  }

  /* -------------------------------------------- */

  /**
   * Get an un-evaluated D20Roll instance used to roll initiative for this Actor.
   * @param {Partial<InitiativeRollOptions>} options  Configuration information for the roll.
   * @returns {D20Roll|null}                          The constructed but unevaluated D20Roll.
   */
  getInitiativeRoll(options={}) {
    // Use a temporarily cached initiative roll
    if ( this._cachedInitiativeRoll ) return this._cachedInitiativeRoll.clone();
    const config = this.getInitiativeRollConfig(options);
    if ( !config ) return null;

    // Create a normal D20 roll
    if ( config.options?.fixed === undefined ) {
      const formula = ["1d20"].concat(config.parts).join(" + ");
      return new CONFIG.Dice.D20Roll(formula, config.data, config.options);
    }

    // Create a basic roll with the fixed score
    return new CONFIG.Dice.BasicRoll(String(config.options.fixed), config.data, config.options);
  }

  /* -------------------------------------------- */

  /**
   * Get an un-evaluated D20Roll instance used to roll initiative for this Actor.
   * @param {Partial<InitiativeRollOptions>} options  Configuration information for the roll.
   * @returns {D20RollConfiguration|null}             Roll configuration.
   */
  getInitiativeRollConfig(options={}) {
    const init = this.system.attributes?.init;
    const flags = this.flags.JujutsuLegacy ?? {};
    const abilityId = init?.ability || CONFIG.DND5E.defaultAbilities.initiative;
    const ability = this.system.abilities?.[abilityId];

    const rollData = this.getRollData({ roll: true });
    Object.assign(rollData.roll, {
      ability: abilityId,
      proficient: init.prof.multiplier >= 1,
      type: "initiative"
    });
    const { advantage, disadvantage, bonus, maximum, minimum } = D20RollModificationField.combineFields(this.system, [
      `abilities.${abilityId}.check.roll`, "attributes.init.roll", "rolls.ability.check"
    ], { rules: { category: "check", actor: this, rollData } });
    const ehV2 = Ruleset.isV2();
    let { parts, data } = CONFIG.Dice.D20Roll.constructParts({
      // 2.0: init.mod já é ((AGI + INT) / 2) — sem proficiência nem alerta
      mod: init?.mod,
      prof: !ehV2 && init.prof.hasProficiency ? init.prof.term : null,
      ruleBonus: bonus,
      alert: !ehV2 && flags.initiativeAlert && (dnd5e.settings.rulesVersion === "legacy") ? 5 : null
    }, rollData);

    // Add condition reductions
    this.addConditionRollReduction(parts, data);

    // Ability score tiebreaker (desempate do 1.0 — na 2.0 o bônus já é
    // atributo inteiro e o desempate tem regra própria)
    const tiebreaker = !ehV2 && game.settings.get("jujutsu-system", "initiativeDexTiebreaker");
    if ( tiebreaker && Number.isNumeric(ability?.value) ) parts.push(String(ability.value / 100));

    // Fixed initiative score
    const scoreMode = game.settings.get("jujutsu-system", "initiativeScore");
    const useScore = (scoreMode === "all") || ((scoreMode === "npcs") && game.user.isGM && this.system.isNPC);

    options = foundry.utils.mergeObject({
      advantage, disadvantage, maximum, minimum,
      ability: abilityId,
      fixed: useScore ? init.score : undefined,
      flavor: options.flavor ?? _loc("DND5E.Initiative"),
      halflingLucky: flags.halflingLucky ?? false
    }, options);

    const rollConfig = { parts, data, options, subject: this };

    /**
     * A hook event that fires before initiative roll is prepared for an Actor.
     * @function dnd5e.preConfigureInitiative
     * @memberof hookEvents
     * @param {Actor5e} subject              The Actor that is rolling initiative.
     * @param {D20RollConfiguration} config  Configuration data for the pending roll.
     */
    Hooks.callAll("dnd5e.preConfigureInitiative", this, rollConfig);

    return rollConfig;
  }

  /* -------------------------------------------- */

  /**
   * Roll initiative for this Actor with a dialog that provides an opportunity to elect advantage or other bonuses.
   * @param {Partial<InitiativeRollOptions>} [rollOptions={}]  Options forwarded to the Actor#getInitiativeRoll method.
   * @param {object} [dialog]                                  Options forwarded to the dialog configuration.
   * @returns {Promise<void>}           A promise which resolves once initiative has been rolled for the Actor.
   */
  async rollInitiativeDialog(rollOptions={}, dialog={}) {
    const config = {
      evaluate: false,
      event: rollOptions.event,
      hookNames: ["initiativeDialog", "abilityCheck", "d20Test"],
      rolls: [this.getInitiativeRollConfig(rollOptions)],
      subject: this
    };
    if ( !config.rolls[0] ) return;

    // Display the roll configuration dialog
    const messageOptions = { rollMode: rollModeAtual() };
    if ( config.rolls[0].options?.fixed === undefined ) {
      const dialogConfig = foundry.utils.mergeObject({
        options: { title: _loc("DND5E.InitiativeRoll") }
      }, dialog);
      const rolls = await CONFIG.Dice.D20Roll.build(config, dialogConfig, messageOptions);
      if ( !rolls.length ) return;
      this._cachedInitiativeRoll = rolls[0];
    }

    // Just create a basic roll with the fixed score
    else {
      const { data, options } = config.rolls[0];
      this._cachedInitiativeRoll = new CONFIG.Dice.BasicRoll(String(options.fixed), data, options);
    }

    await this.rollInitiative({
      createCombatants: true,
      initiativeOptions: { messageMode: messageOptions.rollMode }
    });
  }

  /* -------------------------------------------- */

  /** @inheritDoc */
  async rollInitiative(options={}, rollOptions={}) {
    this._cachedInitiativeRoll ??= this.getInitiativeRoll(rollOptions);

    /**
     * A hook event that fires before initiative is rolled for an Actor.
     * @function dnd5e.preRollInitiative
     * @memberof hookEvents
     * @param {Actor5e} actor  The Actor that is rolling initiative.
     * @param {D20Roll} roll   The initiative roll.
     */
    if ( Hooks.call("dnd5e.preRollInitiative", this, this._cachedInitiativeRoll) === false ) {
      delete this._cachedInitiativeRoll;
      return null;
    }

    const combat = await super.rollInitiative(options);
    if ( !combat ) {
      delete this._cachedInitiativeRoll;
      return null;
    }

    const combatants = this.isToken ? this.getActiveTokens(false, true).reduce((arr, t) => {
      return arr.concat(combat.getCombatantsByToken(t.id));
    }, []) : combat.getCombatantsByActor(this.id);

    /**
     * A hook event that fires after an Actor has rolled for initiative.
     * @function dnd5e.rollInitiative
     * @memberof hookEvents
     * @param {Actor5e} actor           The Actor that rolled initiative.
     * @param {Combatant[]} combatants  The associated Combatants in the Combat.
     */
    Hooks.callAll("dnd5e.rollInitiative", this, combatants);
    delete this._cachedInitiativeRoll;
    return combat;
  }

  /* -------------------------------------------- */

  /**
   * Roll a hit die of the appropriate type, gaining hit points equal to the die roll plus your CON modifier.
   * @param {HitDieRollProcessConfiguration} config  Configuration information for the roll.
   * @param {BasicRollDialogConfiguration} dialog    Configuration for the roll dialog.
   * @param {BasicRollMessageConfiguration} message  Configuration for the roll message.
   * @returns {Promise<BasicRoll[]|null>}            The created Roll instances, or `null` if no hit die was rolled.
   */
  async rollHitDie(config={}, dialog={}, message={}) {
    let formula;
    let oldFormat = false;

    let cls = null;

    // NPCs only have one denomination
    if ( this.system.isNPC ) {
      config.denomination = `d${this.system.attributes.hd.denomination}`;

      // If no hit dice are available, display an error notification
      if ( !this.system.attributes.hd.value ) {
        ui.notifications.error("DND5E.HitDiceNPCWarn", { format: { name: this.name } });
        return null;
      }
    }

    // Otherwise check classes
    else {
      // If no denomination was provided, choose the first available
      if ( !config.denomination ) {
        cls = this.system.attributes.hd.classes.find(c => c.system.hd.value);
        if ( !cls ) return null;
        config.denomination = cls.system.hd.denomination;
      }

      // Otherwise, locate a class (if any) which has an available hit die of the requested denomination
      else cls = this.system.attributes.hd.classes.find(i => {
        return (i.system.hd.denomination === config.denomination) && i.system.hd.value;
      });

      // If no class is available, display an error notification
      if ( !cls ) {
        ui.notifications.error("DND5E.HitDiceWarn", { format: { name: this.name, formula: config.denomination } });
        return null;
      }
    }
    const rulesVersion = dnd5e.settings.rulesVersion;
    const minimumValue = rulesVersion === "modern" ? 1 : 0;
    formula ??= `max(${minimumValue}, 1${config.denomination} + @abilities.con.mod)`;
    const rollConfig = foundry.utils.deepClone(config);
    rollConfig.hookNames = [...(config.hookNames ?? []), "hitDie"];
    rollConfig.rolls = [{ parts: [formula], data: this.getRollData() }].concat(config.rolls ?? []);
    rollConfig.subject = this;

    const dialogConfig = foundry.utils.mergeObject({
      configure: false
    }, dialog);

    const flavor = _loc("DND5E.HitDiceRoll");
    const messageConfig = foundry.utils.mergeObject({
      rollMode: rollModeAtual(),
      data: {
        speaker: ChatMessage.implementation.getSpeaker({actor: this}),
        flavor,
        title: `${flavor}: ${this.name}`,
        type: "hitDie"
      }
    }, message);

    const rolls = await CONFIG.Dice.BasicRoll.build(rollConfig, dialogConfig, messageConfig);
    if ( !rolls.length ) return null;
    const returnValue = oldFormat && rolls?.length ? rolls[0] : rolls;

    const updates = { actor: {}, class: {} };
    if ( rollConfig.modifyHitDice !== false ) {
      if ( cls ) updates.class["system.hd.spent"] = cls.system.hd.spent + 1;
      else updates.actor["system.attributes.hd.spent"] = this.system.attributes.hd.spent + 1;
    }
    const hp = this.system.attributes.hp;
    if ( rollConfig.modifyHitPoints !== false ) {
      const total = rolls.reduce((t, r) => t + r.total, 0);
      const calculated = this.calculateDamage([{ type: "healing", value: total }], { invertHealing: false });
      const dhp = Math.min(Math.max(0, hp.effectiveMax) - hp.value, calculated ? calculated.amount : total);
      updates.actor["system.attributes.hp.value"] = hp.value + dhp;
    }

    /**
     * A hook event that fires after a hit die has been rolled for an Actor, but before updates have been performed.
     * @function dnd5e.rollHitDie
     * @memberof hookEvents
     * @param {BasicRoll[]} rolls          The resulting rolls.
     * @param {object} data
     * @param {Actor5e} data.subject       Actor for which the hit die has been rolled.
     * @param {object} data.updates
     * @param {object} data.updates.actor  Updates that will be applied to the actor.
     * @param {object} data.updates.class  Updates that will be applied to the class.
     * @returns {boolean}                  Explicitly return `false` to prevent updates from being performed.
     */
    if ( Hooks.call("dnd5e.rollHitDie", rolls, { subject: this, updates }) === false ) return returnValue;
    if ( Hooks.call("dnd5e.rollHitDieV2", rolls, { subject: this, updates }) === false ) return returnValue;

    // Perform updates
    if ( !foundry.utils.isEmpty(updates.actor) ) await this.update(updates.actor);
    if ( !foundry.utils.isEmpty(updates.class) ) await cls.update(updates.class);

    /**
     * A hook event that fires after a hit die has been rolled for an Actor and updates have been performed.
     * @function dnd5e.postRollHitDie
     * @memberof hookEvents
     * @param {BasicRoll[]} rolls     The resulting rolls.
     * @param {object} data
     * @param {Actor5e} data.subject  Actor for which the roll was performed.
     */
    Hooks.callAll("dnd5e.postRollHitDie", rolls, { subject: this });

    return returnValue;
  }

  /* -------------------------------------------- */

  /**
   * Roll hit points for a specific class as part of a level-up workflow.
   * @param {Item5e} item                         The class item whose hit dice to roll.
   * @param {object} options
   * @param {boolean} [options.chatMessage=true]  Display the chat message for this roll.
   * @returns {Promise<Roll>}                     The completed roll.
   * @see {@link dnd5e.preRollClassHitPoints}
   */
  async rollClassHitPoints(item, { chatMessage=true }={}) {
    if ( item.type !== "class" ) throw new Error("Hit points can only be rolled for a class item.");
    const config = {
      formula: `1${item.system.hd.denomination}`,
      data: item.getRollData(),
      chatMessage
    };
    const flavor = _loc("DND5E.ADVANCEMENT.HitPoints.Action.RollClass", { class: item.name });
    const messageData = {
      title: `${flavor}: ${this.name}`,
      flavor,
      speaker: ChatMessage.implementation.getSpeaker({ actor: this }),
      type: "hitPoints"
    };

    /**
     * A hook event that fires before hit points are rolled for a character's class.
     * @function dnd5e.preRollClassHitPoints
     * @memberof hookEvents
     * @param {Actor5e} actor            Actor for which the hit points are being rolled.
     * @param {Item5e} item              The class item whose hit dice will be rolled.
     * @param {object} config
     * @param {string} config.formula    The string formula to parse.
     * @param {object} config.data       The data object against which to parse attributes within the formula.
     * @param {object} messageData       The data object to use when creating the message.
     */
    Hooks.callAll("dnd5e.preRollClassHitPoints", this, item, config, messageData);

    const roll = new Roll(config.formula, config.data);
    await roll.evaluate();

    /**
     * A hook event that fires after hit points haven been rolled for a character's class.
     * @function dnd5e.rollClassHitPoints
     * @memberof hookEvents
     * @param {Actor5e} actor  Actor for which the hit points have been rolled.
     * @param {Roll} roll      The resulting roll.
     */
    Hooks.callAll("dnd5e.rollClassHitPoints", this, roll);

    if ( config.chatMessage ) await roll.toMessage(messageData);
    return roll;
  }

  /* -------------------------------------------- */

  /**
   * Roll hit points for an NPC based on the HP formula.
   * @param {object} options
   * @param {boolean} [options.chatMessage=true]  Display the chat message for this roll.
   * @returns {Promise<Roll>}                     The completed roll.
   * @see {@link dnd5e.preRollNPCHitPoints}
   */
  async rollNPCHitPoints({ chatMessage=true }={}) {
    if ( !this.system.isNPC ) throw new Error("NPC hit points can only be rolled for NPCs");
    const config = {
      formula: this.system.attributes.hp.formula,
      data: this.getRollData(),
      chatMessage
    };
    const flavor = _loc("DND5E.HPFormulaRollMessage");
    const messageData = {
      title: `${flavor}: ${this.name}`,
      flavor,
      speaker: ChatMessage.getSpeaker({ actor: this }),
      type: "hitPoints"
    };

    /**
     * A hook event that fires before hit points are rolled for an NPC.
     * @function dnd5e.preRollNPCHitPoints
     * @memberof hookEvents
     * @param {Actor5e} actor            Actor for which the hit points are being rolled.
     * @param {object} config
     * @param {string} config.formula    The string formula to parse.
     * @param {object} config.data       The data object against which to parse attributes within the formula.
     * @param {object} messageData       The data object to use when creating the message.
     */
    Hooks.callAll("dnd5e.preRollNPCHitPoints", this, config, messageData);

    const roll = new Roll(config.formula, config.data);
    await roll.evaluate();

    /**
     * A hook event that fires after hit points are rolled for an NPC.
     * @function dnd5e.rollNPCHitPoints
     * @memberof hookEvents
     * @param {Actor5e} actor  Actor for which the hit points have been rolled.
     * @param {Roll} roll      The resulting roll.
     */
    Hooks.callAll("dnd5e.rollNPCHitPoints", this, roll);

    if ( config.chatMessage ) await roll.toMessage(messageData);
    return roll;
  }

  /* -------------------------------------------- */
  /*  Resting                                     */
  /* -------------------------------------------- */

  /**
   * Initiate a rest, spending or recovering hit dice, resources, item uses and spell slots according to configuration.
   * @param {Partial<RestConfiguration>} config  Configuration options for the rest. Must include the rest type.
   * @returns {Promise<RestResult>}              A Promise which resolves once the rest workflow has completed.
   */
  async initiateRest(config={}) {
    if ( this.system.isVehicle ) return;
    if ( !game.user.isGM && !game.settings.get("jujutsu-system", "allowRests") && !config.request ) {
      ui.notifications.warn("DND5E.REST.Warning.OnlyByRequest", { console: false, localize: true });
      return;
    }

    const clone = this.clone();
    const restConfig = CONFIG.DND5E.restTypes[config.type];
    config = foundry.utils.mergeObject({
      dialog: true,
      chat: restConfig.chat !== false,
      duration: restConfig.duration[game.settings.get("jujutsu-system", "restVariant")],
      newDay: restConfig.newDay === true,
      advanceBastionTurn: restConfig.advanceBastionTurn === true,
      advanceTime: restConfig.advanceTime === true,
      autoHD: restConfig.autoHD === true,
      autoHDThreshold: 3,
      recoverTemp: restConfig.recoverTemp,
      recoverTempMax: restConfig.recoverTempMax,
      exhaustionDelta: restConfig.exhaustionDelta
    }, config);
    config.dialogClass ??= restConfig.dialogClass ?? BaseRestDialog;

    /**
     * A hook event that fires before a rest is started. The actual name of the hook will depend on the rest type
     * (e.g. `dnd5e.preShortRest` or `dnd5e.preLongRest`).
     * @function dnd5e.preRest
     * @memberof hookEvents
     * @param {Actor5e} actor             The actor that is being rested.
     * @param {RestConfiguration} config  Configuration options for the rest.
     * @returns {boolean}                 Explicitly return `false` to prevent the rest from being started.
     */
    if ( Hooks.call(`dnd5e.pre${config.type.capitalize()}Rest`, this, config) === false ) return;

    // Take note of the initial hit points and number of hit dice the Actor has
    const hd0 = foundry.utils.getProperty(this, "system.attributes.hd.value");
    const hp0 = foundry.utils.getProperty(this, "system.attributes.hp.value");
    const energy0 = foundry.utils.getProperty(this, "system.energy.total") ?? 0;
    const energyDice0 = foundry.utils.getProperty(this, "system.energyDice.value") ?? 0;

    // Display a Dialog for rolling hit dice
    if ( config.dialog ) {
      try {
        Object.assign(config, await config.dialogClass.configure(this, config));
      } catch { return; }
    }

    /**
     * A hook event that fires after a rest has started, after the configuration is complete.
     * @function dnd5e.rest
     * @memberof hookEvents
     * @param {Actor5e} actor             The actor that is being rested.
     * @param {RestConfiguration} config  Configuration options for the rest.
     * @returns {boolean}                 Explicitly return `false` to prevent the rest from being continued.
     */
    if ( Hooks.call(`dnd5e.${config.type}Rest`, this, config) === false ) return;

    // Automatically spend hit dice
    if ( config.autoHD ) await this.autoSpendHitDice({ threshold: config.autoHDThreshold });
    if ( config.autoEnergyED ) await this.autoSpendEnergyDice({ threshold: config.autoHDThreshold });

    // Return the rest result
    const dhd = foundry.utils.getProperty(this, "system.attributes.hd.value") - hd0;
    const dhp = foundry.utils.getProperty(this, "system.attributes.hp.value") - hp0;
    const energyRecovered = (foundry.utils.getProperty(this, "system.energy.total") ?? 0) - energy0;
    const energyDiceSpent = energyDice0 - (foundry.utils.getProperty(this, "system.energyDice.value") ?? 0);
    const energyDenomination = this.system.energyDice?.denomination ?? "";
    return this._rest(config, { clone, dhd, dhp, energyRecovered, energyDiceSpent, energyDenomination });
  }

  /* -------------------------------------------- */

  /**
   * Take a short rest, possibly spending hit dice and recovering resources, item uses, and relevant spell slots.
   * @param {Partial<RestConfiguration>} [config]  Configuration options for a short rest.
   * @returns {Promise<RestResult>}                A Promise which resolves once the short rest workflow has completed.
   */
  async shortRest(config={}) {
    return this.initiateRest({ ...config, type: "short" });
  }

  /* -------------------------------------------- */

  /**
   * Take a long rest, recovering hit points, hit dice, resources, item uses, and spell slots.
   * @param {Partial<RestConfiguration>} [config]  Configuration options for a long rest.
   * @returns {Promise<RestResult>}       A Promise which resolves once the long rest workflow has completed.
   */
  async longRest(config={}) {
    return this.initiateRest({ ...config, type: "long" });
  }

  /* -------------------------------------------- */

  /**
   * Handle resting an actor from a request.
   * @param {Actor5e} actor                  Actor to rest.
   * @param {ChatMessage5e} request          Request chat message.
   * @param {RestConfiguration} config       Configuration data for the rest requested.
   * @returns {Promise<ChatMessage5e|null>}
   */
  static async handleRestRequest(actor, request, config) {
    const result = await actor.initiateRest({
      ...config, request, advanceBastionTurn: false, advanceTime: false
    });
    return result?.message ?? null;
  }

  /* -------------------------------------------- */

  /**
   * Perform all of the changes needed for a short or long rest.
   *
   * @param {RestConfiguration} config         Configuration data for the rest occurring.
   * @param {Partial<RestResult>} [result={}]  Results of the rest operation being built.
   * @returns {Promise<RestResult|void>}       Consolidated results of the rest workflow.
   * @private
   */
  async _rest(config, result={}) {
    if ( (foundry.utils.getType(this.system.rest) === "function")
      && (await this.system.rest(config, result) === false) ) return;

    result = foundry.utils.mergeObject({
      type: config.type,
      deleteItems: [],
      deltas: {
        hitPoints: 0,
        hitDice: 0
      },
      newDay: config.newDay === true,
      request: config.request,
      rolls: [],
      updateData: {},
      updateItems: []
    }, result);
    result.clone ??= this.clone();
    if ( "dhp" in result ) result.deltas.hitPoints = result.dhp;
    if ( "dhd" in result ) result.deltas.hitDice = result.dhd;

    this._getRestHitDiceRecovery(config, result);
    this._getRestHitPointRecovery(config, result);
    this._getRestResourceRecovery(config, result);
    this._getRestSpellRecovery(config, result);
    await this._getRestItemUsesRecovery(config, result);
    await this._getRestEnergyDiceRecovery(config, result);

    // ── Jujutsu Legacy 2.0: descansos próprios (cap. 1.3) ───────────────
    // Curto: Vida completa + 10% da Energia total (não reduz Ferimentos).
    // Longo: Vida e Energia completas + reduz 20% dos Ferimentos atuais.
    // Sobrescreve as recuperações padrão (dados de vida/energia) acima.
    if ( Ruleset.isV2() ) {
      const hp = this.system.attributes.hp;
      const energiaMax = Number(this.system.energy?.max ?? 0);
      const energiaAtual = Number(this.system.energy?.total ?? 0);
      let tetoVida;
      if ( config.type === "short" ) {
        tetoVida = hp.effectiveMax ?? hp.max ?? 0;
        result.updateData["system.energy.total"] = Math.min(energiaMax,
          energiaAtual + Math.floor(energiaMax * 0.1));
      } else {
        result.updateData["system.energy.total"] = energiaMax;
        const feridas = this.type === "npc" ? 0
          : Math.max(0, Math.floor(Number(this.system.legacy2?.wounds?.value ?? 0)));
        let feridasFinais = feridas;
        if ( feridas > 0 ) {
          const reducao = Math.max(1, Math.ceil(feridas * 0.2));
          feridasFinais = Math.max(0, feridas - reducao);
          result.updateData["system.legacy2.wounds.value"] = feridasFinais;
        }
        // a Vida enche pelo teto APÓS a redução das Feridas (2 feridas = −1 PV máx)
        tetoVida = Math.max(0, (hp.max ?? 0) - Math.floor(feridasFinais / 2) + (hp.tempmax ?? 0));
      }
      const dhp2 = tetoVida - (foundry.utils.getProperty(this, "system.attributes.hp.value") ?? 0);
      result.updateData["system.attributes.hp.value"] = tetoVida;
      result.deltas.hitPoints = dhp2;
      result.dhp = dhp2;
      // Selos de Mão (2.0): recupera todos os usos em descanso curto ou longo
      const featsSelos = this.items.filter(i => i.type === "feat"
        && i.getFlag?.("jujutsu-system", "especializacao")?.caminho === "Selos e Encantamentos").length;
      if ( featsSelos > 0 ) result.updateData["flags.jujutsu-system.selos"] = 3 + Math.max(0, featsSelos - 1);
    }

    result.dhp = result.deltas.hitPoints;
    result.dhd = result.deltas.hitDice;
    result.longRest = result.type === "long";

    if ( config.exhaustionDelta && !result.clone.hasConditionEffect("malnourished")
      && !result.clone.hasConditionEffect("dehydrated") ) {
      const path = "system.attributes.exhaustion";
      const value = foundry.utils.getProperty(result.clone, path) ?? 0;
      foundry.utils.mergeObject(result.updateData, { [path]: Math.max(0, value + config.exhaustionDelta) });
    }

    /**
     * A hook event that fires after rest result is calculated, but before any updates are performed.
     * @function dnd5e.preRestCompleted
     * @memberof hookEvents
     * @param {Actor5e} actor             The actor that is being rested.
     * @param {RestResult} result         Details on the rest to be completed.
     * @param {RestConfiguration} config  Configuration data for the rest occurring.
     * @returns {boolean}                 Explicitly return `false` to prevent the rest updates from being performed.
     */
    if ( Hooks.call("dnd5e.preRestCompleted", this, result, config) === false ) return result;

    // Expire active effects
    const expiryEvents = CONFIG.DND5E.restTypes[config.type ?? "long"]?.expiryEvents ?? [];
    let operations = [];
    if ( expiryEvents.length ) {
      const expired = new Map();
      const expireEffect = effect => {
        if ( expiryEvents.includes(effect.duration.expiry) ) expired.getOrInsert(effect.parent, []).push(effect.id);
      };
      for ( const effect of this.effects ) {
        if ( !effect.getFlag("jujutsu-system", "dependentOn") ) expireEffect(effect);
      }
      for ( const item of this.items ) {
        for ( const effect of item.effects ) {
          if ( effect.getFlag("jujutsu-system", "dependentOn") ) continue;
          if ( effect.isAppliedEnchantment ) expireEffect(effect);
        }
      }
      operations = expired.entries()
        .map(([parent, ids]) => ({ action: "delete", documentName: "ActiveEffect", ids, parent }))
        .toArray();
    }

    // Perform updates
    await this.performBulkUpdate(
      { actor: result.updateData, delete: result.deleteItems, item: result.updateItems, operations }, { isRest: true }
    );

    // Advance the game clock
    if ( config.advanceTime && (config.duration > 0) && game.user.isGM ) await game.time.advance(60 * config.duration);

    // Display a Chat Message summarizing the rest effects
    if ( config.chat ) result.message = await this._displayRestResultMessage(config, result);

    /**
     * A hook event that fires when the rest process is completed for an actor.
     * @function dnd5e.restCompleted
     * @memberof hookEvents
     * @param {Actor5e} actor             The actor that just completed resting.
     * @param {RestResult} result         Details on the rest completed.
     * @param {RestConfiguration} config  Configuration data for that occurred.
     */
    Hooks.callAll("dnd5e.restCompleted", this, result, config);

    if ( config.advanceBastionTurn && game.user.isGM && game.settings.get("jujutsu-system", "bastionConfiguration").enabled
      && this.itemTypes.facility.length ) await dnd5e.bastion.advanceAllFacilities(this);

    // Return data summarizing the rest effects
    return result;
  }

  /* -------------------------------------------- */

  /**
   * Display a chat message with the result of a rest.
   *
   * @param {RestConfiguration} config  Rest configuration.
   * @param {RestResult} result         Result of the rest operation.
   * @returns {Promise<ChatMessage>}    Chat message that was created.
   * @protected
   */
  async _displayRestResultMessage(config, result) {
    let { dhd, dhp } = result;
    if ( config.type === "short" ) dhd *= -1;
    const diceRestored = dhd !== 0;
    const healthRestored = dhp !== 0;
    const longRest = config.type === "long";
    const length = longRest ? "Long" : "Short";
    const typeConfig = CONFIG.DND5E.restTypes[config.type] ?? {};

    // Determine the chat message to display
    let message;
    if ( typeof typeConfig.chat === "string" ) message = typeConfig.chat;
    if ( !message ) {
      if ( diceRestored && healthRestored ) message = `DND5E.REST.${length}.Result.Full`;
      else if ( longRest && !diceRestored && healthRestored ) message = "DND5E.REST.Long.Result.HitPoints";
      else if ( longRest && diceRestored && !healthRestored ) message = "DND5E.REST.Long.Result.HitDice";
      else message = `DND5E.REST.${length}.Result.Short`;
    }

    // Create a chat message
    const pr = new Intl.PluralRules(game.i18n.lang);

    // Linha extra de energia (descanso curto)
    let energyLine = "";
    if ( config.type === "short" && result.energyRecovered > 0 ) {
      energyLine = ` Recuperou também <strong>${result.energyRecovered} PA</strong> de Energia Amaldiçoada (${result.energyDiceSpent}× ${result.energyDenomination}).`;
    }

    let chatData = {
      content: `<p>${_loc(message, {
        name: this.name,
        dice: _loc(`DND5E.HITDICE.Counted.${pr.select(dhd)}`, { number: formatNumber(dhd) }),
        health: _loc(`DND5E.HITPOINTS.Counted.${pr.select(dhp)}`, { number: formatNumber(dhp) })
      })}</p>` + energyLine,
      flavor: this.createRestFlavor(config, result),
      type: "rest",
      rolls: result.rolls,
      speaker: ChatMessage.getSpeaker({ actor: this, alias: this.name }),
      system: {
        activations: ActivationsField.getActivations(this, typeConfig?.activationPeriods ?? []),
        deltas: ActorDeltasField.getDeltas(result.clone, {
          actor: result.updateData, delete: result.deleteItems, item: result.updateItems
        }),
        request: config.request,
        type: result.type
      }
    };
    if ( config.request ) foundry.utils.setProperty(chatData, "flags.jujutsu-system.requestResult", {
      actorUuid: this.uuid, requestId: config.request.id
    });
    ChatMessage.applyMode(chatData, rollModeAtual());
    return ChatMessage.create(chatData);
  }

  /* -------------------------------------------- */

  /**
   * Generate rest flavor text based on the provided configuration.
   * @param {RestConfiguration} config  Rest configuration.
   * @param {RestResult} [result]       Result of the rest operation.
   * @returns {string}
   */
  createRestFlavor(config, result) {
    const typeConfig = CONFIG.DND5E.restTypes[config.type] ?? {};
    const duration = convertTime(config.duration, "minute");
    const parts = [formatTime(duration.value, duration.unit)];
    if ( result?.newDay ?? config.newDay ) parts.push(_loc("DND5E.REST.NewDay.Label").toLowerCase());
    return `${typeConfig.label} (${game.i18n.getListFormatter({ type: "unit" }).format(parts)})`;
  }

  /* -------------------------------------------- */

  /**
   * Automatically spend hit dice to recover hit points up to a certain threshold.
   * @param {object} [options]
   * @param {number} [options.threshold=3]  A number of missing hit points which would trigger an automatic HD roll.
   * @returns {Promise<number>}             Number of hit dice spent.
   */
  async autoSpendHitDice({ threshold=3 }={}) {
    if ( !this.system.attributes.hp ) return;
    const hp = this.system.attributes.hp;
    const max = Math.max(0, hp.effectiveMax);
    let diceRolled = 0;
    while ( (this.system.attributes.hp.value + threshold) <= max ) {
      const r = await this.rollHitDie();
      if ( r === null ) break;
      diceRolled += 1;
    }
    return diceRolled;
  }

  async autoSpendEnergyDice({ threshold=3 }={}) {
    const ed = this.system.energyDice;
    const energy = this.system.energy;
    if ( !ed || !energy ) return;
    const max = energy.max;
    const conMod = this.system.abilities?.con?.mod ?? 0;
    let diceRolled = 0;
    const rolls = [];

    while ( (this.system.energy.total + threshold) <= max && this.system.energyDice.value > 0 ) {
      const formula = conMod >= 0 ? `${ed.denomination} + ${conMod}` : `${ed.denomination} - ${Math.abs(conMod)}`;
      const roll = await new Roll(formula).evaluate();
      rolls.push(roll);
      const recovered = Math.max(0, roll.total);
      const newTotal = Math.min(this.system.energy.total + recovered, max);
      await this.update({
        "system.energy.total": newTotal,
        "system.energyDice.value": this.system.energyDice.value - 1
      }, { isEnergySystem: true });
      diceRolled++;
    }

    // Exibir todos os rolls no chat
    if ( rolls.length ) {
      const totalRecovered = rolls.reduce((sum, r) => sum + Math.max(0, r.total), 0);
      for ( const roll of rolls ) {
        await roll.toMessage({
          speaker: ChatMessage.getSpeaker({ actor: this, alias: this.name }),
          flavor: `${this.name} recupera PA de Energia Amaldiçoada (${ed.denomination} + mod. CON)`
        });
      }
    }

    return diceRolled;
  }

  /* -------------------------------------------- */

  /**
   * Recovers class hit dice during a long rest.
   *
   * @param {RestConfiguration} [config]
   * @param {number} [config.maxHitDice]  Maximum number of hit dice to recover.
   * @param {number} [config.fraction]    Fraction of max hit dice to recover. Used for NPC recovery and for PCs if
   *                                      `maxHitDice` isn't specified.
   * @param {RestResult} [result={}]      Rest result being constructed.
   * @protected
   */
  _getRestHitDiceRecovery({ maxHitDice, fraction, ...config }={}, result={}) {
    const restConfig = CONFIG.DND5E.restTypes[config.type];
    if ( !this.system.attributes.hd || !restConfig?.recoverHitDice ) return;
    fraction ??= dnd5e.settings.rulesVersion === "modern" ? 1 : 0.5;

    // Handle simpler HD recovery for NPCs
    if ( this.system.isNPC ) {
      const hd = this.system.attributes.hd;
      const recovered = Math.min(
        Math.max(1, Math.floor(hd.max * fraction)), hd.spent, maxHitDice ?? Infinity
      );
      foundry.utils.mergeObject(result, {
        deltas: {
          hitDice: (result.deltas?.hitDice ?? 0) + recovered
        },
        updateData: {
          "system.attributes.hd.spent": hd.spent - recovered
        }
      });
      return;
    }

    this.system.attributes.hd.createHitDiceUpdates({ maxHitDice, fraction, ...config }, result);
  }

  /* -------------------------------------------- */

  /**
   * Recovers actor hit points and eliminates any temp HP.
   * @param {RestConfiguration} [config={}]
   * @param {boolean} [config.recoverTemp=true]     Reset temp HP to zero.
   * @param {boolean} [config.recoverTempMax=true]  Reset temp max HP to zero.
   * @param {RestResult} [result={}]                Rest result being constructed.
   * @protected
   */
  _getRestHitPointRecovery({ recoverTemp, recoverTempMax, ...config }={}, result={}) {
    const restConfig = CONFIG.DND5E.restTypes[config.type ?? "long"];
    const hp = this.system.attributes?.hp;
    if ( !hp || !restConfig.recoverHitPoints ) return;

    let max = hp.max;
    result.updateData ??= {};
    if ( recoverTempMax ) result.updateData["system.attributes.hp.tempmax"] = 0;
    else max = Math.max(0, hp.effectiveMax);
    result.updateData["system.attributes.hp.value"] = max;
    if ( recoverTemp ) result.updateData["system.attributes.hp.temp"] = 0;
    foundry.utils.setProperty(
      result, "deltas.hitPoints", (result.deltas?.hitPoints ?? 0) + Math.max(0, max - hp.value)
    );
  }

  /* -------------------------------------------- */

  /**
   * Recovers actor resources.
   * @param {object} [config={}]
   * @param {boolean} [config.recoverShortRestResources]  Recover resources that recharge on a short rest.
   * @param {boolean} [config.recoverLongRestResources]   Recover resources that recharge on a long rest.
   * @param {RestResult} [result={}]                      Rest result being constructed.
   * @protected
   */
  _getRestResourceRecovery({ recoverShortRestResources, recoverLongRestResources, ...config }={}, result={}) {
    recoverShortRestResources ??= config.type === "short";
    recoverLongRestResources ??= config.type === "long";
    for ( let [k, r] of Object.entries(this.system.resources ?? {}) ) {
      if ( Number.isNumeric(r.max) && ((recoverShortRestResources && r.sr) || (recoverLongRestResources && r.lr)) ) {
        result.updateData[`system.resources.${k}.value`] = Number(r.max);
      }
    }
  }

  /* -------------------------------------------- */

  /**
   * Recovers expended spell slots.
   * @param {RestConfiguration} [config={}]
   * @param {boolean} [config.recoverShort]    Recover slots that return on short rests.
   * @param {boolean} [config.recoverLong]     Recover slots that return on long rests.
   * @param {RestResult} [result={}]           Rest result being constructed.
   * @protected
   */
  _getRestSpellRecovery({ recoverShort, recoverLong, ...config }={}, result={}) {
    const restConfig = CONFIG.DND5E.restTypes[config.type];
    if ( !this.system.spells ) return;
    const types = restConfig.recoverSpellSlotTypes;
    if ( !types?.size ) return;
    for ( const [key, slot] of Object.entries(this.system.spells) ) {
      if ( !types.has(slot.type) ) continue;
      result.updateData[`system.spells.${key}.value`] = slot.max;
    }
  }

  /* -------------------------------------------- */

  /**
   * Recovers item uses during short or long rests.
   * @param {object} [config]
   * @param {boolean} [config.recoverShortRestUses=true]  Recover uses for items that recharge after a short rest.
   * @param {boolean} [config.recoverLongRestUses=true]   Recover uses for items that recharge after a long rest.
   * @param {boolean} [config.recoverDailyUses=true]      Recover uses for items that recharge on a new day.
   * @param {RestResult} [result={}]                      Rest result being constructed.
   * @protected
   */
  async _getRestItemUsesRecovery({
    recoverShortRestUses, recoverLongRestUses, recoverDailyUses, ...config
  }={}, result={}) {
    const restConfig = CONFIG.DND5E.restTypes[config.type];
    let recovery = Array.from(restConfig.recoverPeriods ?? []).map(p => [p, 1]);
    if ( recoverShortRestUses ) recovery.unshift(["sr", 1]);
    if ( recoverLongRestUses ) recovery.unshift(["lr", 1]);
    if ( (recoverDailyUses || config.newDay) && dnd5e.settings.calendarConfig.manualRecovery ) {
      const days = (dnd5e.settings.restVariant === "gritty") && (config.type === "long") ? 7 : 1;
      recovery.unshift(["day", days], ["dawn", days], ["dusk", days]);
    }
    recovery = new Map(recovery);

    result.updateItems ??= [];
    result.rolls ??= [];
    for ( const item of this.items ) {
      if ( item.isHidden || (foundry.utils.getType(item.system.recoverUses) !== "function") ) continue;
      const { updates, rolls, destroy } = await item.system.recoverUses(recovery);
      if ( destroy ) {
        result.deleteItems.push(item.id);
      } else if ( !foundry.utils.isEmpty(updates) ) {
        const updateTarget = result.updateItems.find(i => i._id === item.id);
        if ( updateTarget ) foundry.utils.mergeObject(updateTarget, updates);
        else result.updateItems.push({ _id: item.id, ...updates });
      }
      result.rolls.push(...rolls);
    }
  }

  /* -------------------------------------------- */

  /**
   * Recovers energy dice during a long rest.
   * Amount recovered = actor level. Energy does NOT recover automatically.
   * @param {RestConfiguration} [config={}]
   * @param {RestResult} [result={}]
   * @protected
   */
  async _getRestEnergyDiceRecovery(config={}, result={}) {
    if ( config.type !== "long" ) return;
    const ed = this.system.energyDice;
    if ( !ed ) return;

    const level = this.system.details?.level ?? 1;
    const max = ed.max;
    const current = ed.value;
    const recovered = Math.min(level, max - current);
    if ( recovered <= 0 ) return;

    result.updateData ??= {};
    result.updateData["system.energyDice.value"] = current + recovered;

    await ChatMessage.create({
      speaker: ChatMessage.getSpeaker({ actor: this }),
      content: `${this.name} recuperou ${recovered} Cursed Energy Dice no Descanso Longo.`
    });
  }

  /* -------------------------------------------- */
  /*  Property Attribution                        */
  /* -------------------------------------------- */

  /**
   * Format an HTML breakdown for a given property.
   * @param {string} attribution      The property.
   * @param {object} [options]
   * @param {string} [options.title]  A title for the breakdown.
   * @returns {Promise<string>}
   */
  async getAttributionData(attribution, { title }={}) {
    switch ( attribution ) {
      case "attributes.ac": return this._prepareArmorClassAttribution({ title });
      case "attributes.movement": return this._prepareMovementAttribution();
      default: return "";
    }
  }

  /* -------------------------------------------- */

  /**
   * Prepare a movement breakdown.
   * @returns {string}
   * @protected
   */
  _prepareMovementAttribution() {
    const { movement } = this.system.attributes;
    const units = movement.units || defaultUnits("length");
    const unit = CONFIG.DND5E.movementUnits[units]?.formattingUnit;
    const formatValue = value => `<span class="value">${
      unit ? formatLength(value ?? 0, unit, { parts: true })
        : `${value ?? 0} <span class="units">${units}</span>`
    }</span>`;
    return Object.entries(CONFIG.DND5E.movementTypes).reduce((html, [k, { hidden, label }]) => {
      if ( hidden ) return html;
      const value = movement.speeds[k];
      if ( (k === "fly") && movement.hover ) label = _loc("DND5E.MOVEMENT.HoverSpeed", { speed: label });
      if ( value || (k === "walk") ) html += `
        <div class="row">
          <i class="fas ${k}"></i>
          ${formatValue(value)}
          <span class="label">${label}</span>
        </div>
      `;
      return html;
    }, "");
  }

  /* -------------------------------------------- */

  /**
   * Prepare an AC breakdown.
   * @param {object} [options]
   * @param {string} [options.title]  A title for the breakdown.
   * @returns {Promise<string>}
   * @protected
   */
  async _prepareArmorClassAttribution({ title }={}) {
    const rollData = this.getRollData({ deterministic: true });
    const ac = rollData.attributes.ac;
    const attribution = [];

    if ( Number.isFinite(ac.override) ) {
      attribution.push({
        label: _loc("DND5E.ARMORCLASS.Flat"),
        type: "override",
        value: ac.override
      });
      return new PropertyAttribution(this, attribution, "attributes.ac", { title }).renderTooltip();
    }

    // Base AC Attribution
    let base = ac.base;
    const dataRgx = new RegExp(/@([a-z.0-9_-]+)/gi);
    for ( const [match, term] of ac.formula.matchAll(dataRgx) ) {
      const value = String(foundry.utils.getProperty(rollData, term));
      if ( (term === "attributes.ac.armor") || (value === "0") ) continue;
      if ( Number.isNumeric(value) ) base -= Number(value);
      attribution.push({
        label: match,
        type: "add",
        value
      });
    }
    const armorInFormula = ac.formula.includes("@attributes.ac.armor");
    let label = ac.label || _loc("DND5E.PropertyBase");
    if ( armorInFormula ) label = this.armor?.name ?? _loc("DND5E.ARMORCLASS.Calculation.Unarmored");
    if ( base ) attribution.unshift({
      label,
      type: "override",
      value: base
    });
    else if ( attribution[0]?.label === "@attributes.ac.flat" ) attribution[0].label = label;

    // Shield
    if ( ac.shield !== 0 ) attribution.push({
      label: this.shield?.name ?? _loc("DND5E.EquipmentShield"),
      type: "add",
      value: ac.shield
    });

    // Bonus
    if ( ac.bonus !== 0 ) attribution.push(...this._prepareActiveEffectAttributions("system.attributes.ac.bonus"));

    // Cover
    if ( ac.cover !== 0 ) attribution.push({
      label: _loc("DND5E.Cover"),
      type: "add",
      value: ac.cover
    });

    if ( attribution.length ) {
      return new PropertyAttribution(this, attribution, "attributes.ac", { title }).renderTooltip();
    }

    return "";
  }

  /* -------------------------------------------- */

  /**
   * Break down all of the Active Effects affecting a given target property.
   * @param {string} target               The data property being targeted.
   * @returns {AttributionDescription[]}  Any active effects that modify that property.
   * @protected
   */
  _prepareActiveEffectAttributions(target) {
    const rollData = this.getRollData({ deterministic: true });
    const attributions = [];
    for ( const e of this.allApplicableEffects() ) {
      let source = e.sourceName;
      if ( !e.origin || e.matchesOrigin(this.uuid) ) source = e.name;
      if ( !source || e.disabled || e.isSuppressed ) continue;
      const value = e.changes.reduce((n, change) => {
        if ( (ActiveEffect5e.SHIM_FIELDS[change.key]?.key ?? change.key) !== target ) return n;
        if ( change.type !== "add" ) return n;
        return n + simplifyBonus(change.value, rollData);
      }, 0);
      if ( value ) attributions.push({ value, label: source, document: e, type: "add" });
    }
    return attributions;
  }

  /* -------------------------------------------- */
  /*  Conversion & Transformation                 */
  /* -------------------------------------------- */

  /**
   * Fetch stats from the original actor for data preparation.
   * @returns {{ originalSaves: object|null, originalSkills: object|null }}
   */
  getOriginalStats() {
    // Retrieve data for polymorphed actors
    let originalSaves = null;
    let originalSkills = null;
    if ( this.isPolymorphed ) {
      const transformOptions = this.flags["jujutsu-system"]?.transformOptions;
      const original = game.actors?.get(this.flags["jujutsu-system"]?.originalActor);
      if ( original ) {
        if ( transformOptions.mergeSaves ) originalSaves = original.system.abilities;
        if ( transformOptions.mergeSkills ) originalSkills = original.system.skills;
      }
    }
    return { originalSaves, originalSkills };
  }

  /* -------------------------------------------- */

  /**
   * Transform this Actor into another one.
   *
   * @param {Actor5e} source                       The actor being transformed into.
   * @param {TransformationSetting} [settings]     Options that determine how the transformation is performed.
   * @param {object} [options]
   * @param {boolean} [options.renderSheet]        Render the sheet of the transformed actor after the polymorph.
   * @returns {Promise<Array<Token>>|null}         Updated token if the transformation was performed.
   */
  async transformInto(source, settings=new TransformationSetting(), options={}) {
    // Ensure the player is allowed to polymorph
    const allowed = game.settings.get("jujutsu-system", "allowPolymorphing");
    if ( !allowed && !game.user.isGM ) {
      ui.notifications.warn("DND5E.TRANSFORM.Warning.NoPermission", { localize: true });
      return null;
    }

    // Get the original Actor data and the new source data
    const o = this.toObject();
    o.flags["jujutsu-system"] = o.flags["jujutsu-system"] || {};
    o.flags["jujutsu-system"].transformOptions = {
      ...settings.toObject(),
      mergeSaves: settings.merge.has("saves"),
      mergeSkills: settings.merge.has("skills")
    };
    const sourceData = source.toObject();
    const rollData = { ...this.getRollData(), source: source.getRollData() };

    if ( settings.keep.has("self") ) {
      o.img = sourceData.img;
      o.name = `${o.name} (${_loc("DND5E.TRANSFORM.Preset.Appearance.Label")})`;
    }

    // Prepare new data to merge from the source
    const d = foundry.utils.mergeObject(foundry.utils.deepClone({
      type: o.type, // Remain the same actor type
      name: `${o.name} (${sourceData.name})`, // Append the new shape to your old name
      system: sourceData.system, // Get the systemdata model of your new form
      items: sourceData.items, // Get the items of your new form
      effects: o.effects.concat(sourceData.effects), // Combine active effects from both forms
      img: sourceData.img, // New appearance
      ownership: o.ownership, // Use the original actor permissions
      folder: o.folder, // Be displayed in the same sidebar folder
      flags: o.flags, // Use the original actor flags
      prototypeToken: { texture: {}, sight: {}, detectionModes: [] } // Set a new empty token
    }), settings.keep.has("self") ? o : {}); // Keeps most of original actor

    // Specifically delete some data attributes
    delete d.system.resources; // Don't change your resource pools
    delete d.system.currency; // Don't lose currency
    delete d.system.bonuses; // Don't lose global bonuses

    if ( settings.keep.has("spells") || settings.spellLists.size ) {
      // Keep spellcasting ability if retaining spells.
      d.system.attributes.spellcasting = o.system.attributes.spellcasting;
    }

    // Specific additional adjustments
    d.system.details.alignment = o.system.details.alignment; // Don't change alignment
    d.system.attributes.exhaustion = o.system.attributes.exhaustion; // Keep your prior exhaustion level
    d.system.attributes.inspiration = o.system.attributes.inspiration; // Keep inspiration
    d.system.spells = o.system.spells; // Keep spell slots
    d.system.attributes.ac.flat = source.system.attributes.ac.value; // Override AC

    // Token appearance updates
    const tokenPropsFromSource = ["width", "height", "alpha", "lockRotation", "ring"];
    const tokenTexturePropsFromSource = ["offsetX", "offsetY", "scaleX", "scaleY", "src", "tint"];
    const tokenPropsFromSelf = ["bar1", "bar2", "displayBars", "displayName", "actorLink", "disposition"];
    const tokenPropsPreserved = ["rotation", "elevation", "hidden", "level"];
    const tokenPropsSelfPreserved = [...tokenPropsFromSelf, ...tokenPropsPreserved];

    for ( const k of tokenPropsFromSource ) {
      d.prototypeToken[k] = sourceData.prototypeToken[k];
    }
    for ( const k of tokenTexturePropsFromSource ) {
      d.prototypeToken.texture[k] = sourceData.prototypeToken.texture[k];
    }
    for ( const k of tokenPropsSelfPreserved ) {
      d.prototypeToken[k] = o.prototypeToken[k];
    }

    if ( !settings.keep.has("self") ) {
      const sightSource = settings.keep.has("vision") ? o.prototypeToken : sourceData.prototypeToken;
      for ( const k of ["range", "angle", "visionMode", "color", "attenuation", "brightness", "saturation", "contrast"] ) {
        d.prototypeToken.sight[k] = sightSource.sight[k];
      }
      d.prototypeToken.sight.enabled = o.prototypeToken.sight.enabled;
      d.prototypeToken.detectionModes = sightSource.detectionModes;

      // Transfer ability scores
      const abilities = d.system.abilities;
      for ( let k of Object.keys(abilities) ) {
        const oa = o.system.abilities[k];
        const prof = abilities[k].proficient;
        const type = CONFIG.DND5E.abilities[k]?.type;
        if ( settings.keep.has("physical") && (type === "physical") ) abilities[k] = oa;
        else if ( settings.keep.has("mental") && (type === "mental") ) abilities[k] = oa;

        // Set saving throw proficiencies.
        if ( settings.keep.has("saves") && oa ) abilities[k].proficient = oa.proficient;
        else if ( settings.merge.has("saves") && oa ) abilities[k].proficient = Math.max(prof, oa.proficient);
        else abilities[k].proficient = sourceData.system.abilities[k].proficient;
      }

      // Transfer skills
      if ( settings.keep.has("skills") ) d.system.skills = o.system.skills;
      else if ( settings.merge.has("skills") ) {
        for ( let [k, s] of Object.entries(d.system.skills) ) {
          s.value = Math.max(s.value, o.system.skills[k]?.value ?? 0);
        }
      }

      // Keep armor, weapon, & tool proficiencies
      if ( settings.keep.has("gearProf") ) {
        d.system.traits.armorProf = o.system.traits.armorProf;
        d.system.traits.weaponProf = o.system.traits.weaponProf;
        d.system.tools = o.system.tools;
      }

      // Keep languages
      if ( settings.keep.has("languages") ) d.system.traits.languages = o.system.traits.languages;

      // Keep specific items from the original data
      const spellIdentifiers = settings.spellLists.size ? new Set(
        Array.from(settings.spellLists)
          .map(id => dnd5e.registry.spellLists.forType(id))
          .filter(list => this.identifiedItems.get(list?.metadata.identifier, list?.metadata.type)?.size)
          .flatMap(list => Array.from(list.identifiers))
      ) : null;
      const profDiff = source.system.attributes.prof - this.system.attributes.prof;
      d.items = d.items.map(i => {
        if ( settings.keep.has("class") && ((i.type === "feat") || (i.type === "weapon")) && profDiff ) {
          // Items gained from the source should use the source's proficiency bonus.
          Object.values(i.system.activities).forEach(activity => {
            if ( activity.type === "attack" ) {
              activity.attack.bonus ??= "";
              activity.attack.bonus += ` ${profDiff < 0 ? "" : "+"}${profDiff}`;
            }
          });
        }
        return i;
      }).concat(o.items.filter(i => {
        switch ( i.type ) {
          case "class":
          case "subclass": return settings.keep.has("class") || settings.keep.has("hp");
          case "feat": return settings.keep.has("feats");
          case "spell": return spellIdentifiers?.has(i.system.identifier)
            || (!spellIdentifiers && settings.keep.has("spells"));
          case "race": return settings.keep.has("type");
          default: return settings.keep.has("items");
        }
      }));

      // Transfer classes for NPCs
      if ( !settings.keep.has("class") && ("cr" in d.system.details) ) {
        if ( settings.keep.has("hp") ) {
          let profOverride = d.effects.findSplice(e => e._id === staticID("dnd5eTransformProf"));
          if ( !profOverride ) profOverride = new ActiveEffect.implementation({
            _id: staticID("dnd5eTransformProf"),
            name: _loc("DND5E.Proficiency"),
            img: "icons/skills/social/diplomacy-peace-alliance.webp",
            disabled: false
          }).toObject();
          profOverride.changes = [{
            key: "system.attributes.prof",
            type: "override",
            value: source.system.attributes.prof
          }];
          d.effects.push(profOverride);
        } else {
          const cls = new dnd5e.dataModels.item.ClassData({ levels: d.system.details.cr });
          d.items.push({
            type: "class",
            name: _loc("DND5E.TRANSFORM.TemporaryClass"),
            system: cls.toObject()
          });
        }
      }

      // Keep biography
      if ( settings.keep.has("bio") ) d.system.details.biography = o.system.details.biography;

      // Keep senses
      if ( settings.keep.has("vision") ) d.system.traits.senses = o.system.traits.senses;

      // Keep creature type
      if ( settings.keep.has("type") ) d.system.details.type = o.system.details.type;

      // Keep HP & HD
      if ( settings.keep.has("hp") ) d.system.attributes.hp = {
        ...o.system.attributes.hp,
        max: this.system.attributes.hp.max
      };

      // Keep damage resistances
      if ( settings.keep.has("resistances") ) {
        d.system.traits.di = o.system.traits.di;
        d.system.traits.dr = o.system.traits.dr;
        d.system.traits.dv = o.system.traits.dv;
        d.system.traits.dm = o.system.traits.dm;
      }

      // Add temporary hit points
      const tempHp = simplifyBonus(settings.tempFormula, rollData);
      if ( tempHp ) d.system.attributes.hp.temp = tempHp;

      // Set armor class
      const minimumAC = simplifyBonus(settings.minimumAC, rollData);
      if ( minimumAC > source.system.attributes.ac.value ) {
        d.system.attributes.ac.calc = "natural";
        d.system.attributes.ac.flat = minimumAC;
      }

      // Remove active effects
      const oEffects = foundry.utils.deepClone(d.effects);
      const originEffectIds = new Set(oEffects.filter(effect => {
        const o = effect.system?.origin ?? {};
        const hasOrigin = effect.origin || foundry.utils.iterateValues(o).some(_ => _);
        return !hasOrigin || (effect.origin === this.uuid) || (o.actor === this.uuid);
      }).map(e => e._id));
      d.effects = d.effects.filter(e => {
        if ( settings.effects.has("all") ) return true;
        if ( settings.keep.has("hp") && !settings.keep.has("class") && (e._id === staticID("dnd5eTransformProf")) ) {
          return true;
        }
        const o = e.system?.origin ?? {};
        const originUuid = o.effect ?? o.behavior ?? o.activity ?? o.item ?? o.actor ?? e.origin;
        const origin = originUuid?.startsWith("Actor") || originUuid?.startsWith("Item")
          ? fromUuidSync(originUuid) : {};
        const originIsSelf = origin?.parent?.uuid === this.uuid;
        const isOriginEffect = originEffectIds.has(e._id);
        if ( isOriginEffect ) return settings.effects.has("origin");
        if ( !isOriginEffect && !originIsSelf ) return settings.effects.has("otherOrigin");
        switch ( origin.type ) {
          case "spell": return settings.effects.has("spell");
          case "feat": return settings.effects.has("feat");
          case "background": return settings.effects.has("background");
          case "class":
          case "subclass": return settings.effects.has("class");
          case "equipment":
          case "weapon":
          case "tool":
          case "loot":
          case "container": return settings.effects.has("equipment");
          default: return true;
        }
      });

      // Copy favorites
      if ( "favorites" in o.system ) d.system.favorites = o.system.favorites.filter(f => {
        if ( !["activity", "item"].includes(f.type) ) return true;
        const [, itemId] = foundry.utils.parseUuid(f.id, { relative: this, strict: false })?.embedded ?? [];
        return d.items.find(i => i._id === itemId);
      });
    }

    // Set a random image if source is configured that way
    if ( sourceData.prototypeToken.randomImg ) {
      const images = await source.getTokenImages();
      d.prototypeToken.texture.src = images[Math.floor(Math.random() * images.length)];
    }

    // Set new data flags
    if ( !this.isPolymorphed || !d.flags["jujutsu-system"].originalActor ) d.flags["jujutsu-system"].originalActor = this.id;
    d.flags["jujutsu-system"].isPolymorphed = true;

    // Gather previous actor data
    const previousActorIds = this.getFlag("jujutsu-system", "previousActorIds") || [];
    previousActorIds.push(this._id);
    foundry.utils.setProperty(d.flags, "jujutsu-system.previousActorIds", previousActorIds);

    // If `renderSheet` isn't specified, only render if non-transformed sheet is open
    options.renderSheet ??= this.sheet?.rendered ?? false;

    // Update unlinked Tokens, and grab a copy of any actorData adjustments to re-apply
    if ( this.isToken ) {
      const tokenData = d.prototypeToken;
      delete d.prototypeToken;
      for ( const k of tokenPropsSelfPreserved ) {
        tokenData[k] = this.token[k];
      }
      if ( settings.keep.has("self") ) {
        tokenData.name = `${this.token.name} (${_loc("DND5E.TRANSFORM.Preset.Appearance.Label")})`;
      } else {
        tokenData.name = `${this.token.name} (${sourceData.name})`;
      }

      if ( !this.token.flags["jujutsu-system"]?.previousActorData ) {
        const previousActorData = this.token.delta.toObject();
        const previousTokenData = { texture: {} };
        for ( const k of [...tokenPropsFromSource, ...tokenPropsFromSelf, "name"] ) {
          previousTokenData[k] = this.token[k];
        }
        for ( const k of tokenTexturePropsFromSource ) {
          previousTokenData.texture[k] = this.token.texture[k];
        }
        foundry.utils.setProperty(tokenData, "flags.jujutsu-system.previousActorData", previousActorData);
        foundry.utils.setProperty(tokenData, "flags.jujutsu-system.previousTokenData", previousTokenData);
      }
      await this.sheet?.close();
      const update = await this.token.update(tokenData);
      // TODO: We have to make do with these extra server hits until #12768 or #12769 is resolved.
      const itemIds = new Set(d.items.map(i => i._id));
      const effectIds = new Set(d.effects.map(e => e._id));
      // An invocation like this is the only thing that (currently) triggers correct tombstoning on the ActorDelta.
      await this.token.actor.deleteEmbeddedDocuments("Item", o.items.reduce((ids, { _id: id }) => {
        if ( !itemIds.has(id) ) ids.push(id);
        return ids;
      }, []));
      await this.token.actor.deleteEmbeddedDocuments("ActiveEffect", o.effects.reduce((ids, { _id: id }) => {
        if ( !effectIds.has(id) ) ids.push(id);
        return ids;
      }, []));
      await this.token.actor.update(d);
      if ( options.renderSheet ) this.sheet?.render(true);
      return update;
    }

    // Close sheet for non-transformed Actor
    await this.sheet?.close();

    /**
     * A hook event that fires just before the actor is transformed.
     * @function dnd5e.transformActor
     * @memberof hookEvents
     * @param {Actor5e} host                    The original actor before transformation.
     * @param {Actor5e} source                  The source actor into which to transform.
     * @param {object} data                     The data that will be used to create the new transformed actor.
     * @param {TransformationSetting} settings  Settings that determine how the transformation is performed.
     * @param {object} options                  Rendering options passed to the actor creation.
     */
    Hooks.callAll("dnd5e.transformActor", this, source, d, settings, options);
    Hooks.callAll("dnd5e.transformActorV2", this, source, d, settings, options);

    // Create new Actor with transformed data
    const newActor = await this.constructor.create(d, options);

    // Update placed Token instances
    if ( !settings.transformTokens ) return;
    const tokens = this.getActiveTokens(true);
    const updates = tokens.map(t => {
      const newTokenData = foundry.utils.deepClone(d.prototypeToken);
      newTokenData._id = t.id;
      newTokenData.actorId = newActor.id;
      newTokenData.actorLink = true;
      for ( const k of tokenPropsSelfPreserved ) {
        newTokenData[k] = t.document[k];
      }
      if ( settings.keep.has("self") ) {
        newTokenData.name = `${t.document.name} (${_loc("DND5E.TRANSFORM.Preset.Appearance.Label")})`;
      } else {
        newTokenData.name = `${t.document.name} (${sourceData.name})`;
      }

      const dOriginalActor = foundry.utils.getProperty(d, "flags.jujutsu-system.originalActor");
      foundry.utils.setProperty(newTokenData, "flags.jujutsu-system.originalActor", dOriginalActor);
      foundry.utils.setProperty(newTokenData, "flags.jujutsu-system.isPolymorphed", true);
      if ( !t.document.flags["jujutsu-system"]?.previousTokenData ) {
        const previousTokenData = { texture: {} };
        for ( const k of [...tokenPropsFromSource, ...tokenPropsFromSelf, "name"] ) {
          previousTokenData[k] = t.document[k];
        }
        for ( const k of tokenTexturePropsFromSource ) {
          previousTokenData.texture[k] = t.document.texture[k];
        }
        foundry.utils.setProperty(newTokenData, "flags.jujutsu-system.previousTokenData", previousTokenData);
      }
      return newTokenData;
    });
    return canvas.scene?.updateEmbeddedDocuments("Token", updates);
  }

  /* -------------------------------------------- */

  /**
   * If this actor was transformed with transformTokens enabled, then its
   * active tokens need to be returned to their original state. If not, then
   * we can safely just delete this actor.
   * @param {object} [options]
   * @param {boolean} [options.renderSheet=true]  Render Sheet after revert the transformation.
   * @returns {Promise<Actor>|null}  Original actor if it was reverted.
   */
  async revertOriginalForm(options={}) {
    if ( !this.isPolymorphed ) return;
    if ( !this.isOwner ) {
      ui.notifications.warn("DND5E.TRANSFORM.Warning.NoOwnership", { localize: true });
      return null;
    }

    options.renderSheet ??= true;

    /**
     * A hook event that fires just before the actor is reverted to original form.
     * @function dnd5e.revertOriginalForm
     * @memberof hookEvents
     * @param {Actor} actor                  The original actor before transformation.
     * @param {object} options
     * @param {boolean} options.renderSheet  Render the reverted actor sheet.
     */
    Hooks.callAll("dnd5e.revertOriginalForm", this, options);

    const transformOptions = this.getFlag("jujutsu-system", "transformOptions");
    const previousActorIds = this.getFlag("jujutsu-system", "previousActorIds") ?? [];
    const isRendered = this.sheet.rendered;

    // Obtain a reference to the original actor
    const original = game.actors.get(this.getFlag("jujutsu-system", "originalActor"));

    const update = {};
    if ( transformOptions?.keep?.includes("hp") ) {
      foundry.utils.setProperty(update, "system.attributes.hp.value", this.system.attributes.hp.value);
    }
    if ( transformOptions?.keep?.includes("tempHP") ) {
      foundry.utils.setProperty(update, "system.attributes.hp.temp", this.system.attributes.hp.temp);
    }
    if ( transformOptions?.keep?.includes("spells") || transformOptions?.spellLists?.length ) {
      Object.entries(this.system.spells ?? {}).forEach(([k, v]) => {
        if ( v.max ) update[`system.spells.${k}.value`] = v.value;
      });
    }

    // If we are reverting an unlinked token, grab the previous actorData, and create a new token
    if ( this.isToken ) {
      const baseActor = original ? original : game.actors.get(this.token.actorId);
      if ( !baseActor ) {
        ui.notifications.warn("DND5E.TRANSFORM.Warning.OriginalActor", {
          format: { reference: this.getFlag("jujutsu-system", "originalActor") }
        });
        return;
      }
      const prototypeTokenData = (await baseActor.getTokenDocument()).toObject();
      const actorData = this.token.getFlag("jujutsu-system", "previousActorData");
      foundry.utils.mergeObject(actorData, update);
      const tokenUpdate = this.token.toObject();
      actorData._id = tokenUpdate.delta._id;
      tokenUpdate.delta = actorData;

      foundry.utils.mergeObject(tokenUpdate, this.token.getFlag("jujutsu-system", "previousTokenData"));
      tokenUpdate.sight = prototypeTokenData.sight;
      tokenUpdate.detectionModes = prototypeTokenData.detectionModes;
      delete tokenUpdate.flags["jujutsu-system"]?.previousActorData;
      delete tokenUpdate.flags["jujutsu-system"]?.previousTokenData;

      await this.sheet.close();
      const token = await TokenDocument.implementation.create(tokenUpdate, { parent: this.token.parent, render: true });
      await this.token.delete({ replacements: { [this.token._id]: token.uuid } });
      if ( isRendered && options.renderSheet ) token.actor?.sheet?.render(true);
      return token;
    }

    if ( !original ) {
      ui.notifications.warn("DND5E.TRANSFORM.Warning.OriginalActor", {
        format: { reference: this.getFlag("jujutsu-system", "originalActor") }
      });
      return;
    }

    // Get the Tokens which represent this actor
    if ( canvas.ready ) {
      const tokens = this.getActiveTokens(true);
      const tokenData = (await original.getTokenDocument()).toObject();
      const tokenUpdates = tokens.map(t => {
        const update = foundry.utils.deepClone(tokenData);
        update._id = t.id;
        foundry.utils.mergeObject(update, t.document.getFlag("jujutsu-system", "previousTokenData"));
        delete update.x;
        delete update.y;
        delete update.elevation;
        delete update.hidden;
        delete update.rotation;
        delete update.level;
        return update;
      });
      await canvas.scene.updateEmbeddedDocuments("Token", tokenUpdates, { diff: false, recursive: false });
    }

    const polymorphedActorIds = previousActorIds.filter(id =>
      id !== original.id // Is not original Actor Id
      && game.actors?.get(id) // Actor still exists
    ).concat([this.id]); // Add this id
    // Delete the polymorphed version(s) of the actor, if possible
    if ( game.user.isGM ) {
      await Actor.implementation.deleteDocuments(polymorphedActorIds);
    } else {
      // Remove the flags
      const actorUpdates = polymorphedActorIds.filter(id => game.actors.get(id).isOwner).map(p => {
        return { _id: p, "flags.jujutsu-system": { isPolymorphed: _del, previousActorIds: _del } };
      });
      await Actor.implementation.updateDocuments(actorUpdates);

      if ( isRendered ) this.sheet?.close();
    }
    if ( !foundry.utils.isEmpty(update) ) await original.update(update, { dnd5e: { concentrationCheck: false } });
    if ( isRendered && options.renderSheet ) original.sheet?.render(isRendered);
    return original;
  }

  /* -------------------------------------------- */
  /*  Context Menus                               */
  /* -------------------------------------------- */

  /**
   * Add additional system-specific sidebar directory context menu options for Actor documents
   * @param {ApplicationV2} app   The application being displayed.
   * @param {Array} entryOptions  The default array of context menu options
   */
  static addDirectoryContextOptions(app, entryOptions) {
    if ( app instanceof foundry.applications.sidebar.apps.Compendium ) return;
    entryOptions.push({
      label: "DND5E.TRANSFORM.Action.Restore",
      icon: "fa-solid fa-backward",
      group: "system",
      visible: li => {
        const allowed = game.settings.get("jujutsu-system", "allowPolymorphing");
        if ( !allowed && !game.user.isGM ) return false;
        const actor = game.actors.get(li.dataset.entryId);
        return actor && actor.isPolymorphed;
      },
      onClick: (_, target) => {
        const actor = game.actors.get(target.dataset.entryId);
        return actor.revertOriginalForm();
      }
    }, {
      label: "DND5E.Group.Primary.Set",
      icon: "fa-solid fa-star",
      group: "system",
      visible: li => {
        const actor = game.actors.get(li.dataset.entryId);
        const primary = game.actors.party;
        return game.user.isGM && (actor?.type === "group") && (actor !== primary);
      },
      onClick: (_, target) => game.settings.set("jujutsu-system", "primaryParty", {
        actor: game.actors.get(target.dataset.entryId)
      })
    }, {
      label: "DND5E.Group.Primary.Remove",
      icon: "fa-regular fa-star",
      group: "system",
      visible: li => {
        const actor = game.actors.get(li.dataset.entryId);
        return game.user.isGM && (actor === game.actors.party);
      },
      onClick: () => game.settings.set("jujutsu-system", "primaryParty", { actor: null })
    });
  }

  /* -------------------------------------------- */

  /**
   * Add class to actor entry representing the primary group.
   * @param {HTMLElement} html
   */
  static onRenderActorDirectory(html) {
    const primaryParty = game.actors.party;
    if ( primaryParty ) {
      const element = html?.querySelector(`[data-entry-id="${primaryParty.id}"]`);
      element?.classList.add("primary-party");
    }
  }

  /* -------------------------------------------- */
  /*  Socket Event Handlers                       */
  /* -------------------------------------------- */

  /** @override */
  static async createDialog(data={}, createOptions={}, dialogOptions={}) {
    CreateDocumentDialog.migrateOptions(createOptions, dialogOptions);
    return CreateDocumentDialog.prompt(this, data, createOptions, dialogOptions);
  }

  /* -------------------------------------------- */

  /** @inheritDoc */
async _preUpdate(changed, options, user) {
    if ( (await super._preUpdate(changed, options, user)) === false ) return false;

    // Record previous exhaustion level.
    if ( Number.isFinite(foundry.utils.getProperty(changed, "system.attributes.exhaustion")) ) {
      foundry.utils.setProperty(options, "dnd5e.originalExhaustion", this.system.attributes.exhaustion);
    }

    // Avisar no chat quando PA Gerada for alterada manualmente
    const novaGerada = foundry.utils.getProperty(changed, "system.energy.generated");
    if ( Number.isFinite(novaGerada) && !options.isEnergySystem && this.type === "character" ) {
      const antiga = this.system.energy.generated;
      if ( novaGerada !== antiga ) {
        const delta = novaGerada - antiga;
        const sinal = delta > 0 ? `+${delta}` : `${delta}`;
        ChatMessage.create({
          speaker: ChatMessage.getSpeaker({ actor: this }),
          content: `⚡ <b>${this.name}</b> alterou a PA Gerada manualmente: ${antiga} → ${novaGerada} (${sinal})`
        });
      }
    }

    // Avisar no chat quando a Aura Total (reserva) for alterada manualmente
    const novaTotal = foundry.utils.getProperty(changed, "system.energy.total");
    if ( Number.isFinite(novaTotal) && !options.isEnergySystem && this.type === "character" ) {
      const antigaTotal = this.system.energy.total;
      if ( novaTotal !== antigaTotal ) {
        const delta = novaTotal - antigaTotal;
        const sinal = delta > 0 ? `+${delta}` : `${delta}`;
        ChatMessage.create({
          speaker: ChatMessage.getSpeaker({ actor: this }),
          content: `🌀 <b>${this.name}</b> alterou a Aura Total manualmente: ${antigaTotal} → ${novaTotal} (${sinal})`
        });
      }
    }
  }

  /* -------------------------------------------- */

  /** @inheritDoc */
  async _onUpdate(data, options, userId) {
    super._onUpdate(data, options, userId);
    if ( userId === game.userId ) {
      await this.updateEncumbrance(options);
      this._onUpdateExhaustion(data, options);
    }
    if ( game.user.isActiveGM ) await BastionTurnMessageData.applyClaim(options);
  }

  /* -------------------------------------------- */

  /** @inheritDoc */
  _onDelete(options, userId) {
    // Remove any group sheet apps so they aren't also closed.
    for ( const id in this.apps ) {
      const app = this.apps[id];
      if ( app instanceof dnd5e.applications.actor.GroupActorSheet ) delete this.apps[id];
    }

    super._onDelete(options, userId);

    const origin = this.getFlag("jujutsu-system", "summon.origin");
    if ( origin ) {
      const { collection, primaryId } = foundry.utils.parseUuid(origin);
      dnd5e.registry.summons.untrack(collection?.get?.(primaryId)?.uuid, this.uuid);
    }
  }

  /* -------------------------------------------- */

  /** @inheritDoc */
  async _onCreateDescendantDocuments(parent, collection, documents, data, options, userId) {
    super._onCreateDescendantDocuments(parent, collection, documents, data, options, userId);
    if ( userId === game.userId ) {
      if ( (collection === "effects") && documents.find(d => d.id === ActiveEffect5e.ID.EXHAUSTION)
        && !this._source.system.attributes?.exhaustion ) {
        await this.update({ "system.attributes.exhaustion": 1 });
      }
      if ( collection === "items" ) await this.updateEncumbrance(options);
    }
  }

  /* -------------------------------------------- */

  /** @inheritDoc */
  async _onUpdateDescendantDocuments(parent, collection, documents, changes, options, userId) {
    super._onUpdateDescendantDocuments(parent, collection, documents, changes, options, userId);
    if ( (userId === game.userId) && (collection === "items") ) await this.updateEncumbrance(options);
    if ( collection === "items" ) {
      const refreshBars = documents.some((doc, index) => {
        return doc.hasLimitedUses && foundry.utils.hasProperty(changes[index], "system.uses.spent");
      });
      if ( refreshBars ) this.getActiveTokens().forEach(token => token.renderFlags.set({ refreshBars: true }));
    }
  }

  /* -------------------------------------------- */

  /** @inheritDoc */
  async _onDeleteDescendantDocuments(parent, collection, documents, ids, options, userId) {
    super._onDeleteDescendantDocuments(parent, collection, documents, ids, options, userId);
    if ( userId === game.userId ) {
      if ( (collection === "effects") && ids.includes(ActiveEffect5e.ID.EXHAUSTION) ) {
        await this.update({ "system.attributes.exhaustion": 0 });
      }
      if ( collection === "items" ) await this.updateEncumbrance(options);
      await this._clearFavorites(documents);
    }
  }

  /* -------------------------------------------- */
  /*  Event Listeners and Handlers                */
  /* -------------------------------------------- */

  /**
   * Assign a class item as the original class for the Actor based on which class has the most levels.
   * @returns {Promise<Actor5e>}  Instance of the updated actor.
   * @protected
   */
  _assignPrimaryClass() {
    const classes = this.itemTypes.class.sort((a, b) => b.system.levels - a.system.levels);
    const newPC = classes[0]?.id || "";
    return this.update({ "system.details.originalClass": newPC });
  }

  /* -------------------------------------------- */

  /**
   * Handle clearing favorited entries that were deleted.
   * @param {Document[]} documents  The deleted Documents.
   * @returns {Promise<Actor5e>|void}
   * @protected
   */
  _clearFavorites(documents) {
    if ( !("favorites" in this.system) ) return;
    const ids = new Set(documents.map(d => foundry.utils.buildRelativeUuid(d, this)));
    const favorites = this.system.favorites.filter(f => !ids.has(f.id));
    return this.update({ "system.favorites": favorites });
  }

  /* -------------------------------------------- */

  /**
   * Flash ring & display changes to health as scrolling combat text.
   * @param {object} changes          Object of changes to hit points.
   * @param {number} changes.hp       Changes to `hp.value`.
   * @param {number} changes.temp     The change to `hp.temp`.
   * @param {number} changes.total    The total change to hit points.
   * @protected
   */
  _displayTokenEffect(changes) {
    let key;
    let value;
    if ( changes.hp < 0 ) {
      key = "damage";
      value = changes.total;
    } else if ( changes.hp > 0 ) {
      key = "healing";
      value = changes.total;
    } else if ( changes.temp ) {
      key = "temp";
      value = changes.temp;
    }
    if ( !key || !value ) return;

    const tokens = this.isToken ? [this.token] : this.getActiveTokens(true, true);
    if ( !tokens.length ) return;

    const pct = Math.clamp(Math.abs(value) / this.system.attributes.hp.max, 0, 1);
    const fill = CONFIG.DND5E.tokenHPColors[key];

    for ( const token of tokens ) {
      if ( !token.object?.visible || token.isSecret ) continue;
      if ( token.hasDynamicRing ) token.flashRing(key);
      const t = token.object;
      canvas.interface.createScrollingText(t.center, value.signedString(), {
        anchor: CONST.TEXT_ANCHOR_POINTS.TOP,
        // Adapt the font size relative to the Actor's HP total to emphasize more significant blows
        fontSize: 16 + (32 * pct), // Range between [16, 48]
        fill: fill,
        stroke: 0x000000,
        strokeThickness: 4,
        jitter: 0.25
      });
    }
  }

  /* -------------------------------------------- */

  /**
   * Toggle a configured status effect for the Actor.
   * @override
   * @param {string} statusId                       A status effect ID defined in CONFIG.statusEffects
   * @param {object} [options={}]                   Additional options which modify how the effect is created.
   * @param {boolean} [options.active]              Force the effect to be active or inactive
   *                                                regardless of its current state.
   * @param {boolean} [options.overlay=false]       Display the toggled effect as an overlay.
   * @param {number} [options.levels=1]             A potential level increase.
   * @returns {Promise<ActiveEffect|boolean|void>}  A promise which resolves to one of the following values:
   *                                                - ActiveEffect if a new effect need to be created or updated.
   *                                                - true if was already an existing effect.
   *                                                - false if an existing effect needed to be removed.
   *                                                - undefined if no changes need to be made.
   */
  async toggleStatusEffect(statusId, options={}) {
    const hasLevels = ConditionData.hasLevels(statusId);
    const ActiveEffect = getDocumentClass("ActiveEffect");
    let created;

    if ( hasLevels ) created = await ConditionData._applyDelta(statusId, this, { levels: options.levels ?? 1});
    created ??= await super.toggleStatusEffect(statusId, options);
    const status = CONFIG.statusEffects[statusId];
    if ( !(created instanceof ActiveEffect) || !status.exclusiveGroup ) return created;

    const others = Object.values(CONFIG.statusEffects)
      .filter(e => (e.id !== statusId) && (e.exclusiveGroup === status.exclusiveGroup) && this.effects.has(e._id));
    if ( others.length ) await this.deleteEmbeddedDocuments("ActiveEffect", others.map(e => e._id));

    return created;
  }

  /* -------------------------------------------- */

  /**
   * TODO: Perform this as part of Actor._preUpdateOperation instead when it becomes available in v12.
   * Handle syncing the Actor's exhaustion level with the ActiveEffect.
   * @param {object} data                          The Actor's update delta.
   * @param {DocumentModificationContext} options  Additional options supplied with the update.
   * @returns {Promise<ActiveEffect|void>}
   * @protected
   */
  async _onUpdateExhaustion(data, options) {
    const originalExhaustion = foundry.utils.getProperty(options, "dnd5e.originalExhaustion");
    const level = foundry.utils.getProperty(data, "system.attributes.exhaustion");
    const delta = level - originalExhaustion;
    if ( delta ) ConditionData._applyDelta("exhaustion", this, { levels: delta });
  }

  /* -------------------------------------------- */

  /**
   * Handle applying/removing the bloodied status.
   * @param {DocumentModificationContext} options  Additional options supplied with the update.
   * @returns {Promise<ActiveEffect>|void}
   */
  updateBloodied(options) {
    const hp = this.system.attributes?.hp;
    if ( !this.system.isCreature || !hp?.effectiveMax || (dnd5e.settings.bloodied === "none") ) return;

    const effect = this.effects.get(ActiveEffect5e.ID.BLOODIED);
    if ( (hp.pct === 100) || (hp.pct > hp.bloodied) ) return effect?.delete();
    if ( effect ) return;

    return ActiveEffect.implementation.create({
      _id: ActiveEffect5e.ID.BLOODIED,
      img: CONFIG.DND5E.bloodied.img,
      flags: { dnd5e: { isTemporary: true } },
      name: _loc(CONFIG.DND5E.bloodied.name),
      statuses: ["bloodied"],
      showIcon: CONST.ACTIVE_EFFECT_SHOW_ICON?.CONDITIONAL
    }, { parent: this, keepId: true });
  }

  /* -------------------------------------------- */

  /**
   * Handle applying/removing the dead/unconscious status.
   * @param {DocumentModificationContext} options  Additional options supplied with the update.
   * @returns {Promise<ActiveEffect|boolean|void>}
   */
  async updateDowned(options) {
    const { autoApplyDowned } = dnd5e.settings;
    if ( autoApplyDowned === "none" ) return;
    const hp = this.system.attributes?.hp;
    if ( !hp ) return;

    // If non-zero, remove any auto-downed effects
    if ( hp.value ) {
      const autoEffects = this.effects.filter(e => e.getFlag("jujutsu-system", "autoDowned"));
      return this.deleteEmbeddedDocuments("ActiveEffect", autoEffects.map(e => e.id));
    }
    const conditionEffects = this.effects.documentsByType.condition;
    const isDead = conditionEffects.some(e => e.system.type === "dead");
    const isUnconscious = conditionEffects.some(e => e.system.type === "unconscious");

    // Do not auto-apply statuses outside of combat or if already dead
    if ( !this.inCombat || isDead ) return;
    const failedDeathSaves = this.system.attributes.death.failure >= 3;
    let toApply = null;
    if ( this.type === "npc" ) {
      if ( !this.system.traits.important ) toApply = "dead";
      else if ( autoApplyDowned !== "deadOnly" ) toApply = failedDeathSaves ? "dead" : "unconscious";
    } else if ( (this.type === "character") && (autoApplyDowned === "all") ) {
      toApply = failedDeathSaves ? "dead" : "unconscious";
    }
    if ( !toApply || ((toApply === "unconscious") && isUnconscious) ) return;
    const effect = await ActiveEffect.implementation.fromStatusEffect(toApply);
    const flags = { dnd5e: { autoDowned: true } };
    if ( toApply === "dead" ) flags.core = { overlay: true };
    effect.updateSource({ flags });
    return ActiveEffect.implementation.create(effect, { parent: this, keepId: true });
  }

  /* -------------------------------------------- */

  /**
   * Handle applying/removing encumbrance statuses.
   * @param {DocumentModificationContext} options  Additional options supplied with the update.
   * @returns {Promise<ActiveEffect>|void}
   */
  updateEncumbrance(options) {
    const encumbrance = this.system.attributes?.encumbrance;
    if ( !encumbrance || (game.settings.get("jujutsu-system", "encumbrance") === "none") ) return;
    const statuses = [];
    const variant = game.settings.get("jujutsu-system", "encumbrance") === "variant";
    if ( encumbrance.value > encumbrance.thresholds.maximum ) statuses.push("exceedingCarryingCapacity");
    if ( (encumbrance.value > encumbrance.thresholds.heavilyEncumbered) && variant ) statuses.push("heavilyEncumbered");
    if ( (encumbrance.value > encumbrance.thresholds.encumbered) && variant ) statuses.push("encumbered");

    const effect = this.effects.get(ActiveEffect5e.ID.ENCUMBERED);
    if ( !statuses.length ) return effect?.delete();

    const effectData = { ...CONFIG.DND5E.encumbrance.effects[statuses[0]], statuses };
    if ( effect ) {
      const originalEncumbrance = effect.statuses.first();
      return effect.update(effectData, { dnd5e: { originalEncumbrance } });
    }

    return ActiveEffect.implementation.create(
      { _id: ActiveEffect5e.ID.ENCUMBERED, ...effectData },
      { parent: this, keepId: true }
    );
  }

  /* -------------------------------------------- */

  /** @inheritDoc */
  static getDefaultArtwork(actorData={}) {
    const img = CONFIG.DND5E.defaultArtwork.Actor[actorData.type];
    return img ? { img, texture: { src: img } } : super.getDefaultArtwork(actorData);
  }

  /* -------------------------------------------- */
  /*  Helpers                                     */
  /* -------------------------------------------- */

  /**
   * Perform bulk updates on the actor and its embedded documents.
   * @param {ActorUpdatesDescription} updates
   * @param {DatabaseUpdateOperation[]} [updates.operations=[]]    Additional database operations to perform.
   * @param {object} [options]                                     Options passed to all database operations.
   * @param {Partial<DatabaseCreateOperation>} [options.createOptions={}]  Options passed to item creation operation. By
   *                                                                       default the `keepId` option is set to `true`.
   * @param {Partial<DatabaseDeleteOperation>} [options.deleteOptions={}]  Options passed to item deletion operation.
   * @param {Partial<DatabaseUpdateOperation>} [options.updateOptions={}]  Options passed to item update operation.
   * @returns {Promise<Document[][]>}
   */
  performBulkUpdate(
    { operations=[], ...updates }, { createOptions={}, deleteOptions={}, updateOptions={}, ...options }={}
  ) {
    if ( !foundry.utils.isEmpty(updates.actor) ) operations.push(this.parent
      ? {
        action: "update", documentName: "ActorDelta", parent: this.parent,
        updates: [{ ...updates.actor, _id: this.parent.delta.id }], ...options
      }
      : { action: "update", documentName: "Actor", updates: [{ _id: this.id, ...updates.actor }], ...options }
    );
    if ( !foundry.utils.isEmpty(updates.create) ) operations.push({
      action: "create", documentName: "Item", data: updates.create, parent: this, keepId: true,
      ...options, ...createOptions
    });
    if ( !foundry.utils.isEmpty(updates.delete) ) operations.push({
      action: "delete", documentName: "Item", ids: updates.delete, parent: this,
      ...options, ...deleteOptions
    });
    if ( !foundry.utils.isEmpty(updates.item) ) operations.push({
      action: "update", documentName: "Item", updates: updates.item, parent: this,
      ...options, ...updateOptions
    });
    if ( this.type === "character" && Ruleset.isV2()
      && operations.some(operation => operation.documentName === "Item" && operation.parent === this) ) {
      return performValidatedCustomizationBatch(this, operations, () => foundry.documents.modifyBatch(operations));
    }
    return foundry.documents.modifyBatch(operations);
  }
}

/* -------------------------------------------- */

/**
 * @extends {Map<string, Set<Item5e>>}
 */
class IdentifiedItemsMap extends Map {
  /** @inheritDoc */
  get(key, { type }={}) {
    if ( !key ) return;
    if ( key.includes(":") && !type ) [type, key] = key.split(":", 2);
    const result = super.get(key);
    if ( !result?.size || !type ) return result;
    return result.filter(i => i.type === type);
  }

  /* -------------------------------------------- */

  /** @inheritDoc */
  set(key, value) {
    if ( !key ) return this;
    if ( !this.has(key) ) super.set(key, new Set());
    this.get(key).add(value);
    return this;
  }
}

/* -------------------------------------------- */

/**
 * @extends {Map<string, Set<Item5e>>}
 */
class SourcedItemsMap extends Map {
  /** @inheritDoc */
  get(key, { remap=true }={}) {
    if ( !key ) return;
    if ( remap ) ({ uuid: key } = foundry.utils.parseUuid(key) ?? {});
    return super.get(key);
  }

  /* -------------------------------------------- */

  /** @inheritDoc */
  set(key, value) {
    const { uuid } = foundry.utils.parseUuid(key);
    if ( !this.has(uuid) ) super.set(uuid, new Set());
    this.get(uuid, { remap: false }).add(value);
    return this;
  }

  /* -------------------------------------------- */

  /**
   * Adjust keys once compendium UUID redirects have been initialized.
   */
  _redirectKeys() {
    for ( const [key, set] of this.entries() ) {
      const { uuid } = foundry.utils.parseUuid(key);
      if ( key !== uuid ) {
        for ( const item of set ) this.set(uuid, item);
        this.delete(key);
      }
    }
  }
}
